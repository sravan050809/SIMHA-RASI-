import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowUpDown, ChevronRight, Radar } from "lucide-react";
import { toast } from "sonner";
import { api, errorText, fmtDate, riskScore } from "@/lib/api";
import { PAGE, fadeUp, stagger } from "@/lib/motion";
import { Page } from "@/components/Shell";
import { EmptyState, Overline, Spinner, StatusBadge } from "@/components/kit";

export default function History() {
  const nav = useNavigate();
  const [scans, setScans] = useState(null);
  const [status, setStatus] = useState("all");
  const [sort, setSort] = useState("newest");
  useEffect(() => { api.get("/scans").then((r) => setScans(r.data)).catch((e) => { toast.error(errorText(e)); setScans([]); }); }, []);

  const list = useMemo(() => {
    let l = (scans || []).filter((s) => status === "all" || s.status === status);
    if (sort === "newest") l = [...l].sort((a, b) => b.started_at.localeCompare(a.started_at));
    if (sort === "oldest") l = [...l].sort((a, b) => a.started_at.localeCompare(b.started_at));
    if (sort === "risk") l = [...l].sort((a, b) => riskScore(b.summary) - riskScore(a.summary));
    return l;
  }, [scans, status, sort]);

  if (!scans) return <Page variant={PAGE.history}><div className="flex items-center gap-2 text-sm text-[var(--text-2)]"><Spinner />Loading history…</div></Page>;

  return (
    <Page variant={PAGE.history} testId="history-page">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div><Overline className="mb-2 text-[var(--ice)]">Scan history</Overline><h1 className="text-3xl font-bold tracking-tight sm:text-4xl">{scans.length} scan{scans.length === 1 ? "" : "s"}</h1></div>
        <div className="flex flex-wrap items-center gap-2">
          <select className="input w-auto py-2 text-sm" value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Filter by status" data-testid="history-filter-status">{["all", "done", "running", "failed", "cancelled"].map((s) => <option key={s} value={s}>{s === "all" ? "All statuses" : s}</option>)}</select>
          <select className="input w-auto py-2 text-sm" value={sort} onChange={(e) => setSort(e.target.value)} aria-label="Sort" data-testid="history-sort"><option value="newest">Newest first</option><option value="oldest">Oldest first</option><option value="risk">Highest risk</option></select>
        </div>
      </div>

      {!list.length ? <div className="mt-8"><EmptyState icon={Radar} title={scans.length ? "Nothing matches this filter" : "No scans yet"} hint={scans.length ? "Try another status." : "Run your first analysis from the command center."} testId="history-empty" action={!scans.length && <button className="btn btn-primary" onClick={() => nav("/app/new")}>Start a scan</button>} /></div> : (
        <motion.ol variants={stagger(0.06)} initial="hidden" animate="show" className="relative mt-8 ml-3 space-y-4 border-l border-[var(--line)] pl-6" data-testid="history-timeline">
          {list.map((s) => { const risk = riskScore(s.summary); const col = s.status !== "done" ? "var(--text-3)" : risk > 66 ? "var(--red)" : risk > 33 ? "var(--amber)" : "var(--green)"; return (
            <motion.li key={s.scan_id} variants={fadeUp} className="relative">
              <span className="absolute -left-[31px] top-5 h-3 w-3 rounded-full border-2 border-[var(--bg)]" style={{ background: col, boxShadow: `0 0 12px ${col}` }} />
              <button onClick={() => nav(s.status === "done" ? `/app/scan/${s.scan_id}/results` : `/app/scan/${s.scan_id}`)} className="glass glass-hover group flex w-full flex-wrap items-center gap-4 p-5 text-left" data-testid={`history-item-${s.scan_id}`}>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2"><h3 className="truncate text-base font-semibold">{s.project_name}</h3><StatusBadge status={s.status} /></div>
                  <div className="mt-1 text-xs text-[var(--text-3)]">{s.language} · {fmtDate(s.started_at)} · <span className="font-code">{s.scan_id}</span></div>
                  <div className="mt-2 flex flex-wrap gap-1.5">{s.findings.slice(0, 6).map((f) => <span key={f.id} className={`badge sev-${f.severity}`} style={{ fontSize: 10, padding: "1px 7px" }}>{f.severity}</span>)}{s.findings.length > 6 && <span className="text-xs text-[var(--text-3)]">+{s.findings.length - 6}</span>}</div>
                </div>
                <div className="flex items-center gap-6 text-right">
                  <div><div className="font-head text-2xl font-semibold">{s.findings_count}</div><div className="overline">findings</div></div>
                  <div><div className="font-head text-2xl font-semibold text-[var(--emerald)]">{s.verified_count}</div><div className="overline">verified</div></div>
                  <div><div className="font-head text-2xl font-semibold" style={{ color: col }}>{s.status === "done" ? risk : "—"}</div><div className="overline">risk</div></div>
                  <ChevronRight size={18} className="text-[var(--text-3)] transition-transform group-hover:translate-x-1 group-hover:text-[var(--cyan)]" />
                </div>
              </button>
            </motion.li>); })}
        </motion.ol>
      )}
      <p className="mt-6 inline-flex items-center gap-2 text-xs text-[var(--text-3)]"><ArrowUpDown size={12} />Risk = 40·critical + 22·high + 10·medium + 4·low, capped at 100.</p>
    </Page>
  );
}
