import { useCallback, useEffect, useState } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeft, ChevronRight, GitBranch, FileCode2, Wrench, MousePointerClick } from "lucide-react";
import { toast } from "sonner";
import { api, errorText } from "@/lib/api";
import { PAGE, EASE } from "@/lib/motion";
import { Page } from "@/components/Shell";
import { ConfidenceBadge, Overline, SeverityBadge, Spinner, StatusBadge, Segmented } from "@/components/kit";
import { ExploitGraph, NODE_COLOR } from "@/components/ExploitGraph";
import { CodeView, PatchReview } from "@/components/PatchReview";

const TABS = [{ value: "graph", label: "Exploit graph", icon: <GitBranch size={13} /> }, { value: "code", label: "Vulnerable code", icon: <FileCode2 size={13} /> }, { value: "patch", label: "Patch review", icon: <Wrench size={13} /> }];

function NodePanel({ node }) {
  if (!node) return <div className="glass flex items-center gap-3 p-5 text-sm text-[var(--text-2)]" data-testid="graph-node-panel-empty"><MousePointerClick size={18} className="text-[var(--cyan)]" />Select a node — or press Play — to see its code, location and a plain-language explanation. Use ← → to step through the path.</div>;
  const col = NODE_COLOR[node.node_type];
  return (
    <motion.div key={node.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35, ease: EASE }} className="glass p-5" style={{ borderColor: `${col}55` }} data-testid="graph-node-panel">
      <div className="flex flex-wrap items-center gap-3"><span className="badge" style={{ color: col, borderColor: `${col}66`, background: `${col}1a` }}>{node.node_type}</span><h3 className="text-lg font-semibold">{node.label}</h3><span className="ml-auto font-code text-xs text-[var(--text-3)]">{node.file_path} · line {node.line_number}</span></div>
      <p className="mt-3 text-sm leading-relaxed text-[var(--text-2)]">{node.explanation}</p>
      <pre className="code-surface mt-3 overflow-x-auto px-3 py-2 text-[12px]">{node.code_snippet || "—"}</pre>
    </motion.div>
  );
}

export default function FindingDetail() {
  const { sid, fid } = useParams();
  const nav = useNavigate();
  const [params, setParams] = useSearchParams();
  const tab = params.get("tab") || "graph";
  const [scan, setScan] = useState(null);
  const [sel, setSel] = useState(null);
  const [mode, setMode] = useState("vulnerable");
  const [busy, setBusy] = useState(false);

  useEffect(() => { api.get(`/scans/${sid}`).then((r) => setScan(r.data)).catch((e) => toast.error(errorText(e))); }, [sid]);
  const setTab = (t) => setParams({ tab: t }, { replace: true });
  const finding = scan?.findings.find((f) => f.id === fid);
  const update = useCallback((f) => setScan((s) => ({ ...s, findings: s.findings.map((x) => (x.id === f.id ? f : x)) })), []);

  const act = async (kind) => {
    setBusy(true);
    try {
      const { data } = await api.post(`/scans/${sid}/findings/${fid}/${kind}`); update(data);
      if (kind === "verify") data.patch.verification.passed ? toast.success("Verified — the exploit path no longer exists in the patched code") : toast.error("Still vulnerable — the patched code re-triggers this rule");
      else toast.success("Patch marked as applied");
    } catch (e) { toast.error(errorText(e)); } finally { setBusy(false); }
  };

  if (!scan) return <Page variant={PAGE.detail}><div className="flex items-center gap-2 text-sm text-[var(--text-2)]"><Spinner />Loading finding…</div></Page>;
  if (!finding) return <Page variant={PAGE.detail}><div className="glass p-8 text-center" data-testid="finding-missing">Finding not found.<div className="mt-4"><button className="btn btn-ghost" onClick={() => nav(`/app/scan/${sid}/findings`)}>Back to findings</button></div></div></Page>;
  const node = finding.graph.nodes.find((n) => n.id === sel);

  return (
    <Page variant={PAGE.detail} testId="finding-detail-page">
      <nav className="mb-3 flex flex-wrap items-center gap-1.5 text-xs text-[var(--text-3)]" aria-label="Breadcrumb"><button className="hover:text-white" onClick={() => nav("/app")}>Command center</button><ChevronRight size={12} /><button className="hover:text-white" onClick={() => nav(`/app/scan/${sid}/findings`)} data-testid="finding-breadcrumb-findings">Findings</button><ChevronRight size={12} /><span className="text-[var(--text-2)]">{finding.cwe}</span></nav>
      <div className="flex flex-wrap items-center gap-3">
        <button className="btn btn-ghost btn-icon" onClick={() => nav(`/app/scan/${sid}/findings`)} aria-label="Back to findings" data-testid="finding-back-button"><ArrowLeft size={16} /></button>
        <SeverityBadge severity={finding.severity} testId="finding-severity" />
        <h1 className="order-last w-full text-2xl font-bold tracking-tight sm:order-none sm:w-auto sm:min-w-0 sm:flex-1 sm:truncate sm:text-3xl" data-testid="finding-title">{finding.title}</h1>
        <ConfidenceBadge level={finding.confidence} /><StatusBadge status={finding.status} testId="finding-status" />
      </div>
      <p className="mt-2 text-sm text-[var(--text-2)]"><span className="font-code text-[var(--text-3)]">{finding.cwe} · {finding.file}:{finding.line}</span> — {finding.desc}</p>
      <p className="mt-1 text-xs text-[var(--text-3)]">{finding.detection_method}</p>

      <div className="mt-6"><Segmented value={tab} onChange={setTab} options={TABS} testIdPrefix="finding-tab" /></div>

      <AnimatePresence mode="wait">
        <motion.div key={tab} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.3, ease: EASE }} className="mt-5 space-y-5">
          {tab === "graph" && (<>
            <ExploitGraph graph={finding.graph} selected={sel} onSelect={setSel} mode={mode} onMode={setMode} />
            <div className="grid gap-5 lg:grid-cols-[1fr_320px]">
              <NodePanel node={node} />
              <div className="glass p-5 text-sm" data-testid="graph-compare-panel">
                <Overline className="mb-3">{mode === "protected" ? "Protected path" : "Vulnerable path"}</Overline>
                {mode === "protected" ? <p className="text-[var(--text-2)]">The suggested patch node attaches to the sink; the reaching edge is <span className="text-[var(--emerald)]">blocked</span> and the impact node is marked <span className="text-[var(--emerald)]">prevented</span>. This is what the data-flow looks like <em>if</em> the patch is applied — verify it in the Patch tab.</p>
                  : <p className="text-[var(--text-2)]">Attacker-controlled input enters at the <span className="text-[var(--teal)]">entry point</span>, becomes a <span className="text-[var(--red)]">source</span>, travels through <span className="text-[var(--amber)]">tainted variables</span> and reaches a <span className="text-[var(--ember)]">dangerous sink</span> with no safeguard, causing the <span className="text-[var(--crimson)]">impact</span>.</p>}
              </div>
            </div>
          </>)}
          {tab === "code" && (
            <div className="glass p-5">
              <div className="mb-3 flex flex-wrap items-center gap-3"><Overline>{finding.file}</Overline><span className="badge sev-Critical" style={{ textTransform: "none", letterSpacing: 0 }}>red = sink line</span><span className="badge sev-High" style={{ textTransform: "none", letterSpacing: 0 }}>amber = tainted assignments</span></div>
              <CodeView code={finding.patch.original_code} badLine={finding.line} taintLines={finding.cl} testId="finding-code-view" />
              <p className="mt-4 text-sm text-[var(--text-2)]"><b className="text-white">Why it is risky:</b> {finding.desc}</p>
            </div>
          )}
          {tab === "patch" && <PatchReview finding={finding} file={finding.file} busy={busy} onApply={() => act("apply")} onVerify={() => act("verify")} />}
        </motion.div>
      </AnimatePresence>
    </Page>
  );
}
