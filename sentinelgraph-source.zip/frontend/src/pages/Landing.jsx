import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight, GitBranch, ScanLine, Wrench, ShieldCheck, TerminalSquare } from "lucide-react";
import { ShieldScene } from "@/components/hero/ShieldScene";
import { Brand, PeakButton, ScrambleText } from "@/components/kit";
import { EASE, usePrefersReducedMotion } from "@/lib/motion";
import { useAuth } from "@/context/AuthContext";

const reveal = (d) => ({ initial: { opacity: 0, y: 26, filter: "blur(6px)" }, animate: { opacity: 1, y: 0, filter: "blur(0px)" }, transition: { duration: 0.9, ease: EASE, delay: d } });

const pillars = [
  { icon: ScanLine, t: "Taint-aware detection", d: "Rules follow attacker-controlled input through variables into dangerous sinks — not just a grep." },
  { icon: GitBranch, t: "Exploit path graph", d: "Every finding becomes a playable data-flow graph: entry → source → variables → sink → impact." },
  { icon: Wrench, t: "Conservative patches", d: "Language-aware fixes you review, apply, and verify with a real re-analysis — never auto-claimed." },
];

export default function Landing() {
  const nav = useNavigate();
  const { user } = useAuth();
  const [pulse, setPulse] = useState(0);
  const [leaving, setLeaving] = useState(false);
  const reduced = usePrefersReducedMotion();

  const enter = () => {
    if (leaving) return;
    setPulse(Date.now()); setLeaving(true);
    setTimeout(() => nav(user ? "/app" : "/login"), reduced ? 0 : 950);
  };

  return (
    <div className="relative min-h-screen overflow-hidden bg-[var(--bg)]" data-testid="landing-page">
      <div className="absolute inset-0 grid-bg opacity-70" />
      <ShieldScene variant="hero" pulse={pulse} />
      <motion.div className="pointer-events-none absolute inset-0 z-20 bg-[var(--bg)]" initial={{ opacity: 0 }} animate={{ opacity: leaving ? 1 : 0 }} transition={{ duration: 0.7, ease: EASE, delay: leaving ? 0.3 : 0 }} />

      <header className="relative z-10 mx-auto flex max-w-[1280px] items-center justify-between px-5 pt-6 sm:px-8">
        <motion.div {...reveal(0.1)}><Brand /></motion.div>
        <motion.div {...reveal(0.2)} className="flex items-center gap-2">
          <button className="btn btn-ghost btn-sm" onClick={() => nav(user ? "/app" : "/login")} data-testid="landing-login-button">{user ? "Open console" : "Sign in"}</button>
        </motion.div>
      </header>

      <section className="relative z-10 mx-auto grid min-h-[86vh] max-w-[1280px] items-end px-5 pb-16 sm:px-8 lg:grid-cols-[minmax(0,560px)_1fr] lg:items-center">
        <div className="pt-[42vh] lg:pt-0">
          <motion.div {...reveal(0.35)} className="overline mb-4 flex items-center gap-2 text-[var(--peach)]"><span className="h-px w-8 bg-[var(--peach)]" />Static analysis · exploit graphs · verified patches</motion.div>
          <motion.h1 {...reveal(0.5)} className="text-4xl font-bold leading-[1.02] tracking-tight sm:text-5xl lg:text-6xl" data-testid="hero-title">
            <ScrambleText text="Find the bug." as="span" className="block" speed={30} />
            <ScrambleText text="See the attack." as="span" className="block" speed={30} />
            <ScrambleText text="Prove the fix." as="span" className="block bg-gradient-to-r from-[#FF7A45] via-[#FCB886] to-[#FFB347] bg-clip-text text-transparent" speed={30} />
          </motion.h1>
          <motion.p {...reveal(0.68)} className="mt-6 max-w-[48ch] text-base leading-relaxed text-[var(--text-2)] sm:text-lg">
            SentinelGraph turns source code into a security command center: taint-tracked detection, a cinematic exploit path for every finding, and patches that must survive re-analysis before they are called fixed.
          </motion.p>
          <motion.div {...reveal(0.85)} className="mt-9 flex flex-wrap items-center gap-3">
            <PeakButton className="px-6 py-3 text-[15px]" onClick={enter} testId="hero-scan-cta">Launch analysis <ArrowRight size={16} /></PeakButton>
            <span className="text-sm text-[var(--text-3)]">Python · JS/TS · Java · PHP · C/C++</span>
          </motion.div>
        </div>
        <div className="hidden lg:block" aria-hidden="true" />
      </section>

      <section className="relative z-10 mx-auto grid max-w-[1280px] gap-4 px-5 pb-20 sm:px-8 md:grid-cols-3">
        {pillars.map((p, i) => (
          <motion.div key={p.t} {...reveal(1 + i * 0.12)} className={`glass glass-hover p-6 ${i === 1 ? "md:-translate-y-6" : ""}`} style={{ borderTopColor: ["#FF7A45", "#FCB886", "#2FB9C6"][i], borderTopWidth: 2 }} data-testid={`landing-pillar-${i}`}>
            <div className="mb-4 flex items-center justify-between"><div className="grid h-10 w-10 place-items-center rounded-xl border border-[var(--ember-line)] bg-[var(--ember-soft)]"><p.icon size={18} className="text-[var(--peach)]" /></div><span className="font-code text-xs text-[var(--text-3)]">0{i + 1}</span></div>
            <h3 className="text-base font-semibold md:text-lg">{p.t}</h3>
            <p className="mt-2 text-sm leading-relaxed text-[var(--text-2)]">{p.d}</p>
          </motion.div>
        ))}
      </section>

      <div className="relative z-10 overflow-hidden border-y border-[var(--line)] bg-[rgba(40,21,17,.55)] py-3" aria-hidden="true">
        <motion.div className="flex w-max gap-10 whitespace-nowrap font-code text-xs uppercase tracking-[0.18em] text-[var(--text-3)]" animate={reduced ? {} : { x: ["0%", "-50%"] }} transition={{ duration: 28, repeat: Infinity, ease: "linear" }}>
          {[0, 1].map((k) => ["CWE-89 SQL injection", "CWE-78 Command injection", "CWE-22 Path traversal", "CWE-79 Cross-site scripting", "CWE-502 Unsafe deserialization", "CWE-120 Buffer overflow", "Taint tracking", "Exploit graph", "Verified patches"].map((t, i) => <span key={k + "-" + i} className="inline-flex items-center gap-10">{t}<span className="h-1 w-1 rounded-full bg-[var(--gold)]" /></span>))}
        </motion.div>
      </div>

      <footer className="relative z-10 mx-auto flex max-w-[1280px] flex-wrap items-center justify-between gap-3 border-t border-[var(--line)] px-5 py-6 text-xs text-[var(--text-3)] sm:px-8">
        <span className="inline-flex items-center gap-2"><ShieldCheck size={14} className="text-[var(--green)]" />Server-side accounts · Argon2id · httpOnly sessions</span>
        <span className="inline-flex items-center gap-2"><TerminalSquare size={14} className="text-[var(--ember)]" />Scan → patch → download → run, in one console.</span>
      </footer>
    </div>
  );
}
