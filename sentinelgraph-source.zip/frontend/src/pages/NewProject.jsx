import { useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Upload, Zap, FlaskConical, FileCode2 } from "lucide-react";
import { toast } from "sonner";
import { api, errorText } from "@/lib/api";
import { PAGE } from "@/lib/motion";
import { Page } from "@/components/Shell";
import { ErrorBox, Overline, Spinner, PeakButton } from "@/components/kit";

const LANGS = ["Python", "JavaScript", "TypeScript", "Java", "PHP", "C", "C++"];
const EXT = { py: "Python", js: "JavaScript", jsx: "JavaScript", ts: "TypeScript", tsx: "TypeScript", java: "Java", php: "PHP", c: "C", h: "C", cpp: "C++", cc: "C++", hpp: "C++" };
const DEMO = `from flask import request\nimport sqlite3\n\nusername = request.args.get("username")\nquery = "SELECT * FROM users WHERE name = '" + username + "'"\ncursor = sqlite3.connect("users.db").cursor()\ncursor.execute(query)\nprint(cursor.fetchall())`;

export default function NewProject() {
  const nav = useNavigate();
  const fileRef = useRef(null);
  const [form, setForm] = useState({ name: "", description: "", language: "Python", code: "", source_type: "paste" });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [drag, setDrag] = useState(false);
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const readFile = (f) => {
    if (!f) return;
    const ext = f.name.split(".").pop().toLowerCase();
    if (!EXT[ext]) { setErr("This language or vulnerability type is not supported in the current version."); return; }
    if (f.size > 400_000) { setErr("Files over 400 KB are not supported yet."); return; }
    const r = new FileReader();
    r.onload = () => { setForm((x) => ({ ...x, name: x.name || f.name, language: EXT[ext], code: String(r.result), source_type: "upload" })); setErr(""); };
    r.readAsText(f);
  };

  const submit = async () => {
    setErr("");
    if (!form.name.trim()) return setErr("Give your project a name.");
    if (!form.code.trim()) return setErr("The code is empty. Paste code or upload a file first.");
    setBusy(true);
    try {
      const { data: p } = await api.post("/projects", form);
      const { data: s } = await api.post(`/projects/${p.project_id}/scan`);
      toast.success("Analysis started");
      nav(`/app/scan/${s.scan_id}`);
    } catch (e) { setErr(errorText(e)); setBusy(false); }
  };

  const lines = form.code ? form.code.split("\n").length : 0;

  return (
    <Page variant={PAGE.create} testId="new-project-page">
      <Overline className="mb-2 text-[var(--peach)]">New analysis project</Overline>
      <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">Bring the code in</h1>
      <p className="mt-1 max-w-[60ch] text-sm text-[var(--text-2)]">Paste a file or drop one below. The language is detected from the file extension; the engine runs rule-based detection with intra-file taint tracking.</p>

      <div className="mt-8 grid gap-5 lg:grid-cols-[1fr_320px]">
        <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="glass p-6">
          <div className="grid gap-4 sm:grid-cols-[1fr_180px]">
            <div><label htmlFor="pn" className="label">Project name</label><input id="pn" className="input" value={form.name} onChange={set("name")} placeholder="e.g. Checkout service" data-testid="project-name-input" /></div>
            <div><label htmlFor="lg" className="label">Language</label>
              <select id="lg" className="input" value={form.language} onChange={set("language")} data-testid="project-language-select">{LANGS.map((l) => <option key={l}>{l}</option>)}</select></div>
          </div>
          <div className="mt-4"><label htmlFor="pd" className="label">Description <span className="text-[var(--text-3)]">(optional)</span></label><input id="pd" className="input" value={form.description} onChange={set("description")} data-testid="project-description-input" /></div>
          <div className="mt-4">
            <div className="flex items-center justify-between"><label htmlFor="cd" className="label">Source code</label><span className="font-code text-xs text-[var(--text-3)]">{lines} lines</span></div>
            <div onDragOver={(e) => { e.preventDefault(); setDrag(true); }} onDragLeave={() => setDrag(false)} onDrop={(e) => { e.preventDefault(); setDrag(false); readFile(e.dataTransfer.files[0]); }}
              className={`relative rounded-xl transition-shadow ${drag ? "shadow-[0_0_0_2px_var(--ember),0_0_30px_rgba(255,122,69,.35)]" : ""}`} data-testid="code-upload-area">
              <textarea id="cd" className="input scroll-thin" spellCheck={false} value={form.code} onChange={(e) => setForm((f) => ({ ...f, code: e.target.value, source_type: "paste" }))} placeholder={"Paste code here, or drop a file…"} data-testid="project-code-textarea" />
              {drag && <div className="pointer-events-none absolute inset-0 grid place-items-center rounded-xl bg-[rgba(255,122,69,.14)] font-head text-lg">Drop to load file</div>}
            </div>
          </div>
          {err && <div className="mt-4"><ErrorBox testId="project-error">{err}</ErrorBox></div>}
          <div className="mt-5 flex flex-wrap items-center gap-2">
            <input ref={fileRef} type="file" hidden accept=".py,.js,.jsx,.ts,.tsx,.java,.php,.c,.h,.cpp,.cc,.hpp" onChange={(e) => readFile(e.target.files[0])} data-testid="project-file-input" />
            <button className="btn btn-ghost" onClick={() => fileRef.current.click()} data-testid="project-upload-button"><Upload size={15} />Upload file</button>
            <button className="btn btn-ghost" onClick={() => { setForm({ name: "Demo: Flask login lookup", description: "Built-in vulnerable demo (demo data)", language: "Python", code: DEMO, source_type: "demo" }); setErr(""); }} data-testid="project-load-demo"><FlaskConical size={15} />Load demo code</button>
            <PeakButton className="ml-auto" onClick={submit} disabled={busy} testId="scan-start-button">{busy ? <Spinner /> : <Zap size={15} />}Analyze code</PeakButton>
          </div>
        </motion.div>

        <motion.aside initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.25 }} className="space-y-4">
          <div className="glass p-5">
            <Overline className="mb-3">What the engine checks</Overline>
            <ul className="space-y-2 text-sm text-[var(--text-2)]">
              {["SQL injection (CWE-89)", "Command injection (CWE-78)", "Path traversal (CWE-22)", "Cross-site scripting (CWE-79)", "Unsafe deserialization (CWE-502)", "Buffer overflow (CWE-120, C/C++)"].map((t) => <li key={t} className="flex items-center gap-2"><FileCode2 size={14} className="text-[var(--ember)]" />{t}</li>)}
            </ul>
          </div>
          <div className="glass p-5 text-sm text-[var(--text-2)]">
            <Overline className="mb-3 text-[var(--amber)]">Honest limits</Overline>
            A regex match is evidence, not proof of exploitability — and a clean scan is not proof of safety. Confidence levels tell you how much of the input→sink path was actually traced.
          </div>
        </motion.aside>
      </div>
    </Page>
  );
}
