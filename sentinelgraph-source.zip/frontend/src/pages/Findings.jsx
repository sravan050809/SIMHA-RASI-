import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { motion } from "framer-motion";
import { ChevronRight, BarChart3, History, Filter } from "lucide-react";
import { toast } from "sonner";
import { api, errorText } from "@/lib/api";
import { PAGE, fadeUp, stagger } from "@/lib/motion";
import { Page } from "@/components/Shell";
import { ConfidenceBadge, EmptyState, Overline, SeverityBadge, Spinner, StatusBadge, TiltCard } from "@/components/kit";

const ORDER = { Critical: 0, High: 1, Medium: 2, Low: 3 };

export default function Findings() {
  const { sid } = useParams();
  const nav = useNavigate();
  const [scan, setScan] = useState(null);
  const [sev, setSev] = useState("All");

  useEffect(() => { api.get(`/scans/${sid}`).then((r) => setScan(r.data)).catch((e) => toast.error(errorText(e))); }, [sid]);

  const list = useMemo(() => (scan?.findings || []).filter((f) => sev === "All" || f.severity === sev).sort((a, b) => ORDER[a.severity] - ORDER[b.severity] || a.line - b.line), [scan, sev]);
  if (!scan) return <Page variant={PAGE.findings}><div className="flex items-center gap-2 text-sm text-[var(--text-2)]"><Spinner />Loading findings…</div></Page>;
  const counts = scan.findings.reduce((a, f) => ({ ...a, [f.severity]: (a[f.severity] || 0) + 1 }), {});

  return (
    <Page variant={PAGE.findings} testId="findings-page">
      <nav className="mb-3 flex items-center gap-1.5 text-xs text-[var(--text-3)]" aria-label="Breadcrumb"><button className="hover:text-white" onClick={() => nav("/app")}>Command center</button><ChevronRight size={12} /><span>{scan.project_name}</span><ChevronRight size={12} /><span className="text-[var(--text-2)]">Findings</span></nav>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div><Overline className="mb-2 text-[var(--ice)]">Vulnerability findings</Overline><h1 className="text-3xl font-bold tracking-tight sm:text-4xl">{scan.findings.length} finding{scan.findings.length === 1 ? "" : "s"}</h1><p className="mt-1 text-sm text-[var(--text-2)]">{scan.project_name} · {scan.language} · rule-based detection with taint tracking</p></div>
        <div className="flex gap-2"><button className="btn btn-primary btn-sm" onClick={() => nav(`/app/scan/${sid}/results`)} data-testid="findings-results-button"><BarChart3 size={14} />Results</button><button className="btn btn-ghost btn-sm" onClick={() => nav("/app/history")} data-testid="findings-history-button"><History size={14} />All scans</button></div>
      </div>

      {scan.findings.length > 0 && (
        <div className="mt-6 flex flex-wrap items-center gap-2" role="group" aria-label="Filter by severity" data-testid="findings-filter">
          <Filter size={14} className="text-[var(--text-3)]" />
          {["All", "Critical", "High", "Medium", "Low"].map((s) => (
            <button key={s} onClick={() => setSev(s)} aria-pressed={sev === s} data-testid={`findings-filter-${s}`} className={`badge transition-colors ${sev === s ? "badge-cyan" : "badge-neutral hover:text-white"}`} style={{ padding: "5px 12px", textTransform: "none", letterSpacing: 0, fontSize: 12 }}>{s}{s !== "All" && <span className="opacity-70">· {counts[s] || 0}</span>}</button>
          ))}
        </div>
      )}

      <div className="mt-6">
        {!scan.findings.length ? <EmptyState title="No supported vulnerabilities found" hint="The rule set matched nothing in this file. Treat it as a clean pattern scan, not as a security guarantee." testId="findings-empty" /> : (
          <motion.ol variants={stagger(0.08)} initial="hidden" animate="show" className="space-y-3" data-testid="findings-list">
            {list.map((f) => (
              <motion.li key={f.id} variants={fadeUp}>
                <TiltCard max={2} as="button" onClick={() => nav(`/app/scan/${sid}/finding/${f.id}`)} className="group block w-full p-5 text-left" data-testid={`finding-item-${f.id}`}>
                  <div className="flex flex-wrap items-center gap-3">
                    <SeverityBadge severity={f.severity} />
                    <h3 className="min-w-0 flex-1 truncate text-base font-semibold">{f.title}</h3>
                    <ConfidenceBadge level={f.confidence} />
                    <StatusBadge status={f.status} />
                    <ChevronRight size={16} className="text-[var(--text-3)] transition-transform group-hover:translate-x-1 group-hover:text-[var(--cyan)]" />
                  </div>
                  <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-[var(--text-3)]"><span className="font-code">{f.cwe}</span><span className="font-code">{f.file}:{f.line}</span><span>{f.detection_method}</span></div>
                  <pre className="code-surface mt-3 overflow-x-auto px-3 py-2 text-[12px] text-[var(--text-2)]">{f.snippet}</pre>
                </TiltCard>
              </motion.li>
            ))}
          </motion.ol>
        )}
      </div>
    </Page>
  );
}
