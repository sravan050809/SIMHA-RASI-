import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { Eye, GitBranch, FileCode2, Wrench, ChevronDown, FileDown, Lock, ShieldOff, ArrowRight } from "lucide-react";
import { API, fmtDate, riskScore, LANG_EXT } from "@/lib/api";
import { EASE, fadeUp, stagger } from "@/lib/motion";
import { Brand, ConfidenceBadge, Overline, SeverityBadge, Spinner, StatusBadge, Segmented, CountUp } from "@/components/kit";
import { ExploitGraph, NODE_COLOR } from "@/components/ExploitGraph";
import { CodeView, PatchReview } from "@/components/PatchReview";

const TABS = [{ value: "graph", label: "Exploit graph", icon: <GitBranch size={13} /> }, { value: "code", label: "Vulnerable code", icon: <FileCode2 size={13} /> }, { value: "patch", label: "Patch", icon: <Wrench size={13} /> }];
const SEV_COLOR = { Critical: "var(--red)", High: "var(--amber)", Medium: "var(--yellow)", Low: "var(--blue)" };

function Frame({ children }) {
  return (
    <div className="relative min-h-screen">
      <div className="pointer-events-none fixed inset-0 z-0 grid-bg opacity-60" />
      <header className="relative z-10 border-b border-[var(--line)] bg-[rgba(21,10,7,.85)] backdrop-blur-xl" data-testid="shared-header">
        <div className="mx-auto flex max-w-[1200px] flex-wrap items-center gap-3 px-4 py-4 sm:px-8">
          <Link to="/" className="inline-flex" data-testid="shared-brand-link"><Brand /></Link>
          <span className="badge badge-neutral inline-flex items-center gap-1.5" style={{ textTransform: "none", letterSpacing: 0 }} data-testid="shared-readonly-badge"><Eye size={12} />Read-only shared view</span>
          <Link to="/login" className="btn btn-ghost btn-sm ml-auto" data-testid="shared-open-app-link">Open SentinelGraph<ArrowRight size={14} /></Link>
        </div>
      </header>
      <main className="relative z-10 mx-auto max-w-[1200px] px-4 pb-24 pt-8 sm:px-8">{children}</main>
    </div>
  );
}

function FindingRow({ f, open, onToggle }) {
  const [tab, setTab] = useState("graph");
  const [sel, setSel] = useState(null);
  const [mode, setMode] = useState("vulnerable");
  const node = f.graph.nodes.find((n) => n.id === sel);
  const col = node && NODE_COLOR[node.node_type];
  return (
    <li className="py-1">
      <button className="group flex w-full flex-wrap items-center gap-3 py-3 text-left" onClick={onToggle} aria-expanded={open} data-testid={`shared-finding-${f.id}`}>
        <SeverityBadge severity={f.severity} /><span className="min-w-0 flex-1 truncate font-medium">{f.title}</span><span className="font-code text-xs text-[var(--text-3)]">{f.cwe} · L{f.line}</span><ConfidenceBadge level={f.confidence} /><StatusBadge status={f.patch.status} />
        <ChevronDown size={16} className={`text-[var(--text-3)] transition-transform group-hover:text-[var(--ember)] ${open ? "rotate-180" : ""}`} />
      </button>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.35, ease: EASE }} className="overflow-hidden" data-testid={`shared-finding-detail-${f.id}`}>
            <div className="space-y-4 pb-5 pt-1">
              <p className="text-sm text-[var(--text-2)]">{f.desc}</p>
              <Segmented value={tab} onChange={setTab} options={TABS} testIdPrefix={`shared-tab-${f.id}`} />
              {tab === "graph" && (<>
                <ExploitGraph graph={f.graph} selected={sel} onSelect={setSel} mode={mode} onMode={setMode} />
                {node ? (
                  <div className="glass p-5" style={{ borderColor: `${col}55` }} data-testid="shared-node-panel">
                    <div className="flex flex-wrap items-center gap-3"><span className="badge" style={{ color: col, borderColor: `${col}66`, background: `${col}1a` }}>{node.node_type}</span><h3 className="text-lg font-semibold">{node.label}</h3><span className="ml-auto font-code text-xs text-[var(--text-3)]">{node.file_path} · line {node.line_number}</span></div>
                    <p className="mt-3 text-sm leading-relaxed text-[var(--text-2)]">{node.explanation}</p>
                    <pre className="code-surface mt-3 overflow-x-auto px-3 py-2 text-[12px]">{node.code_snippet || "—"}</pre>
                  </div>
                ) : <p className="text-xs text-[var(--text-3)]">Select a node or press Play to walk the exploit path.</p>}
              </>)}
              {tab === "code" && <div className="glass p-5"><Overline className="mb-3">{f.file}</Overline><CodeView code={f.patch.original_code} badLine={f.line} taintLines={f.cl} testId={`shared-code-${f.id}`} /></div>}
              {tab === "patch" && <PatchReview finding={f} file={f.file} />}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </li>
  );
}

export default function SharedScan() {
  const { token } = useParams();
  const [scan, setScan] = useState(null);
  const [err, setErr] = useState("");
  const [open, setOpen] = useState(null);
  useEffect(() => {
    fetch(`${API}/share/${token}`).then(async (r) => { if (!r.ok) throw new Error((await r.json()).detail || "Link not found"); return r.json(); }).then(setScan).catch((e) => setErr(e.message));
  }, [token]);

  if (err) return <Frame><div className="glass mx-auto mt-16 max-w-md p-10 text-center" data-testid="shared-error"><ShieldOff size={36} className="mx-auto text-[var(--red)]" /><h1 className="mt-4 text-2xl font-bold">Link unavailable</h1><p className="mt-2 text-sm text-[var(--text-2)]">{err}</p><Link to="/" className="btn btn-ghost btn-sm mt-6">Go to SentinelGraph</Link></div></Frame>;
  if (!scan) return <Frame><div className="flex items-center gap-2 text-sm text-[var(--text-2)]"><Spinner />Loading shared scan…</div></Frame>;

  const F = scan.findings; const sev = { Critical: 0, High: 0, Medium: 0, Low: 0 }; F.forEach((f) => sev[f.severity]++);
  const score = riskScore(scan.summary); const fixed = F.filter((f) => f.status === "Fixed").length;
  const ext = LANG_EXT[scan.language] || "txt"; const col = score > 66 ? "var(--red)" : score > 33 ? "var(--amber)" : "var(--green)";
  const dl = `${API}/share/${token}/download`;

  return (
    <Frame>
      <motion.div variants={stagger(0.08)} initial="hidden" animate="show" data-testid="shared-scan-page">
        <motion.div variants={fadeUp} className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <Overline className="mb-2 text-[var(--peach)]">Shared by {scan.shared_by}</Overline>
            <h1 className="text-3xl font-bold tracking-tight sm:text-4xl" data-testid="shared-project-name">{scan.project_name}</h1>
            <p className="mt-1 text-sm text-[var(--text-2)]">{scan.language} · {fmtDate(scan.started_at)} · <StatusBadge status={scan.status} /></p>
            {scan.description && <p className="mt-2 max-w-2xl text-sm text-[var(--text-3)]">{scan.description}</p>}
          </div>
          <div className="flex flex-wrap gap-2">
            <a href={`${dl}/code`} className="btn btn-ghost btn-sm" data-testid="shared-download-code"><FileCode2 size={14} />main.{ext}</a>
            {F.length > 0 && <a href={`${dl}/corrected`} className="btn btn-ghost btn-sm" data-testid="shared-download-corrected"><FileDown size={14} />Corrected file</a>}
          </div>
        </motion.div>

        <div className="mt-8 grid gap-4 md:grid-cols-3">
          <motion.div variants={fadeUp} className="glass p-5" data-testid="shared-risk-card"><Overline>Risk score (0 = clean)</Overline><div className="mt-2 font-head text-5xl font-bold" style={{ color: col }}><CountUp value={score} /></div><div className="progress-track mt-4"><motion.div className="h-full rounded-full" style={{ background: col }} initial={{ width: 0 }} animate={{ width: `${score}%` }} transition={{ duration: 1 }} /></div></motion.div>
          <motion.div variants={fadeUp} className="glass p-5" data-testid="shared-severity-card"><Overline className="mb-4">By severity</Overline>
            {Object.entries(sev).map(([k, v], i) => <div key={k} className="mb-3 flex items-center gap-3"><SeverityBadge severity={k} /><div className="progress-track flex-1"><motion.div className="h-full rounded-full" style={{ background: SEV_COLOR[k] }} initial={{ width: 0 }} animate={{ width: `${F.length ? (v / F.length) * 100 : 0}%` }} transition={{ duration: 0.9, delay: 0.3 + i * 0.12 }} /></div><span className="w-5 text-right font-code text-sm">{v}</span></div>)}
          </motion.div>
          <motion.div variants={fadeUp} className="glass p-5" data-testid="shared-patch-card"><Overline className="mb-3">Patch verification</Overline><div className="font-head text-5xl font-semibold text-[var(--emerald)]"><CountUp value={fixed} /></div><div className="text-sm text-[var(--text-2)]">of {F.length} verified by re-analysis</div></motion.div>
        </div>

        <motion.div variants={fadeUp} className="glass mt-5 p-5" data-testid="shared-findings">
          <div className="mb-2 flex items-center justify-between gap-2"><Overline>Findings ({F.length})</Overline><span className="inline-flex items-center gap-1 text-xs text-[var(--text-3)]"><Lock size={11} />Actions disabled in shared view</span></div>
          {!F.length ? <p className="py-6 text-center text-sm text-[var(--text-2)]">Clean pattern scan — no supported vulnerabilities found.</p> : (
            <ul className="divide-y divide-[var(--line)]">{F.map((f) => <FindingRow key={f.id} f={f} open={open === f.id} onToggle={() => setOpen(open === f.id ? null : f.id)} />)}</ul>
          )}
        </motion.div>

        <motion.div variants={fadeUp} className="glass mt-5 p-5" data-testid="shared-source">
          <Overline className="mb-3">Full source · main.{ext}</Overline>
          <CodeView code={scan.code} badLine={-1} taintLines={F.map((f) => f.line)} testId="shared-source-code" />
        </motion.div>
      </motion.div>
    </Frame>
  );
}
