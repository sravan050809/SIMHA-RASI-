import { useCallback, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Plus, Play, Trash2, FolderGit2, Activity, ShieldCheck, Bug, Radar, FlaskConical, Download } from "lucide-react";
import { toast } from "sonner";
import { api, errorText, fmtDate, riskScore } from "@/lib/api";
import { PAGE, fadeUp, stagger } from "@/lib/motion";
import { Page } from "@/components/Shell";
import { CountUp, EmptyState, Overline, StatusBadge, TiltCard, Spinner, PeakButton } from "@/components/kit";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";

const SEV_COLOR = { Critical: "var(--red)", High: "var(--amber)", Medium: "var(--yellow)", Low: "var(--blue)" };

function Stat({ icon: Icon, label, value, tone = "cyan", testId }) {
  const col = { cyan: "var(--ember)", red: "var(--red)", emerald: "var(--emerald)", violet: "var(--peach)" }[tone];
  return (
    <motion.div variants={fadeUp} className="glass relative overflow-hidden p-5" data-testid={testId}>
      <div className="absolute -right-6 -top-6 h-24 w-24 rounded-full opacity-[0.12] blur-2xl" style={{ background: col }} />
      <div className="flex items-center justify-between"><Overline>{label}</Overline><Icon size={16} style={{ color: col }} /></div>
      <div className="mt-3 font-head text-4xl font-semibold tracking-tight" style={{ color: col }}><CountUp value={value} /></div>
    </motion.div>
  );
}

function Trend({ points }) {
  if (!points.length) return <div className="grid h-28 place-items-center text-sm text-[var(--text-3)]">Run scans to build a risk trend.</div>;
  const W = 420, H = 110, pad = 8;
  const xs = points.map((_, i) => pad + (i / Math.max(1, points.length - 1)) * (W - pad * 2));
  const ys = points.map((p) => H - pad - (p.risk / 100) * (H - pad * 2));
  const d = xs.map((x, i) => `${i ? "L" : "M"}${x},${ys[i]}`).join(" ");
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="h-28 w-full" role="img" aria-label="Risk trend across recent scans">
      <defs><linearGradient id="trend-fill" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#FF7A45" stopOpacity=".35" /><stop offset="1" stopColor="#FF7A45" stopOpacity="0" /></linearGradient></defs>
      {[25, 50, 75].map((g) => <line key={g} x1={pad} x2={W - pad} y1={H - pad - (g / 100) * (H - pad * 2)} y2={H - pad - (g / 100) * (H - pad * 2)} stroke="rgba(255,255,255,.06)" />)}
      <motion.path d={`${d} L${xs[xs.length - 1]},${H - pad} L${xs[0]},${H - pad} Z`} fill="url(#trend-fill)" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6 }} />
      <motion.path d={d} fill="none" stroke="#FF7A45" strokeWidth="2" strokeLinecap="round" initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 1.2, ease: "easeOut", delay: 0.2 }} />
      {xs.map((x, i) => <motion.circle key={i} cx={x} cy={ys[i]} r="3.5" fill={points[i].risk > 66 ? "var(--red)" : points[i].risk > 33 ? "var(--amber)" : "var(--green)"} initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.4 + i * 0.08 }}><title>{points[i].project}: risk {points[i].risk}</title></motion.circle>)}
    </svg>
  );
}

export default function Dashboard() {
  const nav = useNavigate();
  const [projects, setProjects] = useState(null);
  const [stats, setStats] = useState(null);
  const [del, setDel] = useState(null);
  const [starting, setStarting] = useState("");

  const load = useCallback(async () => {
    try {
      const [p, s] = await Promise.all([api.get("/projects"), api.get("/dashboard/stats")]);
      setProjects(p.data); setStats(s.data);
    } catch (e) { toast.error(errorText(e)); setProjects([]); }
  }, []);
  useEffect(() => { load(); }, [load]);

  const run = async (pid) => {
    setStarting(pid);
    try { const { data } = await api.post(`/projects/${pid}/scan`); nav(`/app/scan/${data.scan_id}`); }
    catch (e) { toast.error(errorText(e)); setStarting(""); }
  };
  const remove = async () => {
    try { await api.delete(`/projects/${del.project_id}`); toast.success("Project deleted"); setDel(null); load(); }
    catch (e) { toast.error(errorText(e)); }
  };

  const sevTotal = stats ? Object.values(stats.severity).reduce((a, b) => a + b, 0) : 0;

  return (
    <Page variant={PAGE.dashboard} testId="dashboard-page">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <Overline className="mb-2 text-[var(--peach)]">Command center</Overline>
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">Security posture</h1>
          <p className="mt-1 text-sm text-[var(--text-2)]">Everything below is computed from your own projects and scans — nothing simulated.</p>
        </div>
        <div className="flex flex-wrap gap-3">
          <a href={`${process.env.REACT_APP_BACKEND_URL}/api/export/source`} download="sentinelgraph-source.zip"
             className="inline-flex items-center gap-2 rounded-full border border-[var(--line)] px-5 py-2.5 text-sm font-semibold text-[var(--text-1)] transition-[background-color,transform] hover:bg-white/5 active:scale-95"
             data-testid="dashboard-download-source-link"><Download size={16} />Download source</a>
          <PeakButton onClick={() => nav("/app/new")} testId="dashboard-new-project-button"><Plus size={16} />New project</PeakButton>
        </div>
      </div>

      {!stats ? <div className="mt-10 flex items-center gap-2 text-sm text-[var(--text-2)]" data-testid="dashboard-loading"><Spinner />Loading telemetry…</div> : (
        <motion.div variants={stagger(0.07)} initial="hidden" animate="show" className="mt-8 space-y-6">
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <Stat icon={FolderGit2} label="Projects" value={stats.projects} testId="stat-projects" />
            <Stat icon={Radar} label="Scans run" value={stats.scans} tone="violet" testId="stat-scans" />
            <Stat icon={Bug} label="Findings" value={stats.findings} tone="red" testId="stat-findings" />
            <Stat icon={ShieldCheck} label="Verified fixes" value={stats.verified} tone="emerald" testId="stat-verified" />
          </div>

          <div className="grid gap-4 lg:grid-cols-[1.4fr_1fr_1fr]">
            <motion.div variants={fadeUp} className="glass p-5" data-testid="dashboard-trend-card">
              <div className="flex items-center justify-between"><Overline>Risk trend</Overline><span className="text-xs text-[var(--text-3)]">last {stats.trend.length} completed scans</span></div>
              <Trend points={stats.trend} />
            </motion.div>
            <motion.div variants={fadeUp} className="glass p-5" data-testid="dashboard-severity-card">
              <Overline className="mb-4">Findings by severity</Overline>
              <div className="space-y-3">
                {Object.entries(stats.severity).map(([k, v], i) => (
                  <div key={k} className="flex items-center gap-3 text-sm">
                    <span className="w-16 text-[var(--text-2)]">{k}</span>
                    <div className="progress-track flex-1"><motion.div className="h-full rounded-full" style={{ background: SEV_COLOR[k] }} initial={{ width: 0 }} animate={{ width: `${sevTotal ? (v / sevTotal) * 100 : 0}%` }} transition={{ duration: 0.9, delay: 0.3 + i * 0.1, ease: "easeOut" }} /></div>
                    <span className="w-6 text-right font-code text-xs">{v}</span>
                  </div>
                ))}
              </div>
            </motion.div>
            <motion.div variants={fadeUp} className="glass p-5" data-testid="dashboard-activity-card">
              <Overline className="mb-4">Live activity</Overline>
              {!stats.activity.length ? <p className="text-sm text-[var(--text-3)]">No activity yet.</p> : (
                <ol className="relative ml-2 space-y-3 border-l border-[var(--line)] pl-4 text-sm">
                  {stats.activity.slice(0, 6).map((a, i) => (
                    <motion.li key={i} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 + i * 0.07 }} className="relative">
                      <span className={`absolute -left-[21px] top-1.5 h-2.5 w-2.5 rounded-full ${a.status === "verified" ? "bg-[var(--emerald)] shadow-[0_0_10px_var(--emerald)]" : a.status === "done" ? "bg-[var(--ember)]" : a.status === "failed" ? "bg-[var(--red)]" : "bg-[var(--text-3)]"}`} />
                      <button className="text-left hover:text-white" onClick={() => nav(a.status === "running" ? `/app/scan/${a.scan_id}` : `/app/scan/${a.scan_id}/results`)}>
                        <div className="font-medium">{a.status === "verified" ? `Patch verified · ${a.title}` : `Scan ${a.status} · ${a.findings} finding${a.findings === 1 ? "" : "s"}`}</div>
                        <div className="text-xs text-[var(--text-3)]">{a.project} · {fmtDate(a.at)}</div>
                      </button>
                    </motion.li>
                  ))}
                </ol>
              )}
            </motion.div>
          </div>

          <motion.div variants={fadeUp}>
            <div className="mb-3 flex items-center gap-2"><Overline>Projects</Overline><span className="font-code text-xs text-[var(--text-3)]">({projects?.length ?? 0})</span></div>
            {projects && !projects.length ? (
              <EmptyState icon={FlaskConical} title="No projects yet" hint="Create a project by pasting code or uploading a file — you'll get a scan, exploit graphs and patch suggestions." testId="projects-empty"
                action={<PeakButton onClick={() => nav("/app/new")} testId="projects-empty-create">Create your first project</PeakButton>} />
            ) : (
              <motion.div variants={stagger(0.06)} initial="hidden" animate="show" className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                {(projects || []).map((p) => {
                  const s = p.last_scan?.summary; const risk = riskScore(s);
                  return (
                    <motion.div key={p.project_id} variants={fadeUp}>
                      <TiltCard className="group relative flex h-full flex-col p-5" data-testid={`project-card-${p.project_id}`}>
                        <div className="flex items-start justify-between gap-3">
                          <div className="min-w-0">
                            <h3 className="truncate text-base font-semibold" title={p.name}>{p.name}</h3>
                            <div className="mt-1 text-xs text-[var(--text-3)]">{p.language} · {p.source_type}{p.source_type === "demo" && <span className="ml-1 text-[var(--amber)]">· demo data</span>} · {fmtDate(p.created_at)}</div>
                          </div>
                          <StatusBadge status={p.status} testId={`project-status-${p.project_id}`} />
                        </div>
                        <div className="mt-5 flex items-end gap-6">
                          <div><div className="font-head text-3xl font-semibold" style={{ color: s?.critical ? "var(--red)" : "var(--text)" }}><CountUp value={s?.critical || 0} /></div><div className="overline">critical</div></div>
                          <div><div className="font-head text-3xl font-semibold text-[var(--peach)]"><CountUp value={s?.total || 0} /></div><div className="overline">findings</div></div>
                          <div className="ml-auto text-right"><div className="font-head text-xl font-semibold" style={{ color: risk > 66 ? "var(--red)" : risk > 33 ? "var(--amber)" : s ? "var(--green)" : "var(--text-3)" }}>{s ? risk : "—"}</div><div className="overline">risk</div></div>
                        </div>
                        <div className="mt-5 flex items-center gap-2 border-t border-[var(--line)] pt-4">
                          <button className="btn btn-primary btn-sm" onClick={() => run(p.project_id)} disabled={starting === p.project_id} data-testid={`project-scan-${p.project_id}`}>{starting === p.project_id ? <Spinner size={14} /> : <Play size={14} />}Scan</button>
                          {p.last_scan && <button className="btn btn-ghost btn-sm" onClick={() => nav(`/app/scan/${p.last_scan.scan_id}/results`)} data-testid={`project-results-${p.project_id}`}><Activity size={14} />Results</button>}
                          <button className="btn btn-ghost btn-icon ml-auto" aria-label={`Delete ${p.name}`} onClick={() => setDel(p)} data-testid={`project-delete-${p.project_id}`}><Trash2 size={15} /></button>
                        </div>
                      </TiltCard>
                    </motion.div>
                  );
                })}
              </motion.div>
            )}
          </motion.div>
        </motion.div>
      )}

      <AlertDialog open={!!del} onOpenChange={(o) => !o && setDel(null)}>
        <AlertDialogContent className="glass border-[var(--line-strong)]" data-testid="delete-dialog">
          <AlertDialogHeader><AlertDialogTitle>Delete “{del?.name}”?</AlertDialogTitle><AlertDialogDescription>This removes the project and all of its scans, findings and patches. This cannot be undone.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel className="btn btn-ghost" data-testid="delete-cancel">Cancel</AlertDialogCancel><AlertDialogAction className="btn btn-danger" onClick={remove} data-testid="delete-confirm">Delete project</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Page>
  );
}
