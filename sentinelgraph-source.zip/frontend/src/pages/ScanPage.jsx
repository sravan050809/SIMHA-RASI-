import { useCallback, useEffect, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { XCircle, RotateCcw, ArrowRight, BarChart3, CheckCircle2, AlertTriangle, FileDown, FileCode2, TerminalSquare, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { api, errorText, fmtTime, LANG_EXT, downloadFile } from "@/lib/api";
import { PAGE, usePrefersReducedMotion } from "@/lib/motion";
import { Page } from "@/components/Shell";
import { Overline, Spinner, StatusBadge, Burst, ScrambleText, PeakButton } from "@/components/kit";

const STAGES = ["Parsing source code", "Detecting language", "Running static vulnerability rules", "Building data-flow graph", "Correlating attacker-controlled paths", "Synthesizing conservative patches", "Saving results"];
const LVL = { INFO: "badge-cyan", WARN: "badge-amber", ERROR: "badge-red", OK: "badge-emerald" };

export default function ScanPage() {
  const { sid } = useParams();
  const nav = useNavigate();
  const [scan, setScan] = useState(null);
  const [code, setCode] = useState([]);
  const [error, setError] = useState("");
  const logRef = useRef(null);
  const reduced = usePrefersReducedMotion();

  const fetchScan = useCallback(async () => {
    try { const { data } = await api.get(`/scans/${sid}`); setScan(data); return data; }
    catch (e) { setError(errorText(e)); return null; }
  }, [sid]);

  useEffect(() => {
    let timer; let alive = true;
    (async () => {
      const s = await fetchScan(); if (!s || !alive) return;
      try { const { data } = await api.get(`/projects/${s.project_id}`); if (alive) setCode(data.code.split("\n")); } catch { /* project may be deleted */ }
      const poll = async () => { const d = await fetchScan(); if (alive && d?.status === "running") timer = setTimeout(poll, 500); };
      if (s.status === "running") timer = setTimeout(poll, 500);
    })();
    return () => { alive = false; clearTimeout(timer); };
  }, [fetchScan]);

  useEffect(() => { if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight; }, [scan?.logs?.length]);

  const cancel = async () => { try { await api.post(`/scans/${sid}/cancel`); toast("Scan cancelled"); nav("/app"); } catch (e) { toast.error(errorText(e)); } };
  const retry = async () => { try { const { data } = await api.post(`/projects/${scan.project_id}/scan`); nav(`/app/scan/${data.scan_id}`); } catch (e) { toast.error(errorText(e)); } };

  if (error) return <Page variant={PAGE.scan}><div className="glass p-8 text-center" data-testid="scan-error"><p className="text-red-200">{error}</p><button className="btn btn-ghost mt-4" onClick={() => nav("/app")}>Back to command center</button></div></Page>;
  if (!scan) return <Page variant={PAGE.scan}><div className="flex items-center gap-2 text-sm text-[var(--text-2)]"><Spinner />Connecting to analysis…</div></Page>;

  const running = scan.status === "running"; const done = scan.status === "done"; const failed = scan.status === "failed" || scan.status === "cancelled";
  const stageIdx = Math.max(0, STAGES.indexOf(scan.stage));
  const count = scan.findings?.length || 0;
  const hitLines = new Set((scan.findings || []).flatMap((f) => [f.line, ...(f.cl || [])]));
  const ext = LANG_EXT[scan.language] || "txt";
  const dl = (kind, name) => downloadFile(`/scans/${sid}/download/${kind}`, name).then(() => toast.success(`${name} downloaded`)).catch((e) => toast.error(errorText(e)));

  return (
    <Page variant={PAGE.scan} testId="scan-page">
      <Burst trigger={done ? sid : 0} palette={count ? ["#FF5A4D", "#FFB347", "#FCB886", "#E0784F"] : ["#3FD0AB", "#2FB9C6", "#FCB886"]} />
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <Overline className="mb-2 text-[var(--peach)]">{running ? "Analysis in progress" : "Analysis"}</Overline>
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">{scan.project_name}</h1>
          <div className="mt-1 text-sm text-[var(--text-2)]">{scan.language} · scan <span className="font-code">{scan.scan_id}</span></div>
        </div>
        <StatusBadge status={scan.status} testId="scan-status-badge" />
      </div>

      <div className="mt-8 grid gap-5 lg:grid-cols-[1.3fr_1fr]">
        {/* code surface + scanning beam */}
        <div className="glass scanlines relative overflow-hidden p-0" data-testid="scan-code-surface">
          <div className="flex items-center justify-between border-b border-[var(--line)] px-4 py-2.5"><Overline>Source surface</Overline><span className="font-code text-xs text-[var(--text-3)]">{code.length} lines</span></div>
          <div className="code-surface scroll-thin relative max-h-[460px] rounded-none border-0">
            {running && !reduced && <motion.div aria-hidden="true" className="pointer-events-none absolute left-0 right-0 z-10 h-10" style={{ background: "linear-gradient(180deg, rgba(255,122,69,0) 0%, rgba(255,122,69,.3) 50%, rgba(255,122,69,0) 100%)", boxShadow: "0 0 24px rgba(255,122,69,.5)" }} animate={{ top: ["0%", "100%"] }} transition={{ duration: 2.2, repeat: Infinity, ease: "linear" }} />}
            {code.map((l, i) => (
              <div key={i} style={running && !reduced ? { animationDelay: `${Math.min(i * 16, 1100)}ms` } : undefined}
                className={`code-line ${running && !reduced ? "flicker-in" : ""} ${hitLines.has(i + 1) ? (scan.findings.some((f) => f.line === i + 1) ? "is-bad" : "is-taint") : ""}`}><span className="ln">{i + 1}</span><span>{l || " "}</span></div>
            ))}
            {!code.length && <div className="p-6 text-sm text-[var(--text-3)]">Loading source…</div>}
          </div>
        </div>

        <div className="space-y-5">
          <div className="glass p-5" data-testid="scan-progress-card">
            <div className="flex items-center gap-4">
              {running && !reduced && <div className="radar" aria-hidden="true" />}
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between text-sm">
                  <span className="inline-flex items-center gap-2 font-medium" data-testid="scan-stage-text">{running && <Spinner size={14} className="text-[var(--ember)]" />}<ScrambleText text={scan.stage} trigger={scan.stage} speed={18} /></span>
                  <span className="font-code text-[var(--ember)]" data-testid="scan-progress-percent">{scan.progress}%</span>
                </div>
                <div className="progress-track mt-3" role="progressbar" aria-valuenow={scan.progress} aria-valuemin={0} aria-valuemax={100} data-testid="scan-progress-bar"><div className={`progress-fill ${done ? "done" : failed ? "failed" : ""}`} style={{ width: `${scan.progress}%` }} /></div>
              </div>
            </div>
            <ol className="mt-5 space-y-2">
              {STAGES.map((st, i) => { const state = done ? "done" : i < stageIdx ? "done" : i === stageIdx && running ? "active" : "todo"; return (
                <li key={st} className={`flex items-center gap-2.5 text-[13px] ${state === "todo" ? "text-[var(--text-3)]" : state === "active" ? "text-white" : "text-[var(--text-2)]"}`} data-testid={`scan-stage-${i}`}>
                  <span className={`grid h-4 w-4 place-items-center rounded-full border ${state === "done" ? "border-[var(--emerald)] bg-[rgba(47,185,198,.18)]" : state === "active" ? "border-[var(--ember)] shadow-[0_0_10px_var(--ember)]" : "border-[var(--line-strong)]"}`}>{state === "done" && <span className="h-1.5 w-1.5 rounded-full bg-[var(--emerald)]" />}{state === "active" && <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[var(--ember)]" />}</span>{st}
                </li>); })}
            </ol>
            <div className="mt-5 flex items-center gap-3 border-t border-[var(--line)] pt-4">
              <div><div className="font-head text-3xl font-semibold" style={{ color: count ? "var(--red)" : "var(--text)" }} data-testid="scan-findings-count">{count}</div><div className="overline">findings</div></div>
              <div className="ml-auto flex flex-wrap gap-2">
                {running && <button className="btn btn-ghost btn-sm" onClick={cancel} data-testid="scan-cancel-button"><XCircle size={14} />Cancel</button>}
                {failed && <button className="btn btn-ghost btn-sm" onClick={retry} data-testid="scan-retry-button"><RotateCcw size={14} />Retry</button>}
              </div>
            </div>
          </div>

          <div className="glass p-5" data-testid="scan-log-card">
            <Overline className="mb-3">Live log</Overline>
            <div ref={logRef} className="scroll-thin max-h-56 space-y-1 overflow-auto font-code text-[12px]">
              <AnimatePresence initial={false}>
                {scan.logs.map((l, i) => (
                  <motion.div key={i} initial={{ opacity: 0, x: -6 }} animate={{ opacity: 1, x: 0 }} className="flex items-start gap-2">
                    <span className="text-[var(--text-3)]">{fmtTime(l.created_at)}</span><span className={`badge ${LVL[l.log_level] || "badge-neutral"}`} style={{ padding: "0 6px", fontSize: 10 }}>{l.log_level}</span><span className="text-[var(--text-2)]">{l.message}</span>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {!running && (
          <motion.div initial={{ opacity: 0, y: 24, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }} className={`glass border-flow relative mt-6 overflow-hidden p-6`} data-testid="scan-complete-panel">
            <div className="pointer-events-none absolute -right-20 -top-20 h-60 w-60 rounded-full blur-3xl" style={{ background: done ? (count ? "var(--crimson)" : "var(--teal)") : "var(--crimson)", opacity: 0.14 }} />
            <div className="flex flex-wrap items-center gap-4">
              {done ? (count ? <AlertTriangle className="text-[var(--crimson)]" size={28} /> : <ShieldCheck className="lock-pop text-[var(--teal)]" size={28} />) : <XCircle className="text-[var(--crimson)]" size={28} />}
              <div className="min-w-0 flex-1">
                <h2 className="text-lg font-semibold"><ScrambleText text={done ? (count ? `${count} finding${count === 1 ? "" : "s"} detected` : "No supported vulnerabilities found") : scan.stage} speed={20} /></h2>
                <p className="text-sm text-[var(--text-2)]">{done ? (count ? "Each finding has a playable exploit path and a conservative patch to review." : "The rule set found nothing — this is not proof the code is safe.") : "The analysis did not complete. You can retry or go back."}</p>
              </div>
              {done && (
                <div className="flex flex-wrap gap-2">
                  <PeakButton onClick={() => nav(`/app/scan/${sid}/findings`)} testId="scan-view-findings-button">View findings <ArrowRight size={15} /></PeakButton>
                  <button className="btn btn-ghost" onClick={() => nav(`/app/scan/${sid}/results`)} data-testid="scan-view-results-button"><BarChart3 size={15} />Results</button>
                  {count > 0 && <button className="btn btn-ghost" onClick={() => dl("corrected", `main.fixed.${ext}`)} data-testid="scan-download-corrected"><FileDown size={15} />Corrected file</button>}
                  <button className="btn btn-ghost" onClick={() => dl("code", `main.${ext}`)} data-testid="scan-download-code"><FileCode2 size={15} />Download code</button>
                  <button className="btn btn-ghost" onClick={() => nav(`/app/run?sid=${sid}&kind=${count ? "corrected" : "original"}`)} data-testid="scan-run-code"><TerminalSquare size={15} />Run code</button>
                </div>
              )}
              {!done && <button className="btn btn-ghost" onClick={() => nav("/app")} data-testid="scan-back-button">Back</button>}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </Page>
  );
}
