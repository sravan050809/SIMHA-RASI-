import { useEffect, useRef } from "react";
import "@/App.css";
import { BrowserRouter, Navigate, Route, Routes, useLocation, useNavigate } from "react-router-dom";
import { Toaster } from "sonner";
import { AuthProvider, useAuth } from "@/context/AuthContext";
import { api } from "@/lib/api";
import { Spinner, Brand } from "@/components/kit";
import Shell from "@/components/Shell";
import Landing from "@/pages/Landing";
import Login from "@/pages/Login";
import Dashboard from "@/pages/Dashboard";
import NewProject from "@/pages/NewProject";
import ScanPage from "@/pages/ScanPage";
import Findings from "@/pages/Findings";
import FindingDetail from "@/pages/FindingDetail";
import History from "@/pages/History";
import Results from "@/pages/Results";
import RunCode from "@/pages/RunCode";
import SharedScan from "@/pages/SharedScan";

const Centered = ({ children }) => <div className="grid min-h-screen place-items-center bg-[var(--bg)]"><div className="flex flex-col items-center gap-4 text-sm text-[var(--text-2)]"><Brand />{children}</div></div>;

/* Handles the Google OAuth return: exchanges session_id (URL fragment) for an httpOnly cookie. */
function AuthCallback() {
  const nav = useNavigate();
  const { setUser } = useAuth();
  const done = useRef(false);
  useEffect(() => {
    if (done.current) return; done.current = true;
    const sessionId = new URLSearchParams(window.location.hash.slice(1)).get("session_id");
    api.post("/auth/session", { session_id: sessionId })
      .then(({ data }) => { setUser(data); window.history.replaceState(null, "", "/app"); nav("/app", { replace: true, state: { user: data } }); })
      .catch(() => { window.history.replaceState(null, "", "/login"); nav("/login", { replace: true }); });
  }, [nav, setUser]);
  return <Centered><Spinner /> Completing secure sign-in…</Centered>;
}

function Protected({ children }) {
  const { user } = useAuth();
  const location = useLocation();
  if (user === null) return <Centered><Spinner /> Verifying session…</Centered>;
  if (!user) return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  return children;
}

function AppRouter() {
  const location = useLocation();
  if (location.hash?.includes("session_id=")) return <AuthCallback />;
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/login" element={<Login />} />
      <Route path="/share/:token" element={<SharedScan />} />
      <Route path="/app" element={<Protected><Shell /></Protected>}>
        <Route index element={<Dashboard />} />
        <Route path="new" element={<NewProject />} />
        <Route path="history" element={<History />} />
        <Route path="run" element={<RunCode />} />
        <Route path="scan/:sid" element={<ScanPage />} />
        <Route path="scan/:sid/findings" element={<Findings />} />
        <Route path="scan/:sid/finding/:fid" element={<FindingDetail />} />
        <Route path="scan/:sid/results" element={<Results />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  useEffect(() => {
    document.title = "SentinelGraph — Find the bug. See the attack. Prove the fix.";
    if (window.matchMedia?.("(hover: none)").matches) document.documentElement.classList.add("touch");
  }, []);
  return (
    <div className="App">
      <BrowserRouter>
        <AuthProvider>
          <AppRouter />
          <Toaster position="bottom-right" theme="dark" richColors closeButton toastOptions={{ style: { background: "#281511", border: "1px solid rgba(252,184,134,.24)", color: "#fdf2e9", fontFamily: "Instrument Sans, sans-serif" } }} />
        </AuthProvider>
      </BrowserRouter>
    </div>
  );
}
