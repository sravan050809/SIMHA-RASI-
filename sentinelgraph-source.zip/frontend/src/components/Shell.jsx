import { useEffect, useRef, useState } from "react";
import { NavLink, Outlet, useLocation, useNavigate, useOutlet } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { LayoutGrid, History, Plus, LogOut, Menu, X, TerminalSquare, Flame } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { Brand, PeakButton, ScrambleText } from "@/components/kit";
import { useRafLoop, usePrefersReducedMotion } from "@/lib/motion";

/* Lightweight ambient ember field for app pages (far cheaper than the hero scene). */
function AmbientField() {
  const ref = useRef(null);
  const pts = useRef([]);
  const reduced = usePrefersReducedMotion();
  useEffect(() => {
    const c = ref.current; const resize = () => { c.width = window.innerWidth; c.height = window.innerHeight; pts.current = Array.from({ length: Math.min(50, (c.width * c.height) / 30000) }, () => ({ x: Math.random() * c.width, y: Math.random() * c.height, vx: (Math.random() - .5) * .2, vy: (Math.random() - .5) * .2 })); };
    resize(); window.addEventListener("resize", resize); return () => window.removeEventListener("resize", resize);
  }, []);
  useRafLoop(() => {
    const c = ref.current; if (!c) return; const x = c.getContext("2d"); x.clearRect(0, 0, c.width, c.height);
    const P = pts.current;
    for (const p of P) { p.x += p.vx; p.y += p.vy; if (p.x < 0 || p.x > c.width) p.vx *= -1; if (p.y < 0 || p.y > c.height) p.vy *= -1; }
    for (let i = 0; i < P.length; i++) { const p = P[i]; x.fillStyle = i % 7 === 0 ? "rgba(47,185,198,.65)" : "rgba(252,184,134,.5)"; x.beginPath(); x.arc(p.x, p.y, 1.1, 0, 7); x.fill();
      for (let j = i + 1; j < P.length; j++) { const q = P[j]; const d = Math.hypot(p.x - q.x, p.y - q.y); if (d < 120) { x.strokeStyle = `rgba(255,122,69,${(1 - d / 120) * .2})`; x.beginPath(); x.moveTo(p.x, p.y); x.lineTo(q.x, q.y); x.stroke(); } } }
  }, !reduced);
  return <canvas ref={ref} aria-hidden="true" className="pointer-events-none fixed inset-0 z-0 opacity-70" />;
}

/* Extreme security transition: cipher-glyph rain + ember scan beam on every route change. */
function RouteCipher() {
  const location = useLocation();
  const reduced = usePrefersReducedMotion();
  const [stamp, setStamp] = useState(0);
  const first = useRef(true);
  useEffect(() => {
    if (first.current) { first.current = false; return undefined; }
    if (reduced) return undefined;
    setStamp(Date.now());
    const t = setTimeout(() => setStamp(0), 640);
    return () => clearTimeout(t);
  }, [location.pathname, reduced]);
  const cols = stamp
    ? Array.from({ length: 12 }, (_, i) => ({
        left: 3 + i * 8.2 + Math.random() * 3,
        delay: Math.random() * 0.16,
        chars: Array.from({ length: 26 }, () => "0123456789ABCDEF#$%&@*<>/"[(Math.random() * 27) | 0]).join(" "),
      }))
    : [];
  return (
    <AnimatePresence>
      {stamp ? (
        <motion.div key={stamp} className="cipher-overlay" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.16 }} aria-hidden="true" data-testid="route-cipher">
          {cols.map((c, i) => <span key={i} className="cipher-col" style={{ left: `${c.left}%`, animationDelay: `${c.delay}s` }}>{c.chars}</span>)}
          <span className="cipher-beam" />
          <span className="absolute bottom-8 left-1/2 -translate-x-1/2 whitespace-nowrap font-code text-[11px] uppercase tracking-[0.3em] text-[var(--peach)]">
            <ScrambleText text="SECURE CHANNEL // ROUTE ENCRYPTED" speed={16} trigger={stamp} />
          </span>
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}

const links = [
  { to: "/app", label: "Command center", icon: LayoutGrid, end: true, testId: "nav-dashboard-link" },
  { to: "/app/history", label: "Scan history", icon: History, testId: "nav-history-link" },
  { to: "/app/run", label: "Run code", icon: TerminalSquare, testId: "nav-run-link" },
];

export default function Shell() {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  const location = useLocation();
  const outlet = useOutlet();
  const [open, setOpen] = useState(false);
  useEffect(() => setOpen(false), [location.pathname]);

  const userCard = (
    <div className="flex items-center gap-3">
      {user?.picture ? <img src={user.picture} alt="" className="h-9 w-9 rounded-full border border-[var(--line-strong)]" /> : <div className="grid h-9 w-9 flex-none place-items-center rounded-full border border-[var(--ember-line)] bg-[var(--ember-soft)] font-head text-sm text-[var(--ember)]">{user?.name?.[0]?.toUpperCase()}</div>}
      <div className="min-w-0 flex-1 leading-tight">
        <div className="truncate text-[13px] font-medium" data-testid="nav-user-name">{user?.name}</div>
        <div className="overline" style={{ fontSize: 10 }}>{user?.provider === "google" ? "Google" : "Email"} · {user?.role}</div>
      </div>
      <button className="btn btn-ghost btn-icon" onClick={async () => { await logout(); nav("/login"); }} aria-label="Log out" data-testid="nav-logout-button"><LogOut size={15} /></button>
    </div>
  );

  return (
    <div className="relative min-h-screen">
      <AmbientField />
      <div className="pointer-events-none fixed inset-0 z-0 grid-bg opacity-60" />
      <RouteCipher />

      {/* desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[248px] flex-col border-r border-[var(--line)] bg-[rgba(21,10,7,.85)] backdrop-blur-xl lg:flex" data-testid="app-sidebar">
        <div className="px-5 pb-5 pt-6"><NavLink to="/app" className="inline-flex" data-testid="nav-brand-link"><Brand /></NavLink></div>
        <div className="px-4"><PeakButton className="btn-sm w-full" onClick={() => nav("/app/new")} testId="nav-new-scan-button"><Plus size={15} />New scan</PeakButton></div>
        <nav className="mt-6 flex-1 space-y-1 px-3" aria-label="Primary">
          {links.map((l) => <NavLink key={l.to} to={l.to} end={l.end} data-testid={l.testId} className={({ isActive }) => `side-link ${isActive ? "active" : ""}`}><span className="side-ico"><l.icon size={15} /></span>{l.label}</NavLink>)}
        </nav>
        <div className="px-5 pb-3"><div className="flex items-center gap-2 font-code text-[10px] uppercase tracking-[0.2em] text-[var(--text-3)]"><Flame size={12} className="text-[var(--ember)]" />Solar dusk build</div></div>
        <div className="m-3 mt-0 rounded-2xl border border-[var(--line)] bg-[rgba(40,21,17,.6)] p-3.5">{userCard}</div>
      </aside>

      {/* mobile top bar */}
      <header className="sticky top-0 z-40 flex h-16 items-center gap-3 border-b border-[var(--line)] bg-[rgba(21,10,7,.85)] px-4 backdrop-blur-xl lg:hidden" data-testid="app-header">
        <NavLink to="/app" className="flex items-center" data-testid="nav-brand-link-mobile"><Brand /></NavLink>
        <div className="ml-auto flex items-center gap-2">
          <PeakButton className="btn-sm" onClick={() => nav("/app/new")} testId="nav-new-scan-button-mobile"><Plus size={15} />New scan</PeakButton>
          <button className="btn btn-ghost btn-icon" onClick={() => setOpen((o) => !o)} aria-label="Menu" aria-expanded={open} data-testid="nav-menu-toggle">{open ? <X size={18} /> : <Menu size={18} />}</button>
        </div>
      </header>
      <AnimatePresence>
        {open && (
          <motion.nav initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="fixed inset-x-0 top-16 z-40 overflow-hidden border-b border-[var(--line)] bg-[rgba(21,10,7,.95)] backdrop-blur-xl lg:hidden" aria-label="Mobile" data-testid="nav-mobile-menu">
            <div className="flex flex-col gap-1 px-4 py-3">
              {links.map((l) => <NavLink key={l.to} to={l.to} end={l.end} data-testid={l.testId + "-mobile"} className={({ isActive }) => `side-link ${isActive ? "active" : ""}`}><span className="side-ico"><l.icon size={15} /></span>{l.label}</NavLink>)}
              <div className="mt-2 border-t border-[var(--line)] pt-3">{userCard}</div>
            </div>
          </motion.nav>
        )}
      </AnimatePresence>

      <main className="relative z-10 lg:pl-[248px]">
        <div className="mx-auto max-w-[1200px] px-4 pb-24 pt-8 sm:px-8">
          <AnimatePresence mode="wait" initial={false}>
            <div key={location.pathname}>{outlet || <Outlet />}</div>
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}

export const Page = ({ variant, children, className = "", testId }) => (
  <motion.div {...variant} className={className} data-testid={testId}>{children}</motion.div>
);
