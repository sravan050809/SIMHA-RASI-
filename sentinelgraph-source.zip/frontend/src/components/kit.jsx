import { useEffect, useRef, useState } from "react";
import { motion, useInView } from "framer-motion";
import { Shield, ShieldCheck, ShieldAlert, Loader2 } from "lucide-react";
import { isTouch, usePrefersReducedMotion } from "@/lib/motion";

export const Overline = ({ children, className = "" }) => <div className={`overline ${className}`}>{children}</div>;

export const SeverityBadge = ({ severity, testId }) => (
  <span className={`badge sev-${severity}`} data-testid={testId}>
    <span className={`sev-dot sev-dot-${severity}`} aria-hidden="true" />{severity}
  </span>
);

const STATUS_TONE = { Open: "badge-red", Patched: "badge-blue", Fixed: "badge-emerald", Generated: "badge-neutral", Applied: "badge-blue", Verified: "badge-emerald",
  Ready: "badge-neutral", Scanning: "badge-cyan", Vulnerable: "badge-red", Clean: "badge-green", Failed: "badge-red", running: "badge-cyan", done: "badge-green", failed: "badge-red", cancelled: "badge-neutral", verified: "badge-emerald" };
export const StatusBadge = ({ status, testId }) => <span className={`badge ${STATUS_TONE[status] || "badge-neutral"}`} data-testid={testId}>{status}</span>;

const CONF_TONE = { High: "badge-cyan", Medium: "badge-amber", Low: "badge-neutral" };
export const ConfidenceBadge = ({ level }) => <span className={`badge ${CONF_TONE[level] || "badge-neutral"}`} title="Confidence of the rule engine">conf · {level}</span>;

/* Special-character decrypt: text resolves out of a stream of glyphs. */
const GLYPHS = "!<>-_/[]{}=+*^?#$%&@~";
export function ScrambleText({ text = "", className = "", speed = 26, trigger = 0, as: Tag = "span", testId }) {
  const reduced = usePrefersReducedMotion();
  const [rev, setRev] = useState(0);
  useEffect(() => {
    if (reduced) { setRev(text.length); return undefined; }
    setRev(0);
    let n = 0;
    const id = setInterval(() => {
      n += 1;
      setRev(Math.min(text.length, Math.floor(n * 1.5)));
      if (n * 1.5 >= text.length + 1) clearInterval(id);
    }, speed);
    return () => clearInterval(id);
  }, [text, trigger, speed, reduced]);
  const masked = text.slice(rev).replace(/[^\s]/g, () => GLYPHS[(Math.random() * GLYPHS.length) | 0]);
  return (
    <Tag className={className} data-testid={testId}>
      {text.slice(0, rev)}
      {rev < text.length && <span className="scr-char" aria-hidden="true">{masked}</span>}
    </Tag>
  );
}

/* Peak button: magnetic hover + shine sweep + click ripple on a shifting sunset gradient. */
export function PeakButton({ children, className = "", onClick, testId, type = "button", disabled, magnetic = true, ...rest }) {
  const ref = useRef(null);
  const reduced = usePrefersReducedMotion();
  const move = (e) => {
    if (!magnetic || reduced || isTouch() || !ref.current) return;
    const r = ref.current.getBoundingClientRect();
    ref.current.style.setProperty("--mx", `${(e.clientX - r.left - r.width / 2) * 0.18}px`);
    ref.current.style.setProperty("--my", `${(e.clientY - r.top - r.height / 2) * 0.3}px`);
  };
  const leave = () => { const el = ref.current; if (el) { el.style.setProperty("--mx", "0px"); el.style.setProperty("--my", "0px"); } };
  const click = (e) => {
    const el = ref.current;
    if (el && !reduced) {
      const r = el.getBoundingClientRect();
      const s = document.createElement("span");
      s.className = "ripple";
      const d = Math.max(r.width, r.height) * 1.1;
      s.style.width = s.style.height = d + "px";
      s.style.left = e.clientX - r.left - d / 2 + "px";
      s.style.top = e.clientY - r.top - d / 2 + "px";
      el.appendChild(s);
      setTimeout(() => s.remove(), 700);
    }
    onClick?.(e);
  };
  return <button ref={ref} type={type} disabled={disabled} data-testid={testId} onPointerMove={move} onPointerLeave={leave} onClick={click} className={`btn btn-peak ${className}`} {...rest}>{children}</button>;
}

/* Glass card with restrained 3D tilt (disabled on touch / reduced motion). */
export function TiltCard({ children, className = "", max = 6, as: Tag = "div", ...rest }) {
  const ref = useRef(null);
  const reduced = usePrefersReducedMotion();
  const enabled = !reduced && !isTouch();
  const onMove = (e) => {
    if (!enabled) return;
    const r = ref.current.getBoundingClientRect();
    ref.current.style.setProperty("--ry", `${((e.clientX - r.left) / r.width - 0.5) * max * 2}deg`);
    ref.current.style.setProperty("--rx", `${-((e.clientY - r.top) / r.height - 0.5) * max * 2}deg`);
  };
  const onLeave = () => { if (ref.current) { ref.current.style.setProperty("--rx", "0deg"); ref.current.style.setProperty("--ry", "0deg"); } };
  return <Tag ref={ref} onPointerMove={onMove} onPointerLeave={onLeave} className={`glass glass-hover tilt ${className}`} {...rest}>{children}</Tag>;
}

export function CountUp({ value = 0, duration = 1100, className = "", testId }) {
  const [n, setN] = useState(0);
  const ref = useRef(null);
  const inView = useInView(ref, { once: true });
  const reduced = usePrefersReducedMotion();
  useEffect(() => {
    if (!inView) return undefined;
    if (reduced || !value) { setN(value); return undefined; }
    let raf; const start = performance.now();
    const step = (t) => { const k = Math.min(1, (t - start) / duration); setN(Math.round(value * (1 - Math.pow(1 - k, 3)))); if (k < 1) raf = requestAnimationFrame(step); };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [value, inView, duration, reduced]);
  return <span ref={ref} className={className} data-testid={testId}>{n}</span>;
}

export const Brand = ({ size = 22, withText = true, className = "" }) => (
  <span className={`inline-flex items-center gap-2.5 font-head font-semibold ${className}`}>
    <span className="relative grid place-items-center rounded-lg" style={{ width: size + 12, height: size + 12, background: "linear-gradient(135deg, rgba(255,122,69,.35), rgba(255,179,71,.3))", border: "1px solid rgba(252,184,134,.45)" }}>
      <Shield size={size} className="text-[var(--ember)]" strokeWidth={1.8} />
    </span>
    {withText && <span className="tracking-tight text-[17px]">Sentinel<span className="text-[var(--ember)]">Graph</span></span>}
  </span>
);

export const EmptyState = ({ icon: Icon = ShieldCheck, title, hint, action, testId }) => (
  <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="glass p-12 text-center" data-testid={testId}>
    <div className="relative mx-auto mb-5 grid h-16 w-16 place-items-center rounded-2xl border border-[var(--ember-line)] bg-[var(--ember-soft)]">
      <span className="pulse-ring" aria-hidden="true" /><Icon className="text-[var(--ember)]" size={28} strokeWidth={1.6} />
    </div>
    <h3 className="text-lg font-semibold">{title}</h3>
    {hint && <p className="mx-auto mt-2 max-w-md text-sm text-[var(--text-2)]">{hint}</p>}
    {action && <div className="mt-6">{action}</div>}
  </motion.div>
);

export const Spinner = ({ size = 16, className = "" }) => <Loader2 size={size} className={`spin ${className}`} aria-label="Loading" />;

export const ErrorBox = ({ children, testId }) => (
  <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} role="alert" data-testid={testId}
    className="flex items-start gap-2 rounded-lg border border-red-500/30 bg-red-500/10 px-3.5 py-2.5 text-sm text-red-200">
    <ShieldAlert size={16} className="mt-0.5 flex-none" />{children}
  </motion.div>
);

/* Peak moment: celebratory particle burst (sunset palette). */
export function Burst({ trigger, palette = ["#FF7A45", "#FFB347", "#FCB886", "#2FB9C6", "#E0784F"] }) {
  const reduced = usePrefersReducedMotion();
  useEffect(() => {
    if (!trigger || reduced) return undefined;
    const els = [];
    for (let i = 0; i < 42; i++) {
      const d = document.createElement("span"); d.className = "burst-particle";
      const a = Math.random() * Math.PI * 2, v = 140 + Math.random() * 260;
      d.style.cssText = `left:50%;top:42%;background:${palette[i % palette.length]};--x:${Math.cos(a) * v}px;--y:${Math.sin(a) * v + 140}px`;
      document.body.appendChild(d); els.push(d);
    }
    const tm = setTimeout(() => els.forEach((e) => e.remove()), 1200);
    return () => { clearTimeout(tm); els.forEach((e) => e.remove()); };
  }, [trigger, reduced, palette]);
  return null;
}

export function Segmented({ value, onChange, options, testIdPrefix = "seg" }) {
  return (
    <div role="tablist" className="inline-flex rounded-full border border-[var(--line-strong)] bg-black/30 p-1">
      {options.map((o) => (
        <button key={o.value} role="tab" aria-selected={value === o.value} data-testid={`${testIdPrefix}-${o.value}`} onClick={() => onChange(o.value)}
          className={`relative rounded-full px-3.5 py-1.5 text-[13px] font-medium transition-colors ${value === o.value ? "text-[#2a0d05]" : "text-[var(--text-2)] hover:text-white"}`}>
          {value === o.value && <motion.span layoutId={`${testIdPrefix}-pill`} className="absolute inset-0 rounded-full bg-[var(--ember)]" transition={{ type: "spring", stiffness: 400, damping: 32 }} />}
          <span className="relative inline-flex items-center gap-1.5">{o.icon}{o.label}</span>
        </button>
      ))}
    </div>
  );
}
