import { useEffect, useState } from "react";
import { Link2, Copy, Check, Trash2, Globe, Eye } from "lucide-react";
import { toast } from "sonner";
import { api, errorText } from "@/lib/api";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { PeakButton, Spinner, Overline } from "@/components/kit";

export function ShareDialog({ sid, open, onOpenChange }) {
  const [link, setLink] = useState(undefined);
  const [busy, setBusy] = useState(false);
  const [copied, setCopied] = useState(false);
  useEffect(() => { if (open) api.get(`/scans/${sid}/share`).then((r) => setLink(r.data)).catch((e) => toast.error(errorText(e))); }, [open, sid]);

  const url = link ? `${window.location.origin}${link.path}` : "";
  const create = async () => { setBusy(true); try { const { data } = await api.post(`/scans/${sid}/share`); setLink(data); toast.success("Public link created"); } catch (e) { toast.error(errorText(e)); } finally { setBusy(false); } };
  const revoke = async () => { setBusy(true); try { await api.delete(`/scans/${sid}/share`); setLink(null); toast.success("Link revoked — it no longer opens"); } catch (e) { toast.error(errorText(e)); } finally { setBusy(false); } };
  const copy = async () => { try { await navigator.clipboard.writeText(url); } catch { const i = document.getElementById("share-link-input"); i?.select(); document.execCommand("copy"); } setCopied(true); toast.success("Link copied"); setTimeout(() => setCopied(false), 1600); };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass max-w-lg border-[var(--line-strong)] bg-[rgba(28,13,9,.96)] text-[var(--text-1)]" data-testid="share-dialog">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 font-head text-xl"><Link2 size={18} className="text-[var(--ember)]" />Share scan results</DialogTitle>
          <DialogDescription className="text-[var(--text-2)]">Anyone with the link gets a read-only view of the findings, exploit graphs, patches and source code. No account needed. Revoke it any time.</DialogDescription>
        </DialogHeader>
        {link === undefined ? <div className="flex items-center gap-2 py-4 text-sm text-[var(--text-2)]"><Spinner />Checking link status…</div> : link ? (
          <div className="space-y-4" data-testid="share-active">
            <div className="flex items-center gap-2 text-xs text-[var(--emerald)]"><Globe size={13} /><Overline className="text-[var(--emerald)]">Public link active</Overline></div>
            <div className="flex gap-2">
              <input id="share-link-input" readOnly value={url} onFocus={(e) => e.target.select()} className="min-w-0 flex-1 rounded-xl border border-[var(--line)] bg-black/30 px-3 py-2 font-code text-xs text-[var(--peach)] outline-none focus:border-[var(--ember-line)]" data-testid="share-link-input" />
              <PeakButton className="btn-sm" onClick={copy} testId="share-copy-button">{copied ? <Check size={14} /> : <Copy size={14} />}{copied ? "Copied" : "Copy"}</PeakButton>
            </div>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <a href={url} target="_blank" rel="noreferrer" className="btn btn-ghost btn-sm" data-testid="share-preview-link"><Eye size={14} />Preview as viewer</a>
              <button className="btn btn-ghost btn-sm text-[var(--red)]" onClick={revoke} disabled={busy} data-testid="share-revoke-button">{busy ? <Spinner size={14} /> : <Trash2 size={14} />}Revoke link</button>
            </div>
          </div>
        ) : (
          <div className="space-y-4" data-testid="share-inactive">
            <p className="text-sm text-[var(--text-2)]">This scan is private. Create a link to share it with teammates.</p>
            <PeakButton onClick={create} disabled={busy} testId="share-create-button">{busy ? <Spinner size={14} /> : <Link2 size={14} />}Create public link</PeakButton>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
