import { useCallback, useEffect, useRef } from "react";
import { usePrefersReducedMotion, useRafLoop, isTouch } from "@/lib/motion";

const EMBER = [255, 122, 69];    // FF7A45
const PEACH = [252, 184, 134];   // FCB886
const COPPER = [217, 122, 78];   // D97A4E
const GOLD = [255, 179, 71];     // FFB347
const TEAL = [47, 185, 198];     // 2FB9C6
const rgba = (c, a) => `rgba(${c[0]},${c[1]},${c[2]},${a})`;

function shieldPath(ctx, r) {
  ctx.beginPath();
  ctx.moveTo(0, -r);
  ctx.bezierCurveTo(r * 0.55, -r * 0.92, r * 0.86, -r * 0.74, r * 0.92, -r * 0.62);
  ctx.bezierCurveTo(r * 0.96, 0.05 * r, r * 0.6, r * 0.72, 0, r);
  ctx.bezierCurveTo(-r * 0.6, r * 0.72, -r * 0.96, 0.05 * r, -r * 0.92, -r * 0.62);
  ctx.bezierCurveTo(-r * 0.86, -r * 0.74, -r * 0.55, -r * 0.92, 0, -r);
  ctx.closePath();
}

/**
 * Holographic guardian at dusk: Canvas 2D (no WebGL dependency). Layers: fog + grid → neural network
 * with threat signals → orbital rings (back half) → shield body → emblem → rings (front half) → ember dust.
 */
export function ShieldScene({ variant = "hero", pulse = 0, className = "" }) {
  const canvasRef = useRef(null);
  const state = useRef({ nodes: [], signals: [], dust: [], mouse: { x: 0, y: 0, tx: 0, ty: 0 }, w: 0, h: 0, dpr: 1, pulseAt: 0, last: 0 });
  const reduced = usePrefersReducedMotion();
  const ambient = variant !== "hero";

  useEffect(() => { if (pulse) state.current.pulseAt = performance.now(); }, [pulse]);

  const setup = useCallback(() => {
    const c = canvasRef.current; if (!c) return;
    const s = state.current;
    const rect = c.parentElement.getBoundingClientRect();
    s.dpr = Math.min(2, window.devicePixelRatio || 1);
    s.w = rect.width; s.h = rect.height;
    c.width = s.w * s.dpr; c.height = s.h * s.dpr;
    const n = Math.min(ambient ? 42 : 76, Math.floor((s.w * s.h) / 16000));
    s.nodes = Array.from({ length: n }, () => ({ x: Math.random() * s.w, y: Math.random() * s.h, vx: (Math.random() - 0.5) * 0.25, vy: (Math.random() - 0.5) * 0.25, r: Math.random() * 1.6 + 0.6, z: Math.random() }));
    s.dust = Array.from({ length: ambient ? 20 : 40 }, () => ({ x: Math.random() * s.w, y: Math.random() * s.h, v: Math.random() * 0.3 + 0.1, r: Math.random() * 1.2 + 0.4 }));
    s.signals = [];
  }, [ambient]);

  useEffect(() => {
    setup();
    const ro = new ResizeObserver(setup);
    ro.observe(canvasRef.current.parentElement);
    const onMove = (e) => { const s = state.current; s.mouse.tx = (e.clientX / window.innerWidth - 0.5) * 2; s.mouse.ty = (e.clientY / window.innerHeight - 0.5) * 2; };
    if (!isTouch()) window.addEventListener("pointermove", onMove);
    return () => { ro.disconnect(); window.removeEventListener("pointermove", onMove); };
  }, [setup]);

  const draw = useCallback((t) => {
    const c = canvasRef.current; if (!c) return;
    const s = state.current; const ctx = c.getContext("2d");
    const { w, h, dpr } = s; if (!w) return;
    const dt = Math.min(40, t - (s.last || t)); s.last = t;
    const T = t / 1000;
    s.mouse.x += (s.mouse.tx - s.mouse.x) * 0.04; s.mouse.y += (s.mouse.ty - s.mouse.y) * 0.04;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);

    const cx = w / 2 + s.mouse.x * (ambient ? 6 : 14);
    const cy = (ambient ? h * 0.5 : h * 0.46) + s.mouse.y * (ambient ? 4 : 10);
    const R = ambient ? Math.min(w, h) * 0.26 : Math.min(w * 0.22, h * 0.3, 210);
    const pulseAge = s.pulseAt ? (t - s.pulseAt) / 1000 : 99;
    const energy = pulseAge < 1.4 ? 1 - pulseAge / 1.4 : 0;

    // dusk fog
    const fog = ctx.createRadialGradient(cx, cy, R * 0.2, cx, cy, Math.max(w, h) * 0.7);
    fog.addColorStop(0, rgba(EMBER, 0.17 + energy * 0.18)); fog.addColorStop(0.35, rgba(COPPER, 0.13)); fog.addColorStop(1, "rgba(21,10,7,0)");
    ctx.fillStyle = fog; ctx.fillRect(0, 0, w, h);

    // neural network
    const nodes = s.nodes;
    for (const p of nodes) {
      p.x += p.vx * dt * 0.06; p.y += p.vy * dt * 0.06;
      if (p.x < -10) p.x = w + 10; if (p.x > w + 10) p.x = -10; if (p.y < -10) p.y = h + 10; if (p.y > h + 10) p.y = -10;
    }
    ctx.lineWidth = 1;
    for (let i = 0; i < nodes.length; i++) {
      const p = nodes[i];
      for (let j = i + 1; j < nodes.length; j++) {
        const q = nodes[j]; const d = Math.hypot(p.x - q.x, p.y - q.y);
        if (d < 150) { ctx.strokeStyle = rgba(PEACH, (1 - d / 150) * (ambient ? 0.13 : 0.22)); ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(q.x, q.y); ctx.stroke(); }
      }
      ctx.fillStyle = rgba(i % 8 === 0 ? TEAL : PEACH, 0.35 + p.z * 0.55); ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, 7); ctx.fill();
    }

    // threat signals travelling toward the shield, neutralised at the boundary
    if (!ambient && s.signals.length < 6 && Math.random() < 0.025) {
      const src = nodes[Math.floor(Math.random() * nodes.length)];
      if (src && Math.hypot(src.x - cx, src.y - cy) > R * 1.6) s.signals.push({ x: src.x, y: src.y, sx: src.x, sy: src.y, t: 0, life: 1 });
    }
    s.signals = s.signals.filter((g) => g.life > 0);
    for (const g of s.signals) {
      if (g.t < 1) {
        g.t += dt * 0.00035; const k = g.t; const tx = cx + (g.sx - cx) * (R * 1.05) / Math.hypot(g.sx - cx, g.sy - cy); const ty = cy + (g.sy - cy) * (R * 1.05) / Math.hypot(g.sx - cx, g.sy - cy);
        g.x = g.sx + (tx - g.sx) * k; g.y = g.sy + (ty - g.sy) * k;
        ctx.strokeStyle = `rgba(255,90,77,${0.45})`; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(g.sx, g.sy); ctx.lineTo(g.x, g.y); ctx.stroke();
        ctx.fillStyle = "#ff5a4d"; ctx.shadowColor = "#ff5a4d"; ctx.shadowBlur = 14; ctx.beginPath(); ctx.arc(g.x, g.y, 2.8, 0, 7); ctx.fill(); ctx.shadowBlur = 0;
      } else {
        g.life -= dt * 0.002; const rr = (1 - g.life) * 26 + 4;
        ctx.strokeStyle = rgba(PEACH, g.life * 0.9); ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(g.x, g.y, rr, 0, 7); ctx.stroke();
      }
    }

    // orbital rings (3 tilted ellipses; back halves first)
    const rings = [
      { r: R * 1.35, tilt: 0.32, speed: 0.22, phase: 0, col: PEACH, a: 0.6 },
      { r: R * 1.62, tilt: -0.55, speed: -0.16, phase: 1.4, col: GOLD, a: 0.42 },
      { r: R * 1.9, tilt: 0.95, speed: 0.11, phase: 2.6, col: TEAL, a: 0.4 },
    ];
    const drawRing = (ring, front) => {
      const rot = T * ring.speed + ring.phase;
      ctx.save(); ctx.translate(cx, cy); ctx.rotate(ring.tilt);
      ctx.strokeStyle = rgba(ring.col, ring.a * (front ? 1 : 0.35)); ctx.lineWidth = front ? 1.4 : 1;
      ctx.beginPath(); ctx.ellipse(0, 0, ring.r, ring.r * 0.28, 0, front ? 0 : Math.PI, front ? Math.PI : Math.PI * 2); ctx.stroke();
      const sx = Math.cos(rot) * ring.r, sy = Math.sin(rot) * ring.r * 0.28; const isFront = Math.sin(rot) > 0;
      if (isFront === front) {
        ctx.fillStyle = rgba(ring.col, 1); ctx.shadowColor = rgba(ring.col, 1); ctx.shadowBlur = 14;
        ctx.beginPath(); ctx.arc(sx, sy, front ? 3.2 : 2.2, 0, 7); ctx.fill(); ctx.shadowBlur = 0;
      }
      ctx.restore();
    };
    rings.forEach((r) => drawRing(r, false));

    // shield body — forged copper
    ctx.save(); ctx.translate(cx, cy);
    const breathe = 1 + Math.sin(T * 1.2) * 0.012 + energy * 0.08;
    ctx.scale(breathe, breathe);
    ctx.shadowColor = rgba(EMBER, 0.6 + energy * 0.4); ctx.shadowBlur = 48 + energy * 90;
    const body = ctx.createLinearGradient(-R, -R, R, R);
    body.addColorStop(0, "rgba(64,35,26,0.96)"); body.addColorStop(0.45, "rgba(40,21,17,0.97)"); body.addColorStop(1, "rgba(137,67,41,0.95)");
    shieldPath(ctx, R); ctx.fillStyle = body; ctx.fill();
    ctx.shadowBlur = 0;
    // metallic rim + light sweep
    const sweep = (T * 0.35) % 2 - 1;
    const rim = ctx.createLinearGradient(-R, -R, R, R);
    rim.addColorStop(0, rgba(EMBER, 0.45)); rim.addColorStop(Math.max(0, Math.min(1, 0.5 + sweep * 0.5)), "rgba(255,244,232,0.95)"); rim.addColorStop(1, rgba(GOLD, 0.55));
    shieldPath(ctx, R); ctx.lineWidth = 2.2; ctx.strokeStyle = rim; ctx.stroke();
    shieldPath(ctx, R * 0.86); ctx.lineWidth = 1; ctx.strokeStyle = rgba(PEACH, 0.35); ctx.stroke();
    // inner holographic plates
    ctx.globalAlpha = 0.9;
    const plate = ctx.createLinearGradient(0, -R, 0, R);
    plate.addColorStop(0, rgba(PEACH, 0.2)); plate.addColorStop(0.5, rgba(EMBER, 0.05)); plate.addColorStop(1, rgba(COPPER, 0.32));
    shieldPath(ctx, R * 0.72); ctx.fillStyle = plate; ctx.fill();
    ctx.globalAlpha = 1;
    // emblem: rotating hex + core
    ctx.save(); ctx.rotate(T * 0.3);
    ctx.beginPath(); for (let i = 0; i < 6; i++) { const a = (i / 6) * Math.PI * 2; ctx.lineTo(Math.cos(a) * R * 0.34, Math.sin(a) * R * 0.34); } ctx.closePath();
    ctx.strokeStyle = rgba(PEACH, 0.9); ctx.lineWidth = 1.5; ctx.shadowColor = rgba(EMBER, 1); ctx.shadowBlur = 16; ctx.stroke();
    ctx.restore();
    ctx.save(); ctx.rotate(-T * 0.5);
    ctx.beginPath(); for (let i = 0; i < 3; i++) { const a = (i / 3) * Math.PI * 2 - Math.PI / 2; ctx.lineTo(Math.cos(a) * R * 0.2, Math.sin(a) * R * 0.2); } ctx.closePath();
    ctx.strokeStyle = rgba(GOLD, 0.9); ctx.lineWidth = 1.2; ctx.stroke();
    ctx.restore();
    const core = ctx.createRadialGradient(0, 0, 0, 0, 0, R * 0.16);
    core.addColorStop(0, "rgba(255,248,240,0.95)"); core.addColorStop(0.4, rgba(PEACH, 0.9)); core.addColorStop(1, rgba(EMBER, 0));
    ctx.fillStyle = core; ctx.beginPath(); ctx.arc(0, 0, R * 0.16 * (1 + Math.sin(T * 2) * 0.08 + energy * 0.6), 0, 7); ctx.fill();
    // scan sweep across the shield
    ctx.save(); shieldPath(ctx, R * 0.86); ctx.clip();
    const sy = ((T * 0.25) % 1) * 2 * R - R;
    const beam = ctx.createLinearGradient(0, sy - 18, 0, sy + 18);
    beam.addColorStop(0, rgba(EMBER, 0)); beam.addColorStop(0.5, rgba(EMBER, 0.35)); beam.addColorStop(1, rgba(EMBER, 0));
    ctx.fillStyle = beam; ctx.fillRect(-R, sy - 18, R * 2, 36);
    ctx.restore();
    ctx.restore();

    // energy pulse (CTA)
    if (energy > 0) {
      for (let i = 0; i < 3; i++) {
        const k = Math.min(1, pulseAge * 0.9 - i * 0.15); if (k <= 0) continue;
        ctx.strokeStyle = i === 1 ? `rgba(255,179,71,${(1 - k) * 0.85})` : rgba(PEACH, (1 - k) * 0.9); ctx.lineWidth = 2 - k;
        ctx.beginPath(); ctx.arc(cx, cy, R * (0.9 + k * 2.6), 0, 7); ctx.stroke();
      }
    }
    rings.forEach((r) => drawRing(r, true));

    // foreground ember dust
    for (const d of s.dust) {
      d.y -= d.v * dt * 0.05; if (d.y < -4) { d.y = h + 4; d.x = Math.random() * w; }
      ctx.fillStyle = `rgba(255,226,200,${0.22 + d.r * 0.2})`; ctx.beginPath(); ctx.arc(d.x + s.mouse.x * 20 * d.r, d.y, d.r, 0, 7); ctx.fill();
    }
  }, [ambient]);

  useRafLoop(draw, !reduced);
  useEffect(() => { if (reduced) { setup(); draw(performance.now()); } }, [reduced, setup, draw]);

  return <canvas ref={canvasRef} className={className} aria-hidden="true" style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }} data-testid="shield-scene-canvas" />;
}
