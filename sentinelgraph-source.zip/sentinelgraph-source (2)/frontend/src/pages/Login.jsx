import { useEffect, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { Eye, EyeOff, Mail, Lock, User, ArrowLeft, Clock } from "lucide-react";
import { toast } from "sonner";
import { api, errorText } from "@/lib/api";
import { useAuth } from "@/context/AuthContext";
import { ShieldScene } from "@/components/hero/ShieldScene";
import { Brand, ErrorBox, Spinner } from "@/components/kit";
import { EASE } from "@/lib/motion";

const panel = { initial: { opacity: 0, x: 24, filter: "blur(6px)" }, animate: { opacity: 1, x: 0, filter: "blur(0px)" }, exit: { opacity: 0, x: -24, filter: "blur(6px)" }, transition: { duration: 0.4, ease: EASE } };

function Field({ id, label, icon: Icon, type = "text", value, onChange, error, autoComplete, testId, right }) {
  return (
    <div>
      <label htmlFor={id} className="label">{label}</label>
      <div className="relative">
        <Icon size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-[var(--text-3)]" />
        <input id={id} type={type} value={value} onChange={onChange} autoComplete={autoComplete} aria-invalid={!!error} aria-describedby={error ? `${id}-err` : undefined}
          className="input pl-10 pr-11" data-testid={testId} />
        {right}
      </div>
      {error && <div id={`${id}-err`} className="field-error" data-testid={`${testId}-error`}>{error}</div>}
    </div>
  );
}

export default function Login() {
  const nav = useNavigate();
  const [params] = useSearchParams();
  const { user, setUser, expired, setExpired } = useAuth();
  const [mode, setMode] = useState(params.get("mode") === "register" ? "register" : "login");
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [fieldErr, setFieldErr] = useState({});
  const [sent, setSent] = useState(false);

  useEffect(() => { if (user) nav("/app", { replace: true }); }, [user, nav]);
  useEffect(() => { setErr(""); setFieldErr({}); setSent(false); }, [mode]);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));
  const validate = () => {
    const fe = {};
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(form.email)) fe.email = "Enter a valid email address.";
    if (mode !== "forgot" && form.password.length < 8) fe.password = "Use at least 8 characters.";
    if (mode === "register" && !form.name.trim()) fe.name = "Tell us what to call you.";
    setFieldErr(fe); return !Object.keys(fe).length;
  };

  const submit = async (e) => {
    e.preventDefault(); setErr(""); setExpired(false);
    if (!validate()) return;
    setBusy(true);
    try {
      if (mode === "forgot") { await api.post("/auth/forgot-password", { email: form.email }); setSent(true); }
      else {
        const { data } = await api.post(mode === "login" ? "/auth/login" : "/auth/register", mode === "login" ? { email: form.email, password: form.password } : form);
        setUser(data); toast.success(mode === "login" ? `Welcome back, ${data.name}` : "Account created — demo project ready."); nav("/app", { replace: true });
      }
    } catch (ex) { setErr(errorText(ex)); }
    finally { setBusy(false); }
  };

  const title = { login: "Sign in to the console", register: "Create your analyst account", forgot: "Recover access" }[mode];

  return (
    <div className="relative min-h-screen overflow-hidden bg-[var(--bg)]" data-testid="login-page">
      <div className="absolute inset-0 grid-bg opacity-60" />
      <ShieldScene variant="ambient" />
      <div className="relative z-10 mx-auto flex min-h-screen max-w-[1280px] flex-col px-5 sm:px-8">
        <header className="flex items-center justify-between pt-6">
          <Link to="/" className="inline-flex" data-testid="login-brand-link"><Brand /></Link>
          <Link to="/" className="btn btn-ghost btn-sm" data-testid="login-back-home"><ArrowLeft size={14} />Home</Link>
        </header>
        <div className="grid flex-1 items-center gap-10 py-10 lg:grid-cols-[1fr_440px]">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, ease: EASE, delay: 0.2 }} className="hidden lg:block">
            <div className="overline mb-4 text-[var(--ice)]">Secure access</div>
            <h1 className="max-w-[12ch] text-4xl font-bold leading-[1.05] tracking-tight sm:text-5xl">Your findings stay yours.</h1>
            <p className="mt-5 max-w-[46ch] text-[var(--text-2)]">Accounts are verified server-side. Passwords are hashed with Argon2id, sessions live in httpOnly cookies, and every project, scan and report is ownership-checked.</p>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 28, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} transition={{ duration: 0.7, ease: EASE }} className="glass relative overflow-hidden p-7 sm:p-8" data-testid="auth-panel">
            <div className="pointer-events-none absolute -right-20 -top-24 h-56 w-56 rounded-full bg-[var(--cyan)] opacity-[0.07] blur-3xl" />
            <div className="pointer-events-none absolute -bottom-24 -left-16 h-56 w-56 rounded-full bg-[var(--violet)] opacity-[0.08] blur-3xl" />
            <AnimatePresence>
              {expired && <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="mb-4 flex items-center gap-2 rounded-lg border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-sm text-amber-100" data-testid="auth-session-expired"><Clock size={14} />Your session expired. Please sign in again.</motion.div>}
            </AnimatePresence>
            <AnimatePresence mode="wait">
              <motion.div key={mode} {...panel}>
                <h2 className="text-xl font-semibold sm:text-2xl" data-testid="auth-title">{title}</h2>
                <p className="mt-1 text-sm text-[var(--text-2)]">{mode === "forgot" ? "We'll issue a one-hour reset token for password accounts." : "Analyse code, replay exploit paths and verify fixes."}</p>

                {mode !== "forgot" && (
                  <div className="my-5 flex items-center gap-3 text-xs text-[var(--text-3)]"><span className="h-px flex-1 bg-[var(--line)]" />Sign in with email<span className="h-px flex-1 bg-[var(--line)]" /></div>
                )}

                <form onSubmit={submit} className="space-y-4" noValidate data-testid="auth-form">
                  {mode === "register" && <Field id="name" label="Name" icon={User} value={form.name} onChange={set("name")} error={fieldErr.name} autoComplete="name" testId="auth-name-input" />}
                  <Field id="email" label="Email" icon={Mail} type="email" value={form.email} onChange={set("email")} error={fieldErr.email} autoComplete="email" testId="auth-email-input" />
                  {mode !== "forgot" && (
                    <Field id="password" label="Password" icon={Lock} type={show ? "text" : "password"} value={form.password} onChange={set("password")} error={fieldErr.password} autoComplete={mode === "login" ? "current-password" : "new-password"} testId="auth-password-input"
                      right={<button type="button" onClick={() => setShow((s) => !s)} aria-label={show ? "Hide password" : "Show password"} aria-pressed={show} className="absolute right-2 top-1/2 -translate-y-1/2 rounded-md p-1.5 text-[var(--text-3)] hover:text-white" data-testid="auth-toggle-password">{show ? <EyeOff size={16} /> : <Eye size={16} />}</button>} />
                  )}
                  {err && <ErrorBox testId="auth-error">{err}</ErrorBox>}
                  {sent && <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/10 px-3.5 py-2.5 text-sm text-emerald-100" data-testid="auth-forgot-sent">If that account exists, a reset token was issued. No email provider is configured in this deployment, so the token is written to the server log.</div>}
                  <button type="submit" className="btn btn-primary mt-2 w-full py-3" disabled={busy} data-testid="auth-submit-button">
                    {busy ? <Spinner /> : null}{mode === "login" ? "Sign in" : mode === "register" ? "Create account" : "Send reset token"}
                  </button>
                </form>

                <div className="mt-5 flex flex-wrap items-center justify-between gap-2 text-sm text-[var(--text-2)]">
                  {mode === "login" && <><button className="hover:text-white" onClick={() => setMode("register")} data-testid="auth-switch-register">New here? Create account</button><button className="hover:text-white" onClick={() => setMode("forgot")} data-testid="auth-switch-forgot">Forgot password?</button></>}
                  {mode === "register" && <button className="hover:text-white" onClick={() => setMode("login")} data-testid="auth-switch-login">Have an account? Sign in</button>}
                  {mode === "forgot" && <button className="hover:text-white" onClick={() => setMode("login")} data-testid="auth-switch-login">Back to sign in</button>}
                </div>
              </motion.div>
            </AnimatePresence>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
