import { useEffect, useRef, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { Play, Eraser, FileDown, FlaskConical, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { api, errorText, LANG_EXT } from "@/lib/api";
import { PAGE } from "@/lib/motion";
import { Page } from "@/components/Shell";
import { Overline, PeakButton, ScrambleText, StatusBadge } from "@/components/kit";

const SNIPPET = `// SentinelGraph sunset runtime — JavaScript runs in a sandboxed frame.
// No DOM, no network, no storage. Output only.
const banner = (s) => console.log("» " + s);
banner("runtime online");
console.info("sandbox: allow-scripts only");
for (let i = 1; i <= 4; i++) console.log("probe " + i, "→", "#".repeat(i));
console.warn("warning channel check");
console.log("sunset:", ["#FF7A45", "#FCB886", "#2FB9C6"].join(" "));
banner("done");`;

const TONE = { log: "text-[var(--text-2)]", info: "text-[var(--teal)]", warn: "text-[var(--amber)]", error: "text-[#ffb3ab]", done: "text-[var(--emerald)]" };

export default function RunCode() {
  const [params] = useSearchParams();
  const [code, setCode] = useState(SNIPPET);
  const [lang, setLang] = useState("JavaScript");
  const [srcName, setSrcName] = useState("");
  const [out, setOut] = useState([]);
  const [running, setRunning] = useState(false);
  const termRef = useRef(null);

  useEffect(() => {
    const sid = params.get("sid");
    if (!sid) return;
    const kind = params.get("kind") === "original" ? "code" : "corrected";
    (async () => {
      try {
        const [{ data: scan }, src] = await Promise.all([
          api.get(`/scans/${sid}`),
          api.get(`/scans/${sid}/download/${kind}`, { responseType: "text" }),
        ]);
        setLang(scan.language);
        setCode(typeof src.data === "string" ? src.data : String(src.data));
        setSrcName(`${scan.project_name} · ${kind === "code" ? "original" : "corrected"}`);
        toast.success(`Loaded ${kind === "code" ? "original" : "corrected"} code from “${scan.project_name}”`);
      } catch (e) { toast.error(errorText(e)); }
    })();
  }, [params]);

  useEffect(() => { if (termRef.current) termRef.current.scrollTop = termRef.current.scrollHeight; }, [out.length]);

  const run = () => {
    if (lang !== "JavaScript") { toast.error("The browser sandbox runs JavaScript only — this file is view/download only."); return; }
    if (!code.trim()) { toast.error("The editor is empty."); return; }
    setRunning(true); setOut([]);
    const id = "sg" + Math.random().toString(36).slice(2);
    const push = (type, text) => setOut((o) => [...o, { type, text, at: new Date().toLocaleTimeString(undefined, { hour12: false }) }]);
    let iframe;
    const cleanup = () => { window.removeEventListener("message", onMsg); clearTimeout(tm); iframe?.remove(); setRunning(false); };
    const onMsg = (e) => {
      const d = e.data || {}; if (d.sg !== id) return;
      if (d.type === "done") { cleanup(); push("done", "process finished — exit code 0"); }
      else push(TONE[d.type] ? d.type : "log", d.text);
    };
    const tm = setTimeout(() => { push("error", "Execution timed out after 6s — infinite loop?"); cleanup(); }, 6000);
    window.addEventListener("message", onMsg);
    const safe = code.replace(/<\/script/gi, "<\\/script");
    iframe = document.createElement("iframe");
    iframe.setAttribute("sandbox", "allow-scripts");
    iframe.style.display = "none";
    iframe.srcdoc = `<!doctype html><meta charset="utf-8"><script>
(function(){
  var send=function(t,a){parent.postMessage({sg:${JSON.stringify(id)},type:t,text:a.map(function(x){try{return typeof x==="string"?x:JSON.stringify(x)}catch(_){return String(x)}}).join(" ")},"*")};
  ["log","info","warn","error"].forEach(function(k){console[k]=function(){send(k,[].slice.call(arguments))}});
  window.onerror=function(m,s,l){send("error",[m+" (line "+l+")"]);return true;};
  window.onunhandledrejection=function(e){send("error",["unhandled rejection: "+((e.reason&&e.reason.message)||e.reason)])};
  try {
${safe}
;send("done",[]);
  } catch (err) { send("error",[(err&&err.message)||String(err)]); send("done",[]); }
})();
<\/script>`;
    document.body.appendChild(iframe);
  };

  const downloadEditor = () => {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([code], { type: "text/plain" }));
    a.download = `main.${LANG_EXT[lang] || "txt"}`;
    a.click(); URL.revokeObjectURL(a.href);
  };

  const lines = code ? code.split("\n").length : 0;

  return (
    <Page variant={PAGE.run} testId="run-page">
      <Overline className="mb-2 text-[var(--peach)]">Sunset runtime</Overline>
      <h1 className="text-3xl font-bold tracking-tight sm:text-4xl"><ScrambleText text="Run the code" speed={26} /></h1>
      <p className="mt-1 max-w-[64ch] text-sm text-[var(--text-2)]">
        Paste code — or arrive here from a completed scan to load the corrected file. JavaScript executes in a
        sandboxed frame (<span className="font-code text-[var(--peach)]">allow-scripts</span> only: no DOM, no network, no storage). Other languages are view &amp; download only.
      </p>

      <div className="mt-8 grid gap-5 lg:grid-cols-2">
        <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.08 }} className="glass p-0 overflow-hidden" data-testid="run-editor-card">
          <div className="flex flex-wrap items-center gap-3 border-b border-[var(--line)] px-4 py-2.5">
            <span className="flex gap-1.5" aria-hidden="true"><span className="h-2.5 w-2.5 rounded-full bg-[#FF5A4D]" /><span className="h-2.5 w-2.5 rounded-full bg-[#FFB347]" /><span className="h-2.5 w-2.5 rounded-full bg-[#2FB9C6]" /></span>
            <Overline>Editor</Overline>
            <span className="badge badge-cyan" data-testid="run-language-badge">{lang}</span>
            {srcName && <span className="badge badge-neutral" data-testid="run-source-badge">{srcName}</span>}
            <span className="ml-auto font-code text-xs text-[var(--text-3)]">{lines} lines</span>
          </div>
          <textarea className="input scroll-thin rounded-none border-0 font-code" style={{ minHeight: 380, background: "rgba(19,9,6,.9)" }} spellCheck={false}
            value={code} onChange={(e) => { setCode(e.target.value); setSrcName(""); }} data-testid="run-code-editor" aria-label="Code editor" />
          <div className="flex flex-wrap items-center gap-2 border-t border-[var(--line)] px-4 py-3">
            <PeakButton className="btn-sm" onClick={run} disabled={running} testId="run-execute-button">{running ? <span className="spin inline-block h-3.5 w-3.5 rounded-full border-2 border-[#2a0d05]/40 border-t-[#2a0d05]" /> : <Play size={14} />}Run</PeakButton>
            <button className="btn btn-ghost btn-sm" onClick={() => setOut([])} data-testid="run-clear-button"><Eraser size={14} />Clear</button>
            <button className="btn btn-ghost btn-sm" onClick={downloadEditor} data-testid="run-download-button"><FileDown size={14} />Download</button>
            <button className="btn btn-ghost btn-sm" onClick={() => { setCode(SNIPPET); setLang("JavaScript"); setSrcName(""); }} data-testid="run-demo-button"><FlaskConical size={14} />Demo</button>
            {lang !== "JavaScript" && <span className="ml-auto text-xs text-[var(--amber)]" data-testid="run-nonjs-hint">view/download only — not runnable in browser</span>}
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.18 }} className="glass overflow-hidden p-0" data-testid="run-terminal-card">
          <div className="flex items-center gap-3 border-b border-[var(--line)] px-4 py-2.5">
            <Overline>Console output</Overline>
            <span data-testid="run-status">{running ? <StatusBadge status="running" /> : <StatusBadge status={out.length ? "done" : "Ready"} />}</span>
            <span className="ml-auto inline-flex items-center gap-1.5 font-code text-[10px] uppercase tracking-[0.18em] text-[var(--text-3)]"><ShieldCheck size={12} className="text-[var(--teal)]" />sandboxed</span>
          </div>
          <div ref={termRef} className="code-surface scroll-thin h-[380px] rounded-none border-0 p-4" data-testid="run-terminal">
            {!out.length && <div className="text-[var(--text-3)]">// output appears here — press Run</div>}
            <AnimatePresence initial={false}>
              {out.map((l, i) => (
                <motion.div key={i} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} className="flex items-start gap-2.5 py-0.5" data-testid={`run-line-${l.type}`}>
                  <span className="w-16 flex-none text-right text-[10px] uppercase tracking-wider text-[var(--text-3)]">{l.at}</span>
                  <span className={`w-11 flex-none font-code text-[10px] uppercase ${TONE[l.type]}`}>[{l.type}]</span>
                  <span className={`whitespace-pre-wrap break-words ${TONE[l.type]}`}>{l.text}</span>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </motion.div>
      </div>
    </Page>
  );
}
