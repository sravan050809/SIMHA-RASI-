import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { motion } from "framer-motion";
import { ChevronRight, Copy, Download, Sparkles, ListChecks, FileDown, FileCode2, TerminalSquare } from "lucide-react";
import { toast } from "sonner";
import { api, errorText, fmtDate, riskScore, LANG_EXT, downloadFile } from "@/lib/api";
import { PAGE, fadeUp, stagger } from "@/lib/motion";
import { Page } from "@/components/Shell";
import { Burst, CountUp, Overline, SeverityBadge, Spinner, StatusBadge, PeakButton } from "@/components/kit";
import { copyText } from "@/components/PatchReview";

const SEV_COLOR = { Critical: "var(--red)", High: "var(--amber)", Medium: "var(--yellow)", Low: "var(--blue)" };

function Gauge({ score }) {
  const r = 54, C = 2 * Math.PI * r; const col = score > 66 ? "var(--red)" : score > 33 ? "var(--amber)" : "var(--green)";
  return (
    <div className="relative h-40 w-40">
      <svg viewBox="0 0 120 120" className="h-40 w-40" role="img" aria-label={`Risk score ${score} of 100`}>
        <circle cx="60" cy="60" r={r} fill="none" stroke="rgba(252,184,134,.12)" strokeWidth="10" />
        <motion.circle cx="60" cy="60" r={r} fill="none" stroke={col} strokeWidth="10" strokeLinecap="round" strokeDasharray={C} transform="rotate(-90 60 60)" style={{ filter: `drop-shadow(0 0 8px ${col})` }} initial={{ strokeDashoffset: C }} animate={{ strokeDashoffset: C * (1 - score / 100) }} transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1], delay: 0.2 }} />
      </svg>
      <div className="absolute inset-0 grid place-items-center font-head text-4xl font-bold" style={{ color: col }} data-testid="results-risk-score"><CountUp value={score} duration={1400} /></div>
    </div>
  );
}

export default function Results() {
  const { sid } = useParams();
  const nav = useNavigate();
  const [scan, setScan] = useState(null);
  const [busy, setBusy] = useState(false);
  const [burst, setBurst] = useState(0);
  useEffect(() => { api.get(`/scans/${sid}`).then((r) => setScan(r.data)).catch((e) => toast.error(errorText(e))); }, [sid]);

  if (!scan) return <Page variant={PAGE.results}><div className="flex items-center gap-2 text-sm text-[var(--text-2)]"><Spinner />Loading results…</div></Page>;
  const F = scan.findings; const sev = { Critical: 0, High: 0, Medium: 0, Low: 0 }; F.forEach((f) => sev[f.severity]++);
  const score = riskScore(scan.summary); const fixed = F.filter((f) => f.status === "Fixed").length;
  const ext = LANG_EXT[scan.language] || "txt";

  const getReport = async () => (await api.get(`/scans/${sid}/report`, { responseType: "text" })).data;
  const download = async () => { try { const t = await getReport(); const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([t], { type: "text/plain" })); a.download = `sentinelgraph-${sid}.txt`; a.click(); URL.revokeObjectURL(a.href); } catch (e) { toast.error(errorText(e)); } };
  const dl = (kind, name) => downloadFile(`/scans/${sid}/download/${kind}`, name).then(() => toast.success(`${name} downloaded`)).catch((e) => toast.error(errorText(e)));
  const verifyAll = async () => {
    setBusy(true);
    try { const { data } = await api.post(`/scans/${sid}/verify-all`); setScan((s) => ({ ...s, findings: data.findings })); if (data.verified) setBurst(Date.now()); toast[data.verified === data.total ? "success" : "warning"](`${data.verified} of ${data.total} patches verified by re-analysis`); }
    catch (e) { toast.error(errorText(e)); } finally { setBusy(false); }
  };

  return (
    <Page variant={PAGE.results} testId="results-page">
      <Burst trigger={burst} />
      <nav className="mb-3 flex items-center gap-1.5 text-xs text-[var(--text-3)]" aria-label="Breadcrumb"><button className="hover:text-white" onClick={() => nav("/app")}>Command center</button><ChevronRight size={12} /><button className="hover:text-white" onClick={() => nav("/app/history")}>History</button><ChevronRight size={12} /><span className="text-[var(--text-2)]">Results</span></nav>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div><Overline className="mb-2 text-[var(--peach)]">Scan results</Overline><h1 className="text-3xl font-bold tracking-tight sm:text-4xl">{scan.project_name}</h1><p className="mt-1 text-sm text-[var(--text-2)]">{scan.language} · {fmtDate(scan.started_at)} · <StatusBadge status={scan.status} /></p></div>
        <div className="flex flex-wrap gap-2">
          <button className="btn btn-ghost btn-sm" onClick={async () => copyText(await getReport(), "Report copied")} data-testid="report-copy-button"><Copy size={14} />Copy report</button>
          <button className="btn btn-ghost btn-sm" onClick={download} data-testid="report-download-button"><Download size={14} />Report</button>
          <button className="btn btn-ghost btn-sm" onClick={() => dl("code", `main.${ext}`)} data-testid="results-download-code"><FileCode2 size={14} />Download code</button>
          {F.length > 0 && <button className="btn btn-ghost btn-sm" onClick={() => dl("corrected", `main.fixed.${ext}`)} data-testid="results-download-corrected"><FileDown size={14} />Corrected file</button>}
          <button className="btn btn-ghost btn-sm" onClick={() => nav(`/app/run?sid=${sid}&kind=${F.length ? "corrected" : "original"}`)} data-testid="results-run-code"><TerminalSquare size={14} />Run code</button>
          <PeakButton className="btn-sm" onClick={verifyAll} disabled={busy || !F.length} testId="report-verify-all-button">{busy ? <Spinner size={14} /> : <Sparkles size={14} />}Verify all patches</PeakButton>
        </div>
      </div>

      <motion.div variants={stagger(0.1)} initial="hidden" animate="show" className="mt-8 grid gap-4 md:grid-cols-3">
        <motion.div variants={fadeUp} className="glass flex flex-col items-center p-5 text-center" data-testid="results-risk-card"><Gauge score={score} /><Overline>Risk score (0 = clean)</Overline></motion.div>
        <motion.div variants={fadeUp} className="glass p-5" data-testid="results-severity-card"><Overline className="mb-4">By severity</Overline>
          {Object.entries(sev).map(([k, v], i) => <div key={k} className="mb-3 flex items-center gap-3"><SeverityBadge severity={k} /><div className="progress-track flex-1"><motion.div className="h-full rounded-full" style={{ background: SEV_COLOR[k] }} initial={{ width: 0 }} animate={{ width: `${F.length ? (v / F.length) * 100 : 0}%` }} transition={{ duration: 0.9, delay: 0.3 + i * 0.12 }} /></div><span className="w-5 text-right font-code text-sm"><CountUp value={v} /></span></div>)}
        </motion.div>
        <motion.div variants={fadeUp} className="glass relative overflow-hidden p-5" data-testid="results-patch-card">
          <div className="pointer-events-none absolute -right-10 -top-10 h-40 w-40 rounded-full bg-[var(--teal)] opacity-10 blur-3xl" />
          <Overline className="mb-3">Patch verification</Overline>
          <div className="font-head text-5xl font-semibold text-[var(--emerald)]"><CountUp value={fixed} testId="results-verified-count" /></div>
          <div className="text-sm text-[var(--text-2)]">of {F.length} verified by re-analysis</div>
          <div className="progress-track mt-4"><motion.div className="progress-fill done" initial={{ width: 0 }} animate={{ width: `${F.length ? (fixed / F.length) * 100 : 0}%` }} transition={{ duration: 1 }} /></div>
          <p className="mt-3 text-xs text-[var(--text-3)]">Verified = the same rule engine no longer finds the original path in the patched code. Not a formal proof.</p>
        </motion.div>
      </motion.div>

      <div className="glass mt-5 p-5" data-testid="results-findings-table">
        <div className="mb-2 flex items-center gap-2"><ListChecks size={16} className="text-[var(--ember)]" /><Overline>Findings</Overline></div>
        {!F.length ? <p className="py-6 text-center text-sm text-[var(--text-2)]">Clean pattern scan — no supported vulnerabilities found.</p> : (
          <ul className="divide-y divide-[var(--line)]">
            {F.map((f, i) => (
              <motion.li key={f.id} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 + i * 0.06 }}>
                <button className="group flex w-full flex-wrap items-center gap-3 py-3 text-left" onClick={() => nav(`/app/scan/${sid}/finding/${f.id}?tab=patch`)} data-testid={`results-finding-${f.id}`}>
                  <SeverityBadge severity={f.severity} /><span className="min-w-0 flex-1 truncate font-medium">{f.title}</span><span className="font-code text-xs text-[var(--text-3)]">{f.cwe} · L{f.line}</span><StatusBadge status={f.patch.status} /><ChevronRight size={16} className="text-[var(--text-3)] group-hover:text-[var(--ember)]" />
                </button>
              </motion.li>
            ))}
          </ul>
        )}
      </div>
    </Page>
  );
}
