import { useState } from "react";
import { motion } from "framer-motion";
import { Copy, Check, ShieldCheck, Wrench, AlertTriangle, CheckCircle2, XCircle, FileDown } from "lucide-react";
import { toast } from "sonner";
import { Overline, Spinner, StatusBadge, Burst } from "@/components/kit";
import { fmtDate } from "@/lib/api";

export const copyText = async (text, label = "Copied") => {
  try { await navigator.clipboard.writeText(text); toast.success(label); }
  catch { toast.error("Clipboard unavailable in this browser"); }
};

export const downloadText = (text, name) => {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([text], { type: "text/plain" }));
  a.download = name;
  a.click();
  URL.revokeObjectURL(a.href);
  toast.success(`${name} downloaded`);
};

export function CodeView({ code, badLine, taintLines = [], testId }) {
  const taint = new Set(taintLines);
  return (
    <div className="code-surface scanlines scroll-thin max-h-[520px] py-2" data-testid={testId}>
      {code.split("\n").map((l, i) => (
        <div key={i} className={`code-line ${i + 1 === badLine ? "is-bad" : taint.has(i + 1) ? "is-taint" : ""}`} data-testid={i + 1 === badLine ? "code-line-vulnerable" : undefined}>
          <span className="ln">{i + 1}</span><span>{l || " "}</span>
        </div>
      ))}
    </div>
  );
}

function CopyButton({ text, label, testId }) {
  const [ok, setOk] = useState(false);
  return <button className="btn btn-ghost btn-sm" onClick={async () => { await copyText(text, label + " copied"); setOk(true); setTimeout(() => setOk(false), 1500); }} data-testid={testId}>{ok ? <Check size={14} className="text-[var(--emerald)]" /> : <Copy size={14} />}{label}</button>;
}

export function PatchReview({ finding, file, onApply, onVerify, busy }) {
  const p = finding.patch; const v = p.verification;
  const diffText = `--- a/${file}\n+++ b/${file}\n` + p.diff.map((d) => d[0] + d[1]).join("\n");
  return (
    <div className="space-y-5" data-testid="patch-review">
      <Burst trigger={p.status === "Verified" ? v?.verified_at : 0} />
      <div className={`glass p-5 ${p.status === "Verified" ? "border-[rgba(47,185,198,.45)] shadow-[0_0_40px_rgba(47,185,198,.12)]" : ""}`}>
        <div className="flex flex-wrap items-center gap-3">
          <StatusBadge status={p.status} testId="patch-status-badge" />
          <span className="text-sm text-[var(--text-2)]">{p.status === "Generated" ? "Suggestion only — nothing has been changed." : p.status === "Applied" ? "Marked as applied in your codebase; not yet verified." : "Re-analysis of the patched code no longer finds this path."}</span>
          <div className="ml-auto flex gap-2">
            <button className="btn btn-ghost btn-sm" onClick={onApply} disabled={busy || p.status !== "Generated"} data-testid="patch-apply-button"><Wrench size={14} />Mark applied</button>
            <button className={`btn btn-sm ${p.status === "Verified" ? "btn-emerald" : "btn-primary"}`} onClick={onVerify} disabled={busy} data-testid="patch-verify-button">{busy ? <Spinner size={14} /> : <ShieldCheck size={14} />}{p.status === "Verified" ? "Re-verify" : "Verify patch"}</button>
          </div>
        </div>
        <p className="mt-4 text-sm leading-relaxed text-[var(--text-2)]">{p.explanation}</p>
        <div className="mt-3 flex items-start gap-2 rounded-lg border border-amber-500/20 bg-amber-500/5 px-3 py-2 text-xs text-amber-100/80"><AlertTriangle size={14} className="mt-0.5 flex-none" />Generated patches are conservative and language-aware, but they are a starting point. Review them like any other code change.</div>
      </div>

      {v && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="glass p-5" data-testid="patch-verification-result">
          <div className="flex items-center gap-2">{v.passed ? <CheckCircle2 className="text-[var(--emerald)]" size={18} /> : <XCircle className="text-[var(--crimson)]" size={18} />}<h3 className="font-semibold">{v.passed ? "Verification passed" : "Verification failed — path still reachable"}</h3><span className="ml-auto text-xs text-[var(--text-3)]">{fmtDate(v.verified_at)}</span></div>
          <p className="mt-1 text-xs text-[var(--text-3)]">{v.method}</p>
          <ul className="mt-3 space-y-1.5 text-sm">{v.checks.map((c) => <li key={c.name} className="flex items-center gap-2">{c.passed ? <Check size={14} className="text-[var(--emerald)]" /> : <XCircle size={14} className="text-[var(--crimson)]" />}<span className={c.passed ? "text-[var(--text-2)]" : "text-red-200"}>{c.name}</span></li>)}</ul>
          <p className="mt-3 text-xs text-[var(--text-3)]">{v.limitations}</p>
        </motion.div>
      )}

      <div className="glass p-5">
        <div className="flex flex-wrap items-center justify-between gap-2"><Overline>Unified diff</Overline>
          <div className="flex flex-wrap gap-2">
            <CopyButton text={diffText} label="Copy diff" testId="patch-copy-diff" />
            <CopyButton text={p.patched_code} label="Copy patched file" testId="patch-copy-file" />
            <button className="btn btn-ghost btn-sm" onClick={() => downloadText(diffText, `${file}.patch`)} data-testid="patch-download-diff"><FileDown size={14} />Diff</button>
            <button className="btn btn-ghost btn-sm" onClick={() => downloadText(p.patched_code, `fixed-${file}`)} data-testid="patch-download-file"><FileDown size={14} />Download file</button>
          </div>
        </div>
        <div className="code-surface scroll-thin mt-3 py-2" data-testid="patch-diff">
          {p.diff.map((d, i) => (
            <motion.div key={i} initial={{ opacity: 0, x: d[0] === " " ? 0 : -8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.05 + i * 0.03 }} className={`code-line ${d[0] === "+" ? "d-add" : d[0] === "-" ? "d-del" : ""}`}><span className="ln">{d[0]}</span><span>{d[1] || " "}</span></motion.div>
          ))}
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <div className="glass p-5"><Overline className="mb-3">Original</Overline><CodeView code={p.original_code} badLine={finding.line} taintLines={finding.cl} testId="patch-original-code" /></div>
        <div className="glass p-5"><Overline className="mb-3 text-[var(--emerald)]">Patched</Overline><CodeView code={p.patched_code} testId="patch-patched-code" /></div>
      </div>
    </div>
  );
}
