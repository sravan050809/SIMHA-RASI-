import { createContext, useCallback, useContext, useEffect, useState } from "react";
import { api } from "@/lib/api";

const AuthCtx = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null); // null = checking, false = anonymous, object = authenticated
  const [expired, setExpired] = useState(false);

  const checkAuth = useCallback(async () => {
    try {
      const { data } = await api.get("/auth/me");
      setUser(data);
    } catch {
      setUser(false);
    }
  }, []);

  useEffect(() => {
    checkAuth();
  }, [checkAuth]);

  useEffect(() => {
    const onExpired = () => { setUser(false); setExpired(true); };
    window.addEventListener("sg:session-expired", onExpired);
    return () => window.removeEventListener("sg:session-expired", onExpired);
  }, []);

  const logout = useCallback(async () => {
    try { await api.post("/auth/logout"); } catch { /* cookie may already be gone */ }
    setUser(false);
  }, []);

  return <AuthCtx.Provider value={{ user, setUser, logout, expired, setExpired, checkAuth }}>{children}</AuthCtx.Provider>;
}

export const useAuth = () => useContext(AuthCtx);
