@echo off
setlocal EnableExtensions
title SentinelGraph
color 0B

rem ===================================================================
rem  SentinelGraph - run the whole project with one double-click
rem
rem  1. finds Python 3
rem  2. creates backend\.venv and installs the backend packages
rem     (first run only)
rem  3. checks MongoDB on localhost:27017
rem  4. installs the frontend packages with yarn (first run only)
rem  5. starts backend  ->  http://127.0.0.1:8001
rem  6. starts frontend  ->  http://localhost:3000
rem  7. opens the app in your browser
rem
rem  Everything runs in THIS window; output goes to logs\*.log.
rem  Press any key here to stop. Run "run.bat stop" from anywhere
rem  to stop servers left over from an earlier run.
rem
rem  Optional environment variables:
rem    SG_PYTHON              full path to python.exe to use
rem    REACT_APP_BACKEND_URL  use a remote API instead of the local one
rem    SG_NO_BROWSER          do not open the browser automatically
rem ===================================================================

set "ROOT=%~dp0"
set "BACKEND_PORT=8001"
set "FRONTEND_PORT=3000"
set "LOGS=%ROOT%logs"

rem -- handed to the servers (they inherit this environment) -----------
set "CORS_ORIGINS=http://localhost:3000,http://127.0.0.1:3000"
set "BROWSER=none"
set "PORT=%FRONTEND_PORT%"
set "WDS_SOCKET_PORT=%FRONTEND_PORT%"
set "COREPACK_ENABLE_DOWNLOAD_PROMPT=0"
if not defined REACT_APP_BACKEND_URL set "REACT_APP_BACKEND_URL=http://127.0.0.1:%BACKEND_PORT%"

if /i "%~1"=="stop" goto :stop_only

echo.
echo  ===================================================
echo    SentinelGraph - starting local environment
echo  ===================================================
echo.

rem -- clear leftovers from an earlier run ------------------------------
call :stop_servers

rem ------------------------------------------------------------------ 1 -
call :find_python
if not defined PYTHON goto :no_python
"%PYTHON%" -c "import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)" >nul 2>&1
if errorlevel 1 goto :old_python
echo  [1/6] Python            %PYTHON%

rem ------------------------------------------------------------------ 2 -
set "VENV=%ROOT%backend\.venv"
if exist "%VENV%\Scripts\python.exe" goto :venv_ready
echo  [2/6] Creating the backend virtual environment - first run only
"%PYTHON%" -m venv "%VENV%"
if errorlevel 1 goto :venv_failed
:venv_ready
call :deps_ready
if not errorlevel 1 goto :deps_ok
echo  [2/6] Installing the backend packages - first run only
"%VENV%\Scripts\python.exe" -m pip install --disable-pip-version-check --quiet --upgrade pip
"%VENV%\Scripts\python.exe" -m pip install --disable-pip-version-check --quiet -r "%ROOT%backend\requirements.txt"
if not errorlevel 1 goto :req_done
echo        Some pinned packages failed to build - using the core set instead
:req_done
call :deps_ready
if not errorlevel 1 goto :deps_ok
echo        Installing the missing runtime packages
"%VENV%\Scripts\python.exe" -m pip install --disable-pip-version-check --quiet fastapi uvicorn motor pydantic email-validator pyjwt python-dotenv argon2-cffi python-multipart
call :deps_ready
if not errorlevel 1 goto :deps_ok
echo  [FAIL] The backend packages are incomplete - read the messages above
goto :fail
:deps_ok
echo  [2/6] Backend packages   ready

rem ------------------------------------------------------------------ 3 -
netstat -an | findstr /C:":27017 " | findstr /C:"LISTENING" >nul 2>&1
if not errorlevel 1 goto :mongo_ok
echo  [WARN] No MongoDB is listening on localhost:27017
echo         Start MongoDB, otherwise the backend cannot store anything
:mongo_ok
echo  [3/6] MongoDB            checked

rem ------------------------------------------------------------------ 4 -
call :pick_yarn
if exist "%ROOT%frontend\node_modules\react-scripts\package.json" goto :fe_ready
echo  [4/6] Installing the frontend packages with yarn - can take a few minutes
pushd "%ROOT%frontend"
%YARN_CMD% install
set "YARN_RC=%errorlevel%"
popd
if not "%YARN_RC%"=="0" goto :fe_failed
:fe_ready
echo  [4/6] Frontend packages  ready

rem -- refuse to run if the ports are already taken ---------------------
netstat -an | findstr /C:":%BACKEND_PORT% " | findstr /C:"LISTENING" >nul 2>&1
if not errorlevel 1 goto :port_busy
netstat -an | findstr /C:":%FRONTEND_PORT% " | findstr /C:"LISTENING" >nul 2>&1
if not errorlevel 1 goto :port_busy

rem ------------------------------------------------------------------ 5 -
if not exist "%LOGS%" mkdir "%LOGS%"
echo  [5/6] Starting the backend  -  log: logs\backend.log
pushd "%ROOT%backend"
start "" /b ".venv\Scripts\python.exe" -m uvicorn server:app --host 127.0.0.1 --port %BACKEND_PORT% > "..\logs\backend.log" 2>&1
popd

echo  [6/6] Starting the frontend  -  log: logs\frontend.log
pushd "%ROOT%frontend"
start "" /b %YARN_CMD% start > "..\logs\frontend.log" 2>&1
popd

rem -- wait until both ports answer --------------------------------------
set "BE_UP="
set "FE_UP="
set /a WAITED=0
:wait_loop
ping -n 3 127.0.0.1 >nul
netstat -an | findstr /C:":%BACKEND_PORT% " | findstr /C:"LISTENING" >nul 2>&1
if not errorlevel 1 set "BE_UP=1"
netstat -an | findstr /C:":%FRONTEND_PORT% " | findstr /C:"LISTENING" >nul 2>&1
if not errorlevel 1 set "FE_UP=1"
if defined BE_UP if defined FE_UP goto :all_up
set /a WAITED+=2
if not defined BE_UP if %WAITED% geq 60 goto :backend_failed
if not defined FE_UP if %WAITED% geq 210 goto :frontend_failed
goto :wait_loop

:all_up
echo.
echo  --------------------------------------------------
echo   backend   http://127.0.0.1:%BACKEND_PORT%    API docs: /docs
echo   frontend  http://localhost:%FRONTEND_PORT%
echo  --------------------------------------------------
echo.

rem -- remember which pids answer on our ports, so "run.bat stop" can
rem    kill exactly these two trees first (the pattern match below is the
rem    safety net for anything they forked, e.g. the yarn wrapper).
powershell -NoProfile -Command "$ids=@(); foreach($p in @(%BACKEND_PORT%,%FRONTEND_PORT%)){ $ids += Get-NetTCPConnection -LocalPort $p -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess }; $ids = @($ids | Sort-Object -Unique); if($ids.Count){ ($ids -join [char]10) | Out-File -FilePath $env:LOGS\servers.pids -Encoding ascii }" >nul 2>&1
echo.

if defined SG_NO_BROWSER goto :no_browser
start "" "http://localhost:%FRONTEND_PORT%"
:no_browser

call :probe_interactive
if "%INTERACTIVE%"=="1" goto :wait_key
goto :wait_watchdog

:wait_key
echo  Press any key in this window to stop the servers ...
pause >nul
call :stop_servers
echo  Stopped. Bye.
exit /b 0

:wait_watchdog
rem No keyboard here (started from a script): keep watching instead.
ping -n 11 127.0.0.1 >nul
netstat -an | findstr /C:":%BACKEND_PORT% " | findstr /C:"LISTENING" >nul 2>&1
if not errorlevel 1 goto :wait_watchdog
netstat -an | findstr /C:":%FRONTEND_PORT% " | findstr /C:"LISTENING" >nul 2>&1
if not errorlevel 1 goto :wait_watchdog
echo  Both servers stopped - exiting.
exit /b 0

rem ===================================================================
rem  failure paths
rem ===================================================================
:port_busy
echo  [FAIL] Port %BACKEND_PORT% or %FRONTEND_PORT% is already in use.
echo         Run "run.bat stop" first, or close whatever is using it.
goto :fail

:backend_failed
echo  [FAIL] The backend did not start. Last lines of logs\backend.log:
powershell -NoProfile -Command "Get-Content -LiteralPath '%LOGS%\backend.log' -Tail 25"
call :stop_servers
goto :fail

:frontend_failed
echo  [FAIL] The frontend did not start. Last lines of logs\frontend.log:
powershell -NoProfile -Command "Get-Content -LiteralPath '%LOGS%\frontend.log' -Tail 25"
call :stop_servers
goto :fail

:fail
echo.
echo  Startup did not finish - fix the message above and run it again.
echo.
call :probe_interactive
if "%INTERACTIVE%"=="1" pause
exit /b 1

:no_python
echo  [FAIL] No Python 3 interpreter was found
echo         Install Python 3.9 or newer from https://www.python.org/downloads/
echo         and tick "Add python.exe to PATH", then run this file again.
goto :fail

:old_python
echo  [FAIL] %PYTHON% is older than Python 3.9
goto :fail

:venv_failed
echo  [FAIL] Could not create backend\.venv
goto :fail

:fe_failed
echo  [FAIL] Installing the frontend packages failed
echo         Re-run this file; yarn will continue where it stopped.
goto :fail

:stop_only
call :stop_servers
echo  Stopped any running SentinelGraph servers.
exit /b 0

rem ===================================================================
rem  helpers
rem ===================================================================

:find_python
set "PYTHON="
if defined SG_PYTHON set "PYTHON=%SG_PYTHON%"
if defined PYTHON exit /b 0
for %%V in (314 313 312 311 310 39) do (
  if not defined PYTHON if exist "%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe" set "PYTHON=%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe"
)
if defined PYTHON exit /b 0
where py >nul 2>&1
if not errorlevel 1 for /f "delims=" %%i in ('py -3 -c "import sys; print(sys.executable)" 2^>nul') do set "PYTHON=%%i"
if defined PYTHON exit /b 0
where python >nul 2>&1
if not errorlevel 1 for /f "delims=" %%i in ('python -c "import sys; print(sys.executable)" 2^>nul') do set "PYTHON=%%i"
exit /b 0

:deps_ready
"%VENV%\Scripts\python.exe" -c "import fastapi, uvicorn, motor, dotenv, jwt, argon2, email_validator, multipart" >nul 2>&1
exit /b %errorlevel%

:pick_yarn
rem Prefer corepack: it picks the exact yarn version pinned in package.json.
set "YARN_CMD=npx --yes yarn@1.22.22"
where corepack >nul 2>&1
if not errorlevel 1 set "YARN_CMD=corepack yarn"
exit /b 0

:probe_interactive
rem 1 = this window has a keyboard, 0 = it was started by a script
set "INTERACTIVE=1"
where powershell >nul 2>&1
if errorlevel 1 exit /b 0
powershell -NoProfile -Command "exit [int]([Console]::IsInputRedirected)" >nul 2>&1
if errorlevel 1 set "INTERACTIVE=0"
exit /b 0

:stop_servers
rem 1) the processes this launcher started, by recorded PID
if exist "%LOGS%\servers.pids" (
  for /f "usebackq delims=" %%I in ("%LOGS%\servers.pids") do taskkill /F /T /PID %%I >nul 2>&1
  del "%LOGS%\servers.pids" >nul 2>&1
)
rem 2) anything still matching our own commands.
rem    The patterns are assembled at runtime so this command line does not
rem    match itself (that would kill the shell that is running it).
powershell -NoProfile -Command "$a='uvi'+'corn server:app'; $b='react'+'-scripts'; $c='crac'+'o'; $d='sentin'+'elgraph'; Get-CimInstance Win32_Process | Where-Object { $_.ProcessId -ne $PID -and (($_.CommandLine -match $a) -or (($_.CommandLine -match $b -or $_.CommandLine -match $c) -and $_.CommandLine -match $d)) } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }" >nul 2>&1
ping -n 3 127.0.0.1 >nul
exit /b 0
