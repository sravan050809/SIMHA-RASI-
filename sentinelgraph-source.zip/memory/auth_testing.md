# SentinelGraph Auth Testing Playbook

Two login methods share the `users` collection (custom `user_id` field, `_id` never exposed):
1. Email + password → JWT `access_token` (15 min) + `refresh_token` (7 d) httpOnly cookies. Endpoints: POST /api/auth/register, /api/auth/login, /api/auth/logout, /api/auth/refresh, GET /api/auth/me, POST /api/auth/forgot-password, /api/auth/reset-password.
2. Emergent Google → POST /api/auth/session {session_id} → sets `session_token` httpOnly cookie (7 d, stored in `user_sessions`).

`get_current_user` checks cookies `session_token` → `access_token`, then `Authorization: Bearer <token>` (either a session token or a JWT access token).

## Step 1: Email/password (admin is seeded on startup from .env)
```
curl -c c.txt -X POST $API/api/auth/login -H "Content-Type: application/json" -d '{"email":"admin@sentinelgraph.dev","password":"Sentinel!2026"}'
curl -b c.txt $API/api/auth/me
curl -b c.txt $API/api/projects
```
Brute force: 5 failed logins for the same ip:email → 15 min lockout (HTTP 429).

## Step 2: Google-style session (mongosh)
```
mongosh --eval "
use('test_database');
var userId = 'user_test' + Date.now();
var tok = 'test_session_' + Date.now();
db.users.insertOne({user_id:userId,email:'test.user.'+Date.now()+'@example.com',name:'Test User',picture:'',provider:'google',role:'analyst',created_at:new Date()});
db.user_sessions.insertOne({user_id:userId,session_token:tok,expires_at:new Date(Date.now()+7*24*60*60*1000),created_at:new Date()});
print(tok);"
curl $API/api/auth/me -H "Authorization: Bearer <tok>"
```

## Step 3: Browser
Set cookie `access_token` (from step 1) or `session_token` (step 2) with domain = preview host, path=/, httpOnly, secure, sameSite=None, then open `/app`.

## Checklist
- /api/auth/me returns `user_id`, `email`, `name`, `provider`
- Protected pages (/app, /app/history) load without redirect to /login
- Projects / scans are only visible to their owner (403/404 for other users)
