# Test Credentials
# Agent writes here when creating/modifying auth credentials (admin accounts, test users).
# Testing agent reads this before auth tests. Fork/continuation agents read on startup.

## SentinelGraph admin (seeded on backend startup from backend/.env)
- Email: admin@sentinelgraph.dev
- Password: Sentinel!2026
- Role: admin (a demo project "Demo: Flask login lookup" is auto-created on first login)

## Notes
- Login page: /login (email/password form). Google OAuth button also present (Emergent-managed).
- After 5 failed logins the account locks for 15 minutes — use correct credentials.
- API base: {REACT_APP_BACKEND_URL}/api. httpOnly cookie auth; Authorization: Bearer <access_token> also works.
