# SentinelGraph — Product Requirements & Status

## Original problem statement (latest session)
User uploaded `sentinelgraph-source.zip` (full-stack security scanner) + a "Copper Tones" palette image (#894329 · #12727D · #FCB886) and asked: remove all old color palettes, replace colors with sunset colors, best font styles, restructure the app a new way, professional new animations, peak button animations, extreme security-themed transition animations, special-character animations, download corrected file + download code after scanning, a page to run the code, make it beautiful.

## Architecture
- **Backend** FastAPI (`/app/backend`): `server.py` (projects, staged background scans, findings apply/verify, verify-all, report, dashboard stats, **NEW: `GET /api/scans/{sid}/download/code` and `/download/corrected`** with merged multi-patch output via `scanner.merge_patches`), `auth.py` (Argon2id + JWT httpOnly cookies + Emergent Google session, lockout), `scanner.py` (rules + intra-file taint, patches, diff, verify_patch, merge_patches). 24 pytest cases passing (incl. 3 new download tests).
- **Frontend** React 19 + Tailwind + framer-motion (`/app/frontend/src`): "Solar Dusk" sunset design system in `index.css` (ember #FF7A45 primary, peach #FCB886, copper #D97A4E, teal #2FB9C6 counterpoint on deep dusk #150A07); fonts Bricolage Grotesque / Instrument Sans / JetBrains Mono; sidebar Shell layout; `kit.jsx` adds `PeakButton` (magnetic + shine sweep + ripple) and `ScrambleText` (glyph decrypt); `Shell.jsx` adds `RouteCipher` (cipher-rain + ember beam route transitions); ScanPage has radar sweep, flicker code reveal, lock-pop, border-flow celebration panel with download/run buttons; **NEW page `/app/run`** = sandboxed JS runtime (iframe `allow-scripts`, postMessage console capture, 6s timeout) that can load corrected/original scan code.
- **DB** MongoDB: users, user_sessions, projects, scans, login_attempts, password_reset_tokens.

## Implemented (2026-10-10)
- Full re-theme: every old teal/violet color removed (0 occurrences of #71BBD1/#2B7A77/#EB91E2), sunset palette everywhere incl. ExploitGraph nodes, ShieldScene canvas, ambient field.
- Structure: top navbar → left sidebar (desktop) with user card; mobile top bar + drawer kept.
- Downloads: corrected file (merged patches, X-Patches-Applied/Skipped headers) + original code on scan completion panel, Results page, and per-finding patch tab (file + diff).
- Run code page with sandboxed JS execution + scan code loading (`?sid=&kind=`).
- Testing agent iteration 1: 100% pass (backend 24/24, frontend all flows), no retest needed.

## Known limitations
- Password reset token is logged server-side (no email provider configured).
- Corrected-file merge is best-effort; overlapping patches are skipped (reported via header).
- Run page executes JavaScript only (browser sandbox); other languages view/download.
- Scanner is pattern + taint evidence, not proof; verification = re-analysis with same engine.
- Env: MONGO_URL, DB_NAME, CORS_ORIGINS, JWT_SECRET, ADMIN_EMAIL, ADMIN_PASSWORD.

## Backlog
- P1: multi-file projects / cross-file taint; email provider for password reset; MFA.
- P2: PDF/JSON report export; per-rule toggles; server-side sandboxed runners for Python (isolated container).


## 2026-10-10 — Source export
- Added `GET /api/export/source` serving `backend/public/sentinelgraph-source.zip` (full project source, no node_modules).
- Added "Download source" button on Dashboard (`dashboard-download-source-link`). Verified real browser download.
