"""Rule-based taint scanner + conservative patch synthesizer (server-side port of the SentinelGraph engine)."""
import re
import uuid
from typing import Dict, List, Optional

LANGS = ["Python", "JavaScript", "TypeScript", "Java", "PHP", "C", "C++"]
EXT = {"py": "Python", "js": "JavaScript", "jsx": "JavaScript", "ts": "TypeScript", "tsx": "TypeScript",
       "java": "Java", "php": "PHP", "c": "C", "h": "C", "cpp": "C++", "cc": "C++", "hpp": "C++"}
XO = {"Python": "py", "JavaScript": "js", "TypeScript": "ts", "Java": "java", "PHP": "php", "C": "c", "C++": "cpp"}

DEMO_CODE = (
    'from flask import request\nimport sqlite3\n\nusername = request.args.get("username")\n'
    'query = "SELECT * FROM users WHERE name = \'" + username + "\'"\n'
    'cursor = sqlite3.connect("users.db").cursor()\ncursor.execute(query)\nprint(cursor.fetchall())'
)

SRC = re.compile(r"request\.(args|form|values|json)|\binput\(|req\.(query|body|params)|\$_(GET|POST|REQUEST|COOKIE)"
                 r"|getParameter\(|\bargv\b|\bgets\(|\bscanf\(|getenv\(|location\.(search|hash)")
SAN = re.compile(r"basename\(|fullmatch\(|preg_match\(|\.matches\(|strstr\(|strpbrk\(|html\.escape|escapeHtml"
                 r"|htmlspecialchars|HtmlUtils\.escape|/\^[^\n]*\$/\.test\(")
ASG = re.compile(r"^\s*(?:[\w<>\[\]\*:]+\s+)*\$?(\w+)\s*=[^=]")
COMMENT = re.compile(r"^\s*(#|//)")
PARAMETERIZED = re.compile(r"\(\s*\w+\s*,\s*[\(\[]|,\s*[\(\[][^()\[\]]*[\)\]]\s*\)\s*;?\s*$|prepare\(|setString\(")

RULES = [
    dict(k="sql", t="SQL Injection", cwe="CWE-89", sev="Critical",
         re=re.compile(r"\.(execute|executemany|query|executeQuery|executeUpdate|raw)\s*\(|mysqli?_query\("),
         imp="Data breach / login bypass",
         why="User text is glued into a database command, so an attacker can change what the command does."),
    dict(k="cmd", t="Command Injection", cwe="CWE-78", sev="Critical",
         re=re.compile(r"os\.system\(|subprocess\.\w+\(|child_process|execSync\(|\.exec\(|\bsystem\(|popen\("
                       r"|Runtime\.getRuntime\(\)\.exec|shell_exec\(|passthru\("),
         imp="Remote code execution",
         why="User text is passed to the operating system shell, so an attacker may run their own commands."),
    dict(k="path", t="Path Traversal", cwe="CWE-22", sev="High",
         re=re.compile(r"\bopen\(|readFile(Sync)?\(|fopen\(|file_get_contents\(|new File\(|FileInputStream\(|sendFile\("),
         imp="Reading files outside the allowed folder",
         why='User text decides which file is opened, so "../" tricks can reach private files.'),
    dict(k="xss", t="Cross-Site Scripting (XSS)", cwe="CWE-79", sev="High",
         re=re.compile(r"innerHTML\s*=|document\.write\(|res\.(send|write)\(|\becho\b|render_template_string\(|\.html\("),
         imp="Attacker script runs in a visitor's browser",
         why="User text is shown on a web page without encoding, so it can run as a script."),
    dict(k="deser", t="Unsafe Deserialization", cwe="CWE-502", sev="High",
         re=re.compile(r"pickle\.loads?\(|yaml\.load\(|unserialize\(|ObjectInputStream|\beval\("),
         imp="Remote code execution",
         why="Untrusted data is turned back into objects/code, which can run attacker-chosen logic."),
    dict(k="bof", t="Buffer Overflow", cwe="CWE-120", sev="High",
         re=re.compile(r"\b(strcpy|strcat|gets|sprintf)\s*\("), imp="Memory corruption", langs=["C", "C++"], nt=True,
         why="This copy has no size limit, so long input can overwrite nearby memory."),
]


def uid() -> str:
    return uuid.uuid4().hex[:10]


def _var_re(v: str):
    return re.compile(r"(?<!\w)\$?" + re.escape(v) + r"\b")


def scan(code: str, lang: str) -> List[dict]:
    lines = code.split("\n")
    tainted: Dict[str, dict] = {}
    findings: List[dict] = []
    seen = set()
    for i, line in enumerate(lines):
        if COMMENT.match(line):
            continue
        m = ASG.match(line)
        if SAN.search(line):
            cleared = {v for v in tainted if _var_re(v).search(line)}
            if m:
                cleared.add(m.group(1))
            changed = True
            while changed:  # copies derived from a validated variable are treated as validated too
                changed = False
                for v, info in tainted.items():
                    if v not in cleared and info["from"] in cleared:
                        cleared.add(v)
                        changed = True
            for v in cleared:
                tainted.pop(v, None)
            continue
        if m:
            rhs = line[line.index("=") + 1:]
            sm = SRC.search(rhs)
            if sm:
                tainted[m.group(1)] = {"line": i + 1, "from": None, "src": sm.group(0)}
            else:
                d = next((v for v in tainted if _var_re(v).search(rhs)), None)
                if d:
                    tainted[m.group(1)] = {"line": i + 1, "from": d, "src": None}
        for r in RULES:
            if r.get("langs") and lang not in r["langs"]:
                continue
            rm = r["re"].search(line)
            if not rm or (i, r["k"]) in seen:
                continue
            if r["k"] == "sql" and PARAMETERIZED.search(line):
                continue
            vs = [v for v in tainted if _var_re(v).search(line) and tainted[v]["line"] < i + 1 and not (m and m.group(1) == v)]
            inl = bool(SRC.search(line))
            if not r.get("nt") and not vs and not inl:
                continue
            seen.add((i, r["k"]))
            chain: List[str] = []
            c: Optional[str] = vs[0] if vs else None
            while c and c in tainted:
                chain.insert(0, c)
                c = tainted[c]["from"]
            sl = tainted[chain[0]]["line"] if chain else i + 1
            src_m = SRC.search(line)
            sx = (tainted[chain[0]]["src"] if chain else (src_m.group(0) if src_m else None)) or rm.group(0)
            sk = rm.group(0).rstrip("(") + "()"
            if chain:
                confidence, method = "High", "Taint tracking: attacker-controlled input flows through variables into the sink."
            elif inl:
                confidence, method = "Medium", "Inline pattern: an input source and a dangerous sink appear on the same line."
            else:
                confidence, method = "Low", "Pattern only: an unsafe function was found, but no attacker-controlled input was traced to it."
            nodes, edges = [], []

            def nd(nid, t, lb, ln, ex):
                nodes.append(dict(id=nid, node_type=t, label=lb, file_path="main." + XO[lang], line_number=ln,
                                  code_snippet=(lines[ln - 1] if 0 < ln <= len(lines) else "").strip(), explanation=ex))

            def ed(a, b, t, lb):
                edges.append(dict(id="e%d" % len(edges), source_node_id=a, target_node_id=b, edge_type=t, label=lb))

            nd("n_en", "ENTRY_POINT", "User request", sl, "This is where outside data enters the app. Anyone on the internet can control it.")
            nd("n_so", "SOURCE", sx + "()", sl, "Attacker-controlled input. The app trusts this value without checking it.")
            ed("n_en", "n_so", "DATA_FLOW", "user input")
            pv = "n_so"
            for j, v in enumerate(chain):
                nd("v%d" % j, "VARIABLE", v, tainted[v]["line"], 'Variable "%s" carries the untrusted value forward ("tainted").' % v)
                ed(pv, "v%d" % j, "TAINTS", "tainted")
                pv = "v%d" % j
            nd("n_sk", "SINK", sk, i + 1, "Dangerous operation. If it receives tainted data, the attacker controls it.")
            ed(pv, "n_sk", "REACHES_SINK", "reaches sink")
            nd("n_im", "IMPACT", r["imp"], i + 1, "What can go wrong: " + r["imp"] + ".")
            ed("n_sk", "n_im", "CAUSES", "causes")
            nd("n_mg", "MISSING_GUARD", "Missing check", i + 1, "No validation, escaping or parameterization exists before the sink.")
            ed("n_mg", "n_sk", "DATA_FLOW", "unchecked")
            nd("n_pa", "PATCH", "Secure fix", i + 1, "The suggested patch adds the missing protection and breaks the attack path.")
            ed("n_pa", "n_sk", "PATCHED_BY", "patched by")
            f = dict(id=uid(), k=r["k"], title=r["t"] + " in " + sk, type=r["t"], cwe=r["cwe"], severity=r["sev"],
                     confidence=confidence, detection_method=method, file="main." + XO[lang], line=i + 1, desc=r["why"],
                     snippet=line.strip(), status="Open", V=chain[0] if chain else "", cl=[tainted[v]["line"] for v in chain],
                     graph=dict(nodes=nodes, edges=edges))
            f["patch"] = make_patch(lines, lang, f)
            findings.append(f)
    return findings


def make_patch(L: List[str], lang: str, f: dict) -> dict:
    o = list(L)
    i = f["line"] - 1
    V = f["V"] or "user_input"
    py, js, ph, jv = lang == "Python", "Script" in lang, lang == "PHP", lang == "Java"
    ind = re.match(r"^\s*", o[i]).group(0)
    pv = ("$" + V) if ph else V
    g, ex = None, ""
    k = f["k"]
    if k == "sql":
        qi = next((n for n in f["cl"] if re.search(r"select|insert|update|delete", L[n - 1], re.I)), None)
        if qi:
            m = re.match(r'^(.*?=\s*)f?(["\'])(.*?)\2', L[qi - 1])
            if m:
                s = re.sub(r"'?(\{\w+\}|\$\{\w+\}|%s)'?", "?", m.group(3))
                if "?" not in s:
                    s = re.sub(r"'\s*$", "", s) + "?"
                o[qi - 1] = m.group(1) + m.group(2) + s + m.group(2)
        if py:
            o[i] = re.sub(r"\(\s*(\w+)\s*\)", r"(\1, (" + V + ",))", o[i], count=1)
        elif js:
            o[i] = re.sub(r"\(\s*(\w+)\s*\)", r"(\1, [" + V + "])", o[i], count=1)
        elif jv:
            o[i] = ind + "PreparedStatement ps = conn.prepareStatement(query); ps.setString(1, " + V + "); ResultSet rs = ps.executeQuery();"
        elif ph:
            o[i] = ind + "$stmt = $pdo->prepare($query); $stmt->execute([" + pv + "]);"
        ex = 'The query text now has a "?" placeholder and the value is sent separately, so the database never treats it as code. Behavior for normal input is unchanged.'
    elif k == "cmd":
        o[i] = o[i].replace("shell=True", "shell=False")
        if py:
            g = 'if not re.fullmatch(r"[\\w.\\-]+", ' + V + '): raise ValueError("invalid input")'
        elif js:
            g = "if (!/^[\\w.\\-]+$/.test(" + V + ')) throw new Error("invalid input");'
        elif ph:
            g = "if (!preg_match('/^[\\w.\\-]+$/', " + pv + ")) die('invalid input');"
        elif jv:
            g = "if (!" + V + '.matches("[\\\\w.\\\\-]+")) throw new IllegalArgumentException("invalid input");'
        else:
            g = "if (strpbrk(" + V + ', ";|&$`")) return 1;'
        ex = "Input is checked against a strict allowlist (letters, digits, dot, dash) and the shell is not used to interpret it."
    elif k == "path":
        if py:
            g = V + " = os.path.basename(" + V + ')  # drops folders and ".."'
        elif js:
            g = V + ' = require("path").basename(' + V + ");"
        elif ph:
            g = pv + " = basename(" + pv + ");"
        elif jv:
            g = V + " = java.nio.file.Paths.get(" + V + ").getFileName().toString();"
        else:
            g = "if (strstr(" + V + ', "..")) return 1;'
        ex = 'Only the file name is kept, so "../" tricks cannot leave the allowed folder. Join it to your safe base directory.'
    elif k == "xss":
        e = "html.escape" if py else "escapeHtml" if js else "htmlspecialchars" if ph else "HtmlUtils.escape"
        o[i] = _var_re(V).sub(lambda x: e + "(" + x.group(0) + ")", o[i].replace(".innerHTML", ".textContent"), count=1)
        ex = 'User text is encoded before it is shown, so "<" and ">" display as text instead of running as script.'
    elif k == "bof":
        s = re.sub(r"strcpy\(\s*(\w+)\s*,\s*", r"strncpy(\1, ", o[i])
        s = re.sub(r"strcat\(\s*(\w+)\s*,\s*", r"strncat(\1, ", s)
        s = re.sub(r"(strn(?:cpy|cat)\(\w+, .*?)\)", lambda m: m.group(1) + ", sizeof(" + re.search(r"\((\w+)", m.group(1)).group(1) + ") - 1)", s, count=1)
        s = re.sub(r"gets\(\s*(\w+)\s*\)", r"fgets(\1, sizeof(\1), stdin)", s)
        s = re.sub(r"sprintf\(\s*(\w+)\s*,\s*", r"snprintf(\1, sizeof(\1), ", s)
        o[i] = s
        ex = "A size limit is added so the copy can never run past the end of the buffer. (sizeof works for arrays, not pointers.)"
    else:
        s = o[i].replace("pickle.loads", "json.loads").replace("pickle.load", "json.load").replace("yaml.load(", "yaml.safe_load(")
        s = re.sub(r"unserialize\((.*)\)", r"json_decode(\1, true)", s).replace("eval(", "JSON.parse(")
        o[i] = s
        ex = "A data-only parser replaces the one that can build objects or run code."
    if g:
        o.insert(i, ind + g)
    return dict(id=uid(), vulnerability_type=f["type"], original_code="\n".join(L), patched_code="\n".join(o),
                diff=diff(L, o), explanation=ex, status="Generated", verification=None)


def diff(a: List[str], b: List[str]) -> List[List[str]]:
    n, m = len(a), len(b)
    t = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(n - 1, -1, -1):
        for j in range(m - 1, -1, -1):
            t[i][j] = t[i + 1][j + 1] + 1 if a[i] == b[j] else max(t[i + 1][j], t[i][j + 1])
    i = j = 0
    r: List[List[str]] = []
    while i < n and j < m:
        if a[i] == b[j]:
            r.append([" ", a[i]]); i += 1; j += 1
        elif t[i + 1][j] >= t[i][j + 1]:
            r.append(["-", a[i]]); i += 1
        else:
            r.append(["+", b[j]]); j += 1
    while i < n:
        r.append(["-", a[i]]); i += 1
    while j < m:
        r.append(["+", b[j]]); j += 1
    return r


def diff_text(patch: dict, fname: str) -> str:
    return "--- a/%s\n+++ b/%s\n" % (fname, fname) + "\n".join(d[0] + d[1] for d in patch["diff"])


def merge_patches(code: str, findings: List[dict]):
    """Best-effort merge of every finding's diff onto the original source.

    Each patch was synthesized against the same original file, so edits are mapped back to
    original line indexes and applied bottom-up. Overlapping edits are skipped (reported).
    Returns (merged_code, applied_count, skipped_count).
    """
    edits = []  # (start_orig_index, delete_count, new_lines)
    for f in findings:
        d = (f.get("patch") or {}).get("diff") or []
        oi = 0
        i = 0
        while i < len(d):
            tag = d[i][0]
            if tag == " ":
                oi += 1
                i += 1
            elif tag == "-":
                start = oi
                dels = 0
                while i < len(d) and d[i][0] == "-":
                    dels += 1
                    oi += 1
                    i += 1
                adds = []
                while i < len(d) and d[i][0] == "+":
                    adds.append(d[i][1])
                    i += 1
                edits.append((start, dels, adds))
            else:  # "+" insertion anchored before original line oi
                adds = []
                while i < len(d) and d[i][0] == "+":
                    adds.append(d[i][1])
                    i += 1
                edits.append((oi, 0, adds))
    edits.sort(key=lambda e: (e[0], e[1]), reverse=True)
    lines = code.split("\n")
    applied = skipped = 0
    last_start = len(lines) + 1
    for start, dels, adds in edits:
        if start + dels > last_start:
            skipped += 1
            continue
        lines[start:start + dels] = adds
        applied += 1
        last_start = start
    return "\n".join(lines), applied, skipped


def verify_patch(f: dict, lang: str) -> dict:
    """Re-run the rule engine on the patched code. Honest about limits: pattern+taint only."""
    results = scan(f["patch"]["patched_code"], lang)
    same = [x for x in results if x["k"] == f["k"] and x["cl"] == f["cl"] and x["V"] == f["V"]]
    other = [x for x in results if x not in same]
    return dict(
        passed=not same,
        method="Re-analysis of the patched code with the same taint-tracking rule engine.",
        checks=[
            dict(name="Original source→sink path removed", passed=not same),
            dict(name="Patched line still parses as a sink call", passed=bool(f["patch"]["patched_code"].strip())),
            dict(name="No new findings of the same class introduced", passed=not any(x["k"] == f["k"] for x in other)),
        ],
        remaining_findings=len(results),
        limitations="Pattern-based verification cannot prove exploitability or safety; it confirms the detected data-flow path no longer matches. Review the patch and run your test-suite before merging.",
    )
