"""End-to-end backend API tests for SentinelGraph."""
import os
import time
import uuid
import subprocess
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "https://sentinel-graph.preview.emergentagent.com").rstrip("/")
API = BASE_URL + "/api"
ADMIN_EMAIL = "admin@sentinelgraph.dev"
ADMIN_PASS = "Sentinel!2026"


# --- Fixtures ---
@pytest.fixture(scope="session")
def admin_session():
    s = requests.Session()
    r = s.post(f"{API}/auth/login", json={"email": ADMIN_EMAIL, "password": ADMIN_PASS})
    assert r.status_code == 200, f"admin login failed: {r.status_code} {r.text}"
    return s


@pytest.fixture(scope="session")
def new_user_session():
    s = requests.Session()
    email = f"test_{uuid.uuid4().hex[:8]}@example.com"
    r = s.post(f"{API}/auth/register", json={"name": "Test", "email": email, "password": "Pass12345"})
    assert r.status_code == 200
    return s, email


# --- Health ---
def test_health():
    r = requests.get(f"{API}/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


# --- Auth: register ---
def test_register_duplicate_email(new_user_session):
    _, email = new_user_session
    r = requests.post(f"{API}/auth/register", json={"name": "X", "email": email, "password": "Pass12345"})
    assert r.status_code == 409


def test_register_short_password():
    r = requests.post(f"{API}/auth/register", json={"name": "X", "email": f"x_{uuid.uuid4().hex[:6]}@e.com", "password": "short"})
    assert r.status_code == 422


# --- Auth: login ---
def test_login_sets_cookies(admin_session):
    cookies = admin_session.cookies.get_dict()
    assert "access_token" in cookies
    assert "refresh_token" in cookies


def test_login_wrong_password():
    r = requests.post(f"{API}/auth/login", json={"email": ADMIN_EMAIL, "password": "wrong_password_xx"})
    assert r.status_code == 401


def test_login_bruteforce_lockout():
    s = requests.Session()
    bogus = f"brute_{uuid.uuid4().hex[:8]}@example.com"
    # First register so lockout key stays per-ip:email - but we use bogus to avoid locking admin.
    codes = []
    for _ in range(6):
        r = s.post(f"{API}/auth/login", json={"email": bogus, "password": "wrongpass1"})
        codes.append(r.status_code)
    assert 429 in codes, f"expected 429 after 5 failures, got {codes}"


# --- Auth: me / logout ---
def test_me_requires_auth():
    r = requests.get(f"{API}/auth/me")
    assert r.status_code == 401


def test_me_with_cookies(admin_session):
    r = admin_session.get(f"{API}/auth/me")
    assert r.status_code == 200
    assert r.json()["email"] == ADMIN_EMAIL


def test_logout_clears_cookies():
    s = requests.Session()
    s.post(f"{API}/auth/login", json={"email": ADMIN_EMAIL, "password": ADMIN_PASS})
    r = s.post(f"{API}/auth/logout", headers={"Origin": BASE_URL})
    assert r.status_code == 200
    # After logout, cookies should be cleared
    r2 = s.get(f"{API}/auth/me")
    assert r2.status_code == 401


# --- Google-style session via mongosh ---
def test_bearer_session_token():
    tok = f"test_session_{uuid.uuid4().hex}"
    uid = f"user_test{uuid.uuid4().hex[:8]}"
    email = f"gauth_{uuid.uuid4().hex[:6]}@example.com"
    script = f"""
    var now = new Date();
    var exp = new Date(now.getTime()+7*24*3600*1000);
    db.users.insertOne({{user_id:'{uid}',email:'{email}',name:'G',picture:'',provider:'google',role:'analyst',created_at:now.toISOString()}});
    db.user_sessions.insertOne({{user_id:'{uid}',session_token:'{tok}',expires_at:exp,created_at:now}});
    """
    res = subprocess.run(["mongosh", "mongodb://localhost:27017/test_database", "--quiet", "--eval", script], capture_output=True, text=True)
    assert "insertedId" in res.stdout or res.returncode == 0, res.stderr
    r = requests.get(f"{API}/auth/me", headers={"Authorization": f"Bearer {tok}"})
    assert r.status_code == 200
    assert r.json()["email"] == email


# --- Projects ---
def test_demo_project_auto_created(admin_session):
    r = admin_session.get(f"{API}/projects")
    assert r.status_code == 200
    projects = r.json()
    assert len(projects) >= 1


def test_create_project_validation(admin_session):
    # Unsupported language
    r = admin_session.post(f"{API}/projects", json={"name": "X", "language": "Rust", "code": "print(1)"}, headers={"Origin": BASE_URL})
    assert r.status_code == 400
    # Empty code (whitespace)
    r2 = admin_session.post(f"{API}/projects", json={"name": "X", "language": "Python", "code": "   "}, headers={"Origin": BASE_URL})
    assert r2.status_code == 400


def test_project_isolation_between_users(admin_session, new_user_session):
    other_sess, _ = new_user_session
    r = admin_session.get(f"{API}/projects")
    admin_pid = r.json()[0]["project_id"]
    r2 = other_sess.get(f"{API}/projects/{admin_pid}")
    assert r2.status_code == 404


# --- Scans ---
@pytest.fixture(scope="session")
def demo_scan(admin_session):
    r = admin_session.get(f"{API}/projects")
    pid = r.json()[0]["project_id"]
    r2 = admin_session.post(f"{API}/projects/{pid}/scan", headers={"Origin": BASE_URL})
    assert r2.status_code == 201
    sid = r2.json()["scan_id"]
    assert r2.json()["status"] == "running"
    # Poll
    for _ in range(30):
        time.sleep(0.5)
        rp = admin_session.get(f"{API}/scans/{sid}").json()
        if rp["status"] in ("done", "failed"):
            break
    assert rp["status"] == "done"
    assert rp["progress"] == 100
    return sid, pid, rp


def test_scan_findings_structure(demo_scan):
    sid, _, scan = demo_scan
    assert len(scan["findings"]) == 1
    f = scan["findings"][0]
    assert f["severity"] == "Critical"
    assert f["cwe"] == "CWE-89"
    assert f["confidence"] == "High"
    node_types = [n["node_type"] for n in f["graph"]["nodes"]]
    assert node_types == ["ENTRY_POINT", "SOURCE", "VARIABLE", "VARIABLE", "SINK", "IMPACT", "MISSING_GUARD", "PATCH"]
    assert "diff" in f["patch"]


def test_apply_and_verify_finding(admin_session, demo_scan):
    sid, _, scan = demo_scan
    fid = scan["findings"][0]["id"]
    r = admin_session.post(f"{API}/scans/{sid}/findings/{fid}/apply", headers={"Origin": BASE_URL})
    assert r.status_code == 200
    assert r.json()["patch"]["status"] == "Applied"
    assert r.json()["status"] == "Patched"
    r2 = admin_session.post(f"{API}/scans/{sid}/findings/{fid}/verify", headers={"Origin": BASE_URL})
    assert r2.status_code == 200
    body = r2.json()
    assert body["patch"]["verification"]["passed"] is True
    assert body["patch"]["status"] == "Verified"
    assert body["status"] == "Fixed"


def test_verify_all(admin_session, demo_scan):
    sid, _, _ = demo_scan
    r = admin_session.post(f"{API}/scans/{sid}/verify-all", headers={"Origin": BASE_URL})
    assert r.status_code == 200
    assert r.json()["verified"] >= 1


def test_report_endpoint(admin_session, demo_scan):
    sid, _, _ = demo_scan
    r = admin_session.get(f"{API}/scans/{sid}/report")
    assert r.status_code == 200
    assert "SentinelGraph report" in r.text


def test_scan_list(admin_session):
    r = admin_session.get(f"{API}/scans")
    assert r.status_code == 200
    assert isinstance(r.json(), list)


def test_cancel_running_scan(admin_session):
    r = admin_session.get(f"{API}/projects")
    pid = r.json()[0]["project_id"]
    rs = admin_session.post(f"{API}/projects/{pid}/scan", headers={"Origin": BASE_URL})
    sid = rs.json()["scan_id"]
    rc = admin_session.post(f"{API}/scans/{sid}/cancel", headers={"Origin": BASE_URL})
    assert rc.status_code == 200


def test_dashboard_stats(admin_session):
    r = admin_session.get(f"{API}/dashboard/stats")
    assert r.status_code == 200
    d = r.json()
    for k in ("projects", "scans", "findings", "verified", "severity", "trend", "activity"):
        assert k in d


def test_delete_project(admin_session):
    # Create then delete
    r = admin_session.post(f"{API}/projects", json={"name": "ToDelete", "language": "Python", "code": "x=1"}, headers={"Origin": BASE_URL})
    assert r.status_code == 201
    pid = r.json()["project_id"]
    rd = admin_session.delete(f"{API}/projects/{pid}", headers={"Origin": BASE_URL})
    assert rd.status_code == 200
    rg = admin_session.get(f"{API}/projects/{pid}")
    assert rg.status_code == 404


# --- New download endpoints (sunset redesign) ---
def test_download_code(admin_session, demo_scan):
    sid, _, _ = demo_scan
    r = admin_session.get(f"{API}/scans/{sid}/download/code")
    assert r.status_code == 200
    assert "attachment" in r.headers.get("content-disposition", "")
    assert "main." in r.headers.get("content-disposition", "")
    assert len(r.text) > 0


def test_download_corrected(admin_session, demo_scan):
    sid, _, _ = demo_scan
    r = admin_session.get(f"{API}/scans/{sid}/download/corrected")
    assert r.status_code == 200
    cd = r.headers.get("content-disposition", "")
    assert "main.fixed." in cd
    applied = int(r.headers.get("X-Patches-Applied", "0"))
    assert applied >= 1
    # Verify SQL injection fix is in the merged code (parameterized)
    assert "?" in r.text or "%s" in r.text or "execute(" in r.text


def test_download_requires_auth(demo_scan):
    sid, _, _ = demo_scan
    r = requests.get(f"{API}/scans/{sid}/download/code")
    assert r.status_code == 401

