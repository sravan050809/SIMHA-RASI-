"""Security validation test suite for hardened SentinelGraph backend."""
import uuid
import requests
import pytest

BASE_URL = "http://127.0.0.1:8765/api"


class TestSecurityHeaders:
    def test_health_has_security_headers(self):
        r = requests.get(f"{BASE_URL}/health")
        assert r.status_code == 200
        assert r.headers.get("X-Content-Type-Options") == "nosniff"
        assert r.headers.get("X-Frame-Options") == "DENY"
        assert r.headers.get("Referrer-Policy") == "strict-origin-when-cross-origin"
        assert "camera" in r.headers.get("Permissions-Policy", "")


class TestPasswordComplexity:
    def test_short_password_rejected(self):
        r = requests.post(f"{BASE_URL}/auth/register",
                          json={"name": "T", "email": f"t_{uuid.uuid4().hex[:6]}@e.com", "password": "short"})
        assert r.status_code in (400, 422)

    def test_no_digit_password_rejected(self):
        r = requests.post(f"{BASE_URL}/auth/register",
                          json={"name": "T", "email": f"t_{uuid.uuid4().hex[:6]}@e.com", "password": "alllettersonly"})
        assert r.status_code in (400, 422)

    def test_no_letter_password_rejected(self):
        r = requests.post(f"{BASE_URL}/auth/register",
                          json={"name": "T", "email": f"t_{uuid.uuid4().hex[:6]}@e.com", "password": "12345678"})
        assert r.status_code in (400, 422)

    def test_valid_password_accepted(self):
        email = f"test_{uuid.uuid4().hex[:8]}@example.com"
        r = requests.post(f"{BASE_URL}/auth/register",
                          json={"name": "Test", "email": email, "password": "Valid123"})
        assert r.status_code == 200


class TestAuthEnforcement:
    def test_projects_requires_auth(self):
        assert requests.get(f"{BASE_URL}/projects").status_code == 401

    def test_scans_requires_auth(self):
        assert requests.get(f"{BASE_URL}/scans").status_code == 401

    def test_dashboard_requires_auth(self):
        assert requests.get(f"{BASE_URL}/dashboard/stats").status_code == 401

    def test_export_requires_auth(self):
        assert requests.get(f"{BASE_URL}/export/source").status_code == 401

    def test_me_requires_auth(self):
        assert requests.get(f"{BASE_URL}/auth/me").status_code == 401


class TestInputSanitization:
    @pytest.fixture()
    def session(self):
        s = requests.Session()
        email = f"sec_{uuid.uuid4().hex[:8]}@example.com"
        r = s.post(f"{BASE_URL}/auth/register", json={"name": "Sec", "email": email, "password": "Valid123"})
        assert r.status_code == 200
        return s

    def test_xss_in_project_name_sanitized(self, session):
        r = session.post(f"{BASE_URL}/projects",
                         json={"name": "<script>alert(1)</script>Test", "language": "Python", "code": "x=1"},
                         headers={"Origin": "http://127.0.0.1:8765"})
        assert r.status_code == 201
        name = r.json()["name"]
        assert "<script>" not in name
        assert "</script>" not in name

    def test_control_chars_stripped(self, session):
        r = session.post(f"{BASE_URL}/projects",
                         json={"name": "hello\x00\x07world", "language": "Python", "code": "x=1"},
                         headers={"Origin": "http://127.0.0.1:8765"})
        assert r.status_code == 201
        assert "\x00" not in r.json()["name"]

    def test_invalid_source_type_rejected(self, session):
        r = session.post(f"{BASE_URL}/projects",
                         json={"name": "T", "language": "Python", "code": "x=1", "source_type": "malicious"},
                         headers={"Origin": "http://127.0.0.1:8765"})
        assert r.status_code == 422

    def test_oversized_code_rejected(self, session):
        r = session.post(f"{BASE_URL}/projects",
                         json={"name": "T", "language": "Python", "code": "x" * 500_000},
                         headers={"Origin": "http://127.0.0.1:8765"})
        assert r.status_code in (400, 413, 422)


class TestCSRF:
    def test_mutation_without_origin_allowed_for_non_browser(self):
        r = requests.post(f"{BASE_URL}/auth/login",
                          json={"email": "nonexistent@test.com", "password": "WrongPass1"})
        assert r.status_code in (401, 429)


class TestLoginLockout:
    def test_burst_lockout(self):
        s = requests.Session()
        bogus = f"brute_{uuid.uuid4().hex[:8]}@example.com"
        codes = []
        for _ in range(6):
            r = s.post(f"{BASE_URL}/auth/login", json={"email": bogus, "password": "wrongpass1"})
            codes.append(r.status_code)
        assert 429 in codes


class TestAuthenticatedFlow:
    @pytest.fixture()
    def session(self):
        s = requests.Session()
        email = f"flow_{uuid.uuid4().hex[:8]}@example.com"
        r = s.post(f"{BASE_URL}/auth/register", json={"name": "Flow", "email": email, "password": "Valid123"})
        assert r.status_code == 200
        return s

    def test_full_crud_flow(self, session):
        r = session.get(f"{BASE_URL}/auth/me")
        assert r.status_code == 200

        r = session.post(f"{BASE_URL}/projects",
                         json={"name": "SecTest", "language": "Python", "code": "x=1"},
                         headers={"Origin": "http://127.0.0.1:8765"})
        assert r.status_code == 201
        pid = r.json()["project_id"]

        r = session.post(f"{BASE_URL}/projects/{pid}/scan", headers={"Origin": "http://127.0.0.1:8765"})
        assert r.status_code == 201

        r = session.get(f"{BASE_URL}/projects")
        assert r.status_code == 200

        r = session.get(f"{BASE_URL}/dashboard/stats")
        assert r.status_code == 200

        r = session.delete(f"{BASE_URL}/projects/{pid}", headers={"Origin": "http://127.0.0.1:8765"})
        assert r.status_code == 200

    def test_logout_clears_session(self, session):
        r = session.post(f"{BASE_URL}/auth/logout", headers={"Origin": "http://127.0.0.1:8765"})
        assert r.status_code == 200
        r = session.get(f"{BASE_URL}/auth/me")
        assert r.status_code == 401


class TestRateLimiting:
    def test_rate_limit_returns_429_after_burst(self):
        import os
        limit = int(os.environ.get("RATE_LIMIT", "120"))
        codes = []
        for _ in range(limit + 20):
            r = requests.get(f"{BASE_URL}/health")
            codes.append(r.status_code)
            if r.status_code == 429:
                break
        assert 429 in codes, f"Expected at least one 429 in burst of {limit + 20}, got: {set(codes)}"
