"""Detection / patch / verification regression tests for the rule engine."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import scanner  # noqa: E402

DEMO = scanner.DEMO_CODE


def test_demo_sql_injection_detected_with_high_confidence():
    fs = scanner.scan(DEMO, "Python")
    assert len(fs) == 1
    f = fs[0]
    assert f["k"] == "sql" and f["severity"] == "Critical" and f["confidence"] == "High"
    assert f["cl"] == [4, 5] and f["V"] == "username"
    assert [n["node_type"] for n in f["graph"]["nodes"]] == ["ENTRY_POINT", "SOURCE", "VARIABLE", "VARIABLE", "SINK", "IMPACT", "MISSING_GUARD", "PATCH"]


def test_demo_patch_is_parameterized_and_verifies():
    f = scanner.scan(DEMO, "Python")[0]
    assert 'WHERE name = ?' in f["patch"]["patched_code"]
    assert "cursor.execute(query, (username,))" in f["patch"]["patched_code"]
    v = scanner.verify_patch(f, "Python")
    assert v["passed"] is True


def test_parameterized_query_is_not_flagged():
    code = 'name = request.args.get("n")\ncursor.execute("SELECT * FROM u WHERE n = ?", (name,))'
    assert scanner.scan(code, "Python") == []


def test_sanitizer_clears_taint():
    code = 'p = request.args.get("f")\np = os.path.basename(p)\nopen(p)'
    assert scanner.scan(code, "Python") == []


def test_comment_lines_ignored():
    code = '# user = request.args.get("x")\n# os.system(user)'
    assert scanner.scan(code, "Python") == []


def test_command_injection_js_chain():
    code = 'const q = req.query.cmd;\nconst c = q;\nexecSync(c);'
    fs = scanner.scan(code, "JavaScript")
    assert len(fs) == 1 and fs[0]["k"] == "cmd" and fs[0]["cl"] == [1, 2]
    assert "throw new Error" in fs[0]["patch"]["patched_code"]
    assert scanner.verify_patch(fs[0], "JavaScript")["passed"]


def test_buffer_overflow_only_in_c_and_low_confidence():
    code = 'char buf[8];\nstrcpy(buf, argv[1]);'
    assert scanner.scan(code, "Python") == []
    fs = scanner.scan(code, "C")
    assert fs and fs[0]["k"] == "bof"
    assert "strncpy(buf, argv[1], sizeof(buf) - 1)" in fs[0]["patch"]["patched_code"]


def test_unsupported_sink_without_input_is_not_flagged():
    assert scanner.scan('cursor.execute("SELECT 1")', "Python") == []


def test_xss_inline_medium_confidence():
    fs = scanner.scan('el.innerHTML = location.search', "JavaScript")
    assert fs and fs[0]["confidence"] == "Medium"
    assert ".textContent" in fs[0]["patch"]["patched_code"]


def test_diff_roundtrip():
    d = scanner.diff(["a", "b", "c"], ["a", "x", "c"])
    assert d == [[" ", "a"], ["-", "b"], ["+", "x"], [" ", "c"]]
