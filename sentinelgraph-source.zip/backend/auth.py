import os
import re
import uuid
import secrets
import logging
from datetime import datetime, timedelta, timezone

import httpx
import jwt
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, VerificationError, InvalidHashError
from fastapi import APIRouter, HTTPException, Request, Response, Depends
from pydantic import BaseModel, EmailStr, Field

router = APIRouter(prefix="/auth")
ph = PasswordHasher()  # Argon2id defaults
JWT_ALG = "HS256"
SESSION_DATA_URL = "https://demobackend.emergentagent.com/auth/v1/env/oauth/session-data"
db = None  # injected by server.py
audit_log = logging.getLogger("sentinelgraph.audit")


def _audit(event: str, detail: str = "", **extra):
    """Structured audit log for security-relevant events."""
    audit_log.info("AUDIT %s %s %s", event, detail, extra if extra else "")


def hash_password(p: str) -> str:
    return ph.hash(p)


def verify_password(p: str, h: str) -> bool:
    try:
        return ph.verify(h, p)
    except (VerifyMismatchError, VerificationError, InvalidHashError):
        return False


def _secret() -> str:
    return os.environ["JWT_SECRET"]


def make_token(user_id: str, kind: str, minutes: int) -> str:
    return jwt.encode({"sub": user_id, "type": kind, "exp": datetime.now(timezone.utc) + timedelta(minutes=minutes)}, _secret(), algorithm=JWT_ALG)


def set_jwt_cookies(resp: Response, user_id: str):
    secure = os.environ.get("COOKIE_SECURE", "1") == "1"
    resp.set_cookie("access_token", make_token(user_id, "access", 15), httponly=True, secure=secure, samesite="none" if secure else "lax", max_age=900, path="/")
    resp.set_cookie("refresh_token", make_token(user_id, "refresh", 7 * 24 * 60), httponly=True, secure=secure, samesite="none" if secure else "lax", max_age=604800, path="/")


def public_user(u: dict) -> dict:
    return {k: u.get(k) for k in ("user_id", "email", "name", "picture", "role", "provider", "created_at")}


def _aware(dt):
    if isinstance(dt, str):
        dt = datetime.fromisoformat(dt)
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt


async def _user_from_session(token: str):
    s = await db.user_sessions.find_one({"session_token": token}, {"_id": 0})
    if not s or _aware(s["expires_at"]) < datetime.now(timezone.utc):
        return None
    return await db.users.find_one({"user_id": s["user_id"]}, {"_id": 0})


async def _user_from_jwt(token: str):
    try:
        payload = jwt.decode(token, _secret(), algorithms=[JWT_ALG])
    except jwt.PyJWTError:
        return None
    if payload.get("type") != "access":
        return None
    return await db.users.find_one({"user_id": payload["sub"]}, {"_id": 0})


async def get_current_user(request: Request) -> dict:
    user = None
    if request.cookies.get("session_token"):
        user = await _user_from_session(request.cookies["session_token"])
    if not user and request.cookies.get("access_token"):
        user = await _user_from_jwt(request.cookies["access_token"])
    if not user:
        auth = request.headers.get("Authorization", "")
        if auth.startswith("Bearer "):
            tok = auth[7:]
            user = await _user_from_session(tok) or await _user_from_jwt(tok)
    if not user:
        raise HTTPException(401, "Not authenticated")
    user.pop("password_hash", None)
    return user


def require_same_origin(request: Request):
    """CSRF guard for cookie auth: mutating requests must come from an allowed origin."""
    if request.method in ("GET", "HEAD", "OPTIONS"):
        return
    origin = request.headers.get("origin") or request.headers.get("referer")
    if not origin:
        return  # non-browser clients (curl / tests) carry no cookies implicitly
    allowed = [o.strip() for o in os.environ.get("CORS_ORIGINS", "*").split(",")]
    if "*" in allowed:
        return
    if not any(origin.startswith(a) for a in allowed):
        raise HTTPException(403, "Cross-origin request blocked")


def _validate_password_strength(password: str) -> None:
    """Enforce minimum password complexity."""
    errors = []
    if len(password) < 8:
        errors.append("at least 8 characters")
    if not re.search(r"[A-Za-z]", password):
        errors.append("a letter")
    if not re.search(r"\d", password):
        errors.append("a digit")
    if errors:
        raise HTTPException(400, "Password must contain " + " and ".join(errors) + ".")


class RegisterIn(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)


class LoginIn(BaseModel):
    email: EmailStr
    password: str


class SessionIn(BaseModel):
    session_id: str


class ForgotIn(BaseModel):
    email: EmailStr


class ResetIn(BaseModel):
    token: str
    password: str = Field(min_length=8, max_length=128)


async def ensure_demo_project(user_id: str):
    from scanner import DEMO_CODE
    if await db.projects.count_documents({"user_id": user_id}) == 0:
        await db.projects.insert_one(dict(project_id="proj_" + uuid.uuid4().hex[:12], user_id=user_id, name="Demo: Flask login lookup",
                                          description="Built-in vulnerable demo (labelled demo data)", language="Python", source_type="demo",
                                          code=DEMO_CODE, status="Ready", created_at=datetime.now(timezone.utc).isoformat()))


async def _check_lockout(identifier: str):
    doc = await db.login_attempts.find_one({"identifier": identifier}, {"_id": 0})
    if doc and doc.get("count", 0) >= 5 and _aware(doc["last"]) + timedelta(minutes=15) > datetime.now(timezone.utc):
        raise HTTPException(429, "Too many failed attempts. Try again in 15 minutes.")


async def _record_failure(identifier: str):
    await db.login_attempts.update_one({"identifier": identifier}, {"$inc": {"count": 1}, "$set": {"last": datetime.now(timezone.utc)}}, upsert=True)


@router.post("/register")
async def register(data: RegisterIn, response: Response):
    _validate_password_strength(data.password)
    email = data.email.lower()
    if await db.users.find_one({"email": email}):
        raise HTTPException(409, "This email is already registered.")
    user = dict(user_id="user_" + uuid.uuid4().hex[:12], email=email, name=data.name.strip(), picture="", role="analyst",
                provider="password", password_hash=hash_password(data.password), created_at=datetime.now(timezone.utc).isoformat())
    await db.users.insert_one(user)
    await ensure_demo_project(user["user_id"])
    set_jwt_cookies(response, user["user_id"])
    _audit("REGISTER", email=email, user_id=user["user_id"])
    return public_user(user)


@router.post("/login")
async def login(data: LoginIn, request: Request, response: Response):
    email = data.email.lower()
    # Behind the ingress client.host rotates per request, so the throttle key is the account itself.
    ident = f"login:{email}"
    await _check_lockout(ident)
    user = await db.users.find_one({"email": email}, {"_id": 0})
    if not user or not user.get("password_hash") or not verify_password(data.password, user["password_hash"]):
        await _record_failure(ident)
        _audit("LOGIN_FAILED", email=email)
        raise HTTPException(401, "Wrong email or password.")
    await db.login_attempts.delete_one({"identifier": ident})
    await ensure_demo_project(user["user_id"])
    set_jwt_cookies(response, user["user_id"])
    _audit("LOGIN_OK", email=email, user_id=user["user_id"])
    return public_user(user)


@router.post("/session")
async def exchange_session(data: SessionIn, response: Response):
    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.get(SESSION_DATA_URL, headers={"X-Session-ID": data.session_id})
    if r.status_code != 200:
        raise HTTPException(401, "Invalid or expired Google session.")
    info = r.json()
    email = info["email"].lower()
    user = await db.users.find_one({"email": email}, {"_id": 0})
    if user:
        await db.users.update_one({"email": email}, {"$set": {"name": info.get("name") or user["name"], "picture": info.get("picture", "")}})
        user.update(name=info.get("name") or user["name"], picture=info.get("picture", ""))
    else:
        user = dict(user_id="user_" + uuid.uuid4().hex[:12], email=email, name=info.get("name") or email, picture=info.get("picture", ""),
                    role="analyst", provider="google", created_at=datetime.now(timezone.utc).isoformat())
        await db.users.insert_one(dict(user))
    await ensure_demo_project(user["user_id"])
    token = info["session_token"]
    await db.user_sessions.insert_one(dict(user_id=user["user_id"], session_token=token, created_at=datetime.now(timezone.utc),
                                           expires_at=datetime.now(timezone.utc) + timedelta(days=7)))
    secure = os.environ.get("COOKIE_SECURE", "1") == "1"
    response.set_cookie("session_token", token, httponly=True, secure=secure, samesite="none" if secure else "lax", max_age=7 * 24 * 3600, path="/")
    return public_user(user)


@router.get("/me")
async def me(user=Depends(get_current_user)):
    return public_user(user)


@router.post("/refresh")
async def refresh(request: Request, response: Response):
    tok = request.cookies.get("refresh_token")
    if not tok:
        raise HTTPException(401, "No refresh token")
    try:
        payload = jwt.decode(tok, _secret(), algorithms=[JWT_ALG])
    except jwt.PyJWTError:
        raise HTTPException(401, "Invalid refresh token")
    if payload.get("type") != "refresh":
        raise HTTPException(401, "Invalid token type")
    secure = os.environ.get("COOKIE_SECURE", "1") == "1"
    response.set_cookie("access_token", make_token(payload["sub"], "access", 15), httponly=True, secure=secure, samesite="none" if secure else "lax", max_age=900, path="/")
    return {"ok": True}


@router.post("/logout")
async def logout(request: Request, response: Response):
    tok = request.cookies.get("session_token")
    if tok:
        await db.user_sessions.delete_one({"session_token": tok})
        _audit("LOGOUT", method="session")
    secure = os.environ.get("COOKIE_SECURE", "1") == "1"
    for c in ("session_token", "access_token", "refresh_token"):
        response.delete_cookie(c, path="/", secure=secure, samesite="none" if secure else "lax")
    return {"ok": True}


@router.post("/forgot-password")
async def forgot_password(data: ForgotIn):
    user = await db.users.find_one({"email": data.email.lower(), "provider": "password"}, {"_id": 0})
    if user:
        token = secrets.token_urlsafe(32)
        await db.password_reset_tokens.insert_one(dict(token=token, user_id=user["user_id"], used=False,
                                                       expires_at=datetime.now(timezone.utc) + timedelta(hours=1)))
        # No email provider is configured: the reset link is logged server-side only (documented limitation).
        print(f"[password-reset] token for {user['email']}: {token}")
    return {"ok": True, "message": "If that account exists, a reset link has been issued. (Demo: see server log.)"}


@router.post("/reset-password")
async def reset_password(data: ResetIn):
    _validate_password_strength(data.password)
    doc = await db.password_reset_tokens.find_one({"token": data.token, "used": False}, {"_id": 0})
    if not doc or _aware(doc["expires_at"]) < datetime.now(timezone.utc):
        raise HTTPException(400, "Reset link is invalid or expired.")
    await db.users.update_one({"user_id": doc["user_id"]}, {"$set": {"password_hash": hash_password(data.password)}})
    await db.password_reset_tokens.update_one({"token": data.token}, {"$set": {"used": True}})
    return {"ok": True}


async def seed_admin():
    email = os.environ.get("ADMIN_EMAIL")
    pw = os.environ.get("ADMIN_PASSWORD")
    if not email or not pw:
        return
    existing = await db.users.find_one({"email": email}, {"_id": 0})
    if not existing:
        await db.users.insert_one(dict(user_id="user_" + uuid.uuid4().hex[:12], email=email, name="Sentinel Admin", picture="", role="admin",
                                       provider="password", password_hash=hash_password(pw), created_at=datetime.now(timezone.utc).isoformat()))
    elif not verify_password(pw, existing.get("password_hash", "")):
        await db.users.update_one({"email": email}, {"$set": {"password_hash": hash_password(pw)}})
