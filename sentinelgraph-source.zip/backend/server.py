from dotenv import load_dotenv
from pathlib import Path

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

import asyncio
import logging
import os
import re
import secrets
import time
import uuid
from collections import defaultdict
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, FastAPI, HTTPException, Request
from fastapi.responses import PlainTextResponse
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, Field, field_validator
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.middleware.cors import CORSMiddleware
from starlette.responses import Response as StarletteResponse

import auth
import scanner
from auth import get_current_user, require_same_origin

client = AsyncIOMotorClient(os.environ["MONGO_URL"])
db = client[os.environ["DB_NAME"]]
auth.db = db

app = FastAPI(title="SentinelGraph API")
api = APIRouter(prefix="/api", dependencies=[Depends(require_same_origin)])
logging.basicConfig(level=logging.INFO)
log = logging.getLogger("sentinelgraph")

STAGES = ["Parsing source code", "Detecting language", "Running static vulnerability rules", "Building data-flow graph",
          "Correlating attacker-controlled paths", "Synthesizing conservative patches", "Saving results"]
RUNNING: dict = {}

# --- Security: rate limiting store ---
_rate_buckets: dict = defaultdict(lambda: {"tokens": 120, "last": time.time()})
RATE_LIMIT = int(os.environ.get("RATE_LIMIT", "120"))  # requests per window
RATE_WINDOW = int(os.environ.get("RATE_WINDOW", "60"))  # seconds

# --- Security: input sanitisation ---
_CONTROL_CHARS = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
_TAG_CHARS = re.compile(r"<[^>]*>")


def _sanitize_text(value: str) -> str:
    """Strip null bytes, control chars and HTML tags from user-facing text fields."""
    value = _CONTROL_CHARS.sub("", value)
    value = _TAG_CHARS.sub("", value)
    return value.strip()


def _validate_password_strength(password: str) -> None:
    """Enforce minimum password complexity: length, mixed classes."""
    errors = []
    if len(password) < 8:
        errors.append("at least 8 characters")
    if not re.search(r"[A-Za-z]", password):
        errors.append("a letter")
    if not re.search(r"\d", password):
        errors.append("a digit")
    if errors:
        raise HTTPException(400, "Password must contain " + " and ".join(errors) + ".")


# --- Security middleware: headers, body limit, rate limit, HTTPS redirect ---
class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """Attach hardening headers to every response."""

    async def dispatch(self, request: Request, call_next):
        response: StarletteResponse = await call_next(request)
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        response.headers.setdefault("X-Permitted-Cross-Domain-Policies", "none")
        if request.url.scheme == "https":
            response.headers.setdefault("Strict-Transport-Security", "max-age=63072000; includeSubDomains")
        return response


class BodySizeLimitMiddleware(BaseHTTPMiddleware):
    """Reject request bodies larger than the allowed maximum."""

    MAX_BODY = 500_000  # 500 KB (code max is 400 KB)

    async def dispatch(self, request: Request, call_next):
        cl = request.headers.get("content-length")
        if cl and cl.isdigit() and int(cl) > self.MAX_BODY:
            return StarletteResponse(
                content='{"detail":"Request body too large."}',
                status_code=413,
                media_type="application/json",
            )
        return await call_next(request)


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Sliding-window rate limiter per client IP for API endpoints."""

    async def dispatch(self, request: Request, call_next):
        if not request.url.path.startswith("/api/"):
            return await call_next(request)
        client = request.client.host if request.client else "unknown"
        now = time.time()
        bucket = _rate_buckets[client]
        elapsed = now - bucket["last"]
        bucket["tokens"] = min(RATE_LIMIT, bucket["tokens"] + elapsed * (RATE_LIMIT / RATE_WINDOW))
        bucket["last"] = now
        if bucket["tokens"] < 1:
            return StarletteResponse(
                content='{"detail":"Too many requests. Please slow down."}',
                status_code=429,
                media_type="application/json",
                headers={"Retry-After": str(RATE_WINDOW)},
            )
        bucket["tokens"] -= 1
        return await call_next(request)


class HTTPSRedirectMiddleware(BaseHTTPMiddleware):
    """Redirect HTTP to HTTPS when enabled (set FORCE_HTTPS=1 in production)."""

    async def dispatch(self, request: Request, call_next):
        if os.environ.get("FORCE_HTTPS") == "1" and request.url.scheme == "http":
            return StarletteResponse(
                status_code=301,
                headers={"Location": request.url.replace(scheme="https").__str__()},
            )
        return await call_next(request)


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


class ProjectIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    description: str = Field(default="", max_length=500)
    language: str
    source_type: str = "paste"
    code: str = Field(min_length=1, max_length=400_000)

    @field_validator("name", "description")
    @classmethod
    def _sanitize(cls, v: str) -> str:
        return _sanitize_text(v)

    @field_validator("source_type")
    @classmethod
    def _valid_source(cls, v: str) -> str:
        if v not in ("paste", "upload", "demo"):
            raise ValueError("source_type must be paste, upload or demo")
        return v


def project_out(p: dict, last: Optional[dict]) -> dict:
    return dict(project_id=p["project_id"], name=p["name"], description=p.get("description", ""), language=p["language"],
                source_type=p["source_type"], status=p["status"], created_at=p["created_at"],
                last_scan=None if not last else dict(scan_id=last["scan_id"], status=last["status"], summary=last.get("summary"), started_at=last["started_at"]))


async def owned_project(pid: str, user: dict) -> dict:
    p = await db.projects.find_one({"project_id": pid, "user_id": user["user_id"]}, {"_id": 0})
    if not p:
        raise HTTPException(404, "Project not found")
    return p


async def owned_scan(sid: str, user: dict) -> dict:
    s = await db.scans.find_one({"scan_id": sid, "user_id": user["user_id"]}, {"_id": 0})
    if not s:
        raise HTTPException(404, "Scan not found")
    return s


@api.get("/health")
async def health():
    return {"status": "ok", "engine": "rules+taint", "languages": scanner.LANGS}


@api.get("/projects")
async def list_projects(user=Depends(get_current_user)):
    ps = await db.projects.find({"user_id": user["user_id"]}, {"_id": 0}).sort("created_at", -1).to_list(500)
    out = []
    for p in ps:
        last = await db.scans.find_one({"project_id": p["project_id"], "status": "done"}, {"_id": 0, "findings": 0, "logs": 0}, sort=[("started_at", -1)])
        out.append(project_out(p, last))
    return out


@api.post("/projects", status_code=201)
async def create_project(data: ProjectIn, user=Depends(get_current_user)):
    if data.language not in scanner.LANGS:
        raise HTTPException(400, "This language is not supported in the current version.")
    if not data.code.strip():
        raise HTTPException(400, "The code is empty. Paste code or upload a file first.")
    p = dict(project_id="proj_" + uuid.uuid4().hex[:12], user_id=user["user_id"], name=data.name.strip(), description=data.description.strip(),
             language=data.language, source_type=data.source_type, code=data.code, status="Ready", created_at=now())
    await db.projects.insert_one(dict(p))
    return project_out(p, None)


@api.get("/projects/{pid}")
async def get_project(pid: str, user=Depends(get_current_user)):
    p = await owned_project(pid, user)
    last = await db.scans.find_one({"project_id": pid, "status": "done"}, {"_id": 0, "findings": 0, "logs": 0}, sort=[("started_at", -1)])
    return {**project_out(p, last), "code": p["code"]}


@api.delete("/projects/{pid}")
async def delete_project(pid: str, user=Depends(get_current_user)):
    await owned_project(pid, user)
    await db.projects.delete_one({"project_id": pid})
    await db.scans.delete_many({"project_id": pid})
    return {"ok": True}


async def run_scan(scan_id: str, project: dict):
    async def update(**fields):
        await db.scans.update_one({"scan_id": scan_id}, {"$set": fields})

    async def log_line(msg: str, level: str = "INFO"):
        await db.scans.update_one({"scan_id": scan_id}, {"$push": {"logs": dict(message=msg, log_level=level, created_at=now())}})

    findings = []
    try:
        for idx, stage in enumerate(STAGES):
            if scan_id not in RUNNING:
                return
            await update(stage=stage, progress=round(idx / len(STAGES) * 100))
            await log_line(stage + "…")
            if idx == 0:
                lines = project["code"].split("\n")
                await log_line(f"{len(lines)} lines, {len(project['code'])} bytes loaded")
                if not project["code"].strip():
                    raise ValueError("Empty code")
            elif idx == 1:
                if project["language"] not in scanner.LANGS:
                    raise ValueError("This language is not supported in the current version.")
                await log_line(f"Language: {project['language']} · {len(scanner.RULES)} rule families active")
            elif idx == 2:
                findings = await asyncio.to_thread(scanner.scan, project["code"], project["language"])
                await log_line(f"Rules matched: {len(findings)} finding(s)", "WARN" if findings else "INFO")
                for f in findings:
                    await log_line(f"[{f['severity']}] {f['title']} at line {f['line']} · {f['cwe']} · confidence {f['confidence']}",
                                   "WARN" if f["severity"] in ("Critical", "High") else "INFO")
            elif idx == 3:
                await log_line(f"{sum(len(f['graph']['nodes']) for f in findings)} graph nodes built")
            elif idx == 4:
                hi = sum(1 for f in findings if f["confidence"] == "High")
                await log_line(f"{hi} path(s) with confirmed input→sink taint flow")
            elif idx == 5:
                await log_line(f"{len(findings)} patch suggestion(s) generated (not applied)")
            await asyncio.sleep(0.35)
        summary = dict(total=len(findings), critical=sum(f["severity"] == "Critical" for f in findings), high=sum(f["severity"] == "High" for f in findings),
                       medium=sum(f["severity"] == "Medium" for f in findings), low=sum(f["severity"] == "Low" for f in findings))
        await update(status="done", progress=100, stage="Analysis complete", findings=findings, summary=summary, finished_at=now())
        await log_line("Analysis complete.", "OK")
        await db.projects.update_one({"project_id": project["project_id"]}, {"$set": {"status": "Vulnerable" if findings else "Clean"}})
    except Exception as e:  # noqa
        log.exception("scan failed")
        await update(status="failed", stage="Failed: " + str(e), finished_at=now())
        await log_line(str(e), "ERROR")
        await db.projects.update_one({"project_id": project["project_id"]}, {"$set": {"status": "Failed"}})
    finally:
        RUNNING.pop(scan_id, None)


@api.post("/projects/{pid}/scan", status_code=201)
async def start_scan(pid: str, user=Depends(get_current_user)):
    p = await owned_project(pid, user)
    s = dict(scan_id="scan_" + uuid.uuid4().hex[:12], project_id=pid, project_name=p["name"], language=p["language"], user_id=user["user_id"],
             status="running", progress=0, stage=STAGES[0], started_at=now(), finished_at=None, logs=[], findings=[], summary=None)
    await db.scans.insert_one(dict(s))
    await db.projects.update_one({"project_id": pid}, {"$set": {"status": "Scanning"}})
    RUNNING[s["scan_id"]] = True
    asyncio.create_task(run_scan(s["scan_id"], p))
    return s


@api.get("/scans")
async def list_scans(user=Depends(get_current_user)):
    ss = await db.scans.find({"user_id": user["user_id"]}, {"_id": 0, "logs": 0, "findings.graph": 0, "findings.patch": 0}).sort("started_at", -1).to_list(500)
    for s in ss:
        s["findings_count"] = len(s.get("findings", []))
        s["verified_count"] = sum(1 for f in s.get("findings", []) if f.get("status") == "Fixed")
        s["findings"] = [dict(id=f["id"], severity=f["severity"], title=f["title"], status=f["status"]) for f in s.get("findings", [])]
    return ss


@api.get("/scans/{sid}")
async def get_scan(sid: str, user=Depends(get_current_user)):
    return await owned_scan(sid, user)


@api.post("/scans/{sid}/cancel")
async def cancel_scan(sid: str, user=Depends(get_current_user)):
    s = await owned_scan(sid, user)
    if s["status"] == "running":
        RUNNING.pop(sid, None)
        await db.scans.update_one({"scan_id": sid}, {"$set": {"status": "cancelled", "stage": "Cancelled", "finished_at": now()}})
        await db.projects.update_one({"project_id": s["project_id"]}, {"$set": {"status": "Ready"}})
    return {"ok": True}


def _finding(s: dict, fid: str) -> dict:
    for f in s["findings"]:
        if f["id"] == fid:
            return f
    raise HTTPException(404, "Finding not found")


@api.post("/scans/{sid}/findings/{fid}/apply")
async def apply_patch(sid: str, fid: str, user=Depends(get_current_user)):
    s = await owned_scan(sid, user)
    f = _finding(s, fid)
    f["patch"]["status"] = "Applied"
    f["status"] = "Patched"
    await db.scans.update_one({"scan_id": sid}, {"$set": {"findings": s["findings"]}})
    return f


@api.post("/scans/{sid}/findings/{fid}/verify")
async def verify_finding(sid: str, fid: str, user=Depends(get_current_user)):
    s = await owned_scan(sid, user)
    f = _finding(s, fid)
    result = await asyncio.to_thread(scanner.verify_patch, f, s["language"])
    f["patch"]["verification"] = {**result, "verified_at": now()}
    if result["passed"]:
        f["patch"]["status"] = "Verified"
        f["status"] = "Fixed"
    elif f["patch"]["status"] == "Verified":
        f["patch"]["status"], f["status"] = "Applied", "Patched"
    await db.scans.update_one({"scan_id": sid}, {"$set": {"findings": s["findings"]}})
    return f


@api.post("/scans/{sid}/verify-all")
async def verify_all(sid: str, user=Depends(get_current_user)):
    s = await owned_scan(sid, user)
    ok = 0
    for f in s["findings"]:
        result = await asyncio.to_thread(scanner.verify_patch, f, s["language"])
        f["patch"]["verification"] = {**result, "verified_at": now()}
        if result["passed"]:
            f["patch"]["status"], f["status"] = "Verified", "Fixed"
            ok += 1
        else:
            f["patch"]["status"], f["status"] = "Applied", "Patched"
    await db.scans.update_one({"scan_id": sid}, {"$set": {"findings": s["findings"]}})
    return {"verified": ok, "total": len(s["findings"]), "findings": s["findings"]}


@api.get("/scans/{sid}/report", response_class=PlainTextResponse)
async def report(sid: str, user=Depends(get_current_user)):
    s = await owned_scan(sid, user)
    head = f"SentinelGraph report: {s['project_name']} ({s['language']})\nScan {s['scan_id']} · {s['started_at']} · status {s['status']}\n"
    head += "Engine: rule-based detection + intra-file taint tracking (pattern analysis; not a proof of exploitability).\n\n"
    if not s["findings"]:
        return head + "No findings."
    body = "\n".join(f"{i+1}. [{f['severity']}] {f['title']} | {f['cwe']} | {f['file']}:{f['line']} | confidence {f['confidence']} | patch: {f['patch']['status']}"
                     for i, f in enumerate(s["findings"]))
    return head + body


from fastapi.responses import Response


def _scan_file_response(code: str, filename: str, extra: Optional[dict] = None) -> Response:
    headers = {"Content-Disposition": f'attachment; filename="{filename}"'}
    if extra:
        headers.update(extra)
    return Response(content=code, media_type="text/plain; charset=utf-8", headers=headers)


@api.get("/scans/{sid}/download/code")
async def download_source(sid: str, user=Depends(get_current_user)):
    s = await owned_scan(sid, user)
    p = await db.projects.find_one({"project_id": s["project_id"]}, {"_id": 0})
    if not p:
        raise HTTPException(404, "Project not found")
    ext = scanner.XO.get(s["language"], "txt")
    return _scan_file_response(p["code"], f"main.{ext}")


@api.get("/scans/{sid}/download/corrected")
async def download_corrected(sid: str, user=Depends(get_current_user)):
    s = await owned_scan(sid, user)
    if s["status"] != "done":
        raise HTTPException(409, "Scan is not complete yet.")
    p = await db.projects.find_one({"project_id": s["project_id"]}, {"_id": 0})
    if not p:
        raise HTTPException(404, "Project not found")
    merged, applied, skipped = scanner.merge_patches(p["code"], s.get("findings", []))
    if not applied:
        raise HTTPException(400, "No patch suggestions available for this scan.")
    ext = scanner.XO.get(s["language"], "txt")
    return _scan_file_response(merged, f"main.fixed.{ext}", {"X-Patches-Applied": str(applied), "X-Patches-Skipped": str(skipped)})


@api.get("/dashboard/stats")
async def dashboard_stats(user=Depends(get_current_user)):
    scans = await db.scans.find({"user_id": user["user_id"]}, {"_id": 0, "logs": 0, "findings.graph": 0, "findings.patch.original_code": 0,
                                                              "findings.patch.patched_code": 0, "findings.patch.diff": 0}).sort("started_at", -1).to_list(500)
    projects = await db.projects.count_documents({"user_id": user["user_id"]})
    sev = dict(Critical=0, High=0, Medium=0, Low=0)
    verified = total = 0
    trend, activity = [], []
    for s in scans:
        for f in s.get("findings", []):
            sev[f["severity"]] = sev.get(f["severity"], 0) + 1
            total += 1
            verified += f.get("status") == "Fixed"
        if s["status"] == "done":
            sm = s.get("summary") or {}
            risk = min(100, sm.get("critical", 0) * 40 + sm.get("high", 0) * 22 + sm.get("medium", 0) * 10 + sm.get("low", 0) * 4)
            trend.append(dict(scan_id=s["scan_id"], project=s["project_name"], at=s["started_at"], risk=risk, findings=sm.get("total", 0)))
        activity.append(dict(scan_id=s["scan_id"], project=s["project_name"], status=s["status"], at=s["started_at"], findings=len(s.get("findings", []))))
        for f in s.get("findings", []):
            if f.get("status") == "Fixed":
                activity.append(dict(scan_id=s["scan_id"], project=s["project_name"], status="verified",
                                     at=(f.get("patch") or {}).get("verification", {}).get("verified_at", s["started_at"]), title=f["title"]))
    activity.sort(key=lambda a: a["at"], reverse=True)
    return dict(projects=projects, scans=len(scans), findings=total, verified=verified, severity=sev, trend=list(reversed(trend[:12])), activity=activity[:12])


def _share_out(link: dict) -> dict:
    return dict(token=link["token"], created_at=link["created_at"], path=f"/share/{link['token']}")


@api.get("/scans/{sid}/share")
async def get_share(sid: str, user=Depends(get_current_user)):
    await owned_scan(sid, user)
    link = await db.share_links.find_one({"scan_id": sid, "revoked": False}, {"_id": 0})
    return _share_out(link) if link else None


@api.post("/scans/{sid}/share", status_code=201)
async def create_share(sid: str, user=Depends(get_current_user)):
    s = await owned_scan(sid, user)
    if s["status"] != "done":
        raise HTTPException(409, "Only completed scans can be shared.")
    link = await db.share_links.find_one({"scan_id": sid, "revoked": False}, {"_id": 0})
    if not link:
        link = dict(token=secrets.token_urlsafe(48), scan_id=sid, user_id=user["user_id"], created_at=now(), revoked=False)
        await db.share_links.insert_one(dict(link))
    return _share_out(link)


@api.delete("/scans/{sid}/share")
async def revoke_share(sid: str, user=Depends(get_current_user)):
    await owned_scan(sid, user)
    await db.share_links.update_many({"scan_id": sid, "revoked": False}, {"$set": {"revoked": True, "revoked_at": now()}})
    return {"ok": True}


async def _shared_scan(token: str) -> tuple[dict, dict]:
    link = await db.share_links.find_one({"token": token, "revoked": False}, {"_id": 0})
    s = link and await db.scans.find_one({"scan_id": link["scan_id"]}, {"_id": 0, "user_id": 0, "logs": 0})
    p = s and await db.projects.find_one({"project_id": s["project_id"]}, {"_id": 0})
    if not p:
        raise HTTPException(404, "This shared link does not exist or has been revoked.")
    return s, p


@api.get("/share/{token}")
async def shared_scan(token: str):
    s, p = await _shared_scan(token)
    owner = await db.users.find_one({"user_id": p["user_id"]}, {"_id": 0, "name": 1})
    return {**s, "code": p["code"], "description": p.get("description", ""), "shared_by": (owner or {}).get("name", "a SentinelGraph user")}


@api.get("/share/{token}/download/{kind}")
async def shared_download(token: str, kind: str):
    s, p = await _shared_scan(token)
    ext = scanner.XO.get(s["language"], "txt")
    if kind == "code":
        return _scan_file_response(p["code"], f"main.{ext}")
    if kind == "corrected":
        merged, applied, _ = scanner.merge_patches(p["code"], s.get("findings", []))
        if not applied:
            raise HTTPException(400, "No patch suggestions available for this scan.")
        return _scan_file_response(merged, f"main.fixed.{ext}")
    raise HTTPException(404, "Unknown download")


from fastapi.responses import FileResponse

@app.get("/api/export/source")
async def export_source(user=Depends(get_current_user)):
    _audit_export = logging.getLogger("sentinelgraph.audit")
    _audit_export.info("AUDIT EXPORT_SOURCE user_id=%s", user["user_id"])
    return FileResponse(ROOT_DIR / "public" / "sentinelgraph-source.zip", media_type="application/zip", filename="sentinelgraph-source.zip")


app.include_router(auth.router, prefix="/api")
app.include_router(api)

# --- Security middleware stack (order matters: CORS outermost, then headers, limits) ---
app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get("CORS_ORIGINS", "*").split(","),
    allow_methods=["GET", "POST", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "Origin", "Referer"],
)
app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(BodySizeLimitMiddleware)
app.add_middleware(RateLimitMiddleware)
app.add_middleware(HTTPSRedirectMiddleware)


@app.on_event("startup")
async def startup():
    await db.users.create_index("email", unique=True)
    await db.users.create_index("user_id", unique=True)
    await db.user_sessions.create_index("session_token")
    await db.projects.create_index([("user_id", 1), ("created_at", -1)])
    await db.scans.create_index([("user_id", 1), ("started_at", -1)])
    await db.login_attempts.create_index("identifier")
    await db.share_links.create_index("token", unique=True)
    await db.share_links.create_index("scan_id")
    await db.password_reset_tokens.create_index("expires_at", expireAfterSeconds=0)
    await auth.seed_admin()
    await db.scans.update_many({"status": "running"}, {"$set": {"status": "failed", "stage": "Failed: server restarted during analysis"}})


@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
